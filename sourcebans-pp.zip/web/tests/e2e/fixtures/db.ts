/**
 * Bridge between Playwright (TypeScript) and the PHPUnit Fixture (PHP)
 * that owns the `sourcebans_e2e` database.
 *
 * The actual install/reset logic lives in
 * `web/tests/e2e/scripts/reset-e2e-db.php` which reuses
 * `Sbpp\Tests\Fixture` — same renderer, same struc.sql + data.sql, same
 * seeded admin row (admin/admin) — but pointed at a dedicated
 * `sourcebans_e2e` schema so PHPUnit's `sourcebans_test` and the dev
 * `sourcebans` DB stay untouched.
 *
 * Two execution modes are supported:
 *
 * 1. Host-side (`E2E_IN_CONTAINER` unset/empty): we shell out via
 *    `docker compose exec -T web php …`. Used when the spec runs from
 *    the host (e.g. `npx playwright test` invoked manually with the
 *    panel reachable on a published port).
 * 2. In-container (`E2E_IN_CONTAINER=1`): we invoke `php` directly
 *    because we're already inside the web container. `./sbpp.sh e2e`
 *    flips this on so the suite doesn't need a Docker socket inside
 *    the container.
 */

import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const execFileP = promisify(execFile);

const SCRIPT_INSIDE_CONTAINER = '/var/www/html/web/tests/e2e/scripts/reset-e2e-db.php';
const SEED_COMMS_INSIDE_CONTAINER =
    '/var/www/html/web/tests/e2e/scripts/seed-comms-e2e.php';
const SEED_COMMENTS_INSIDE_CONTAINER =
    '/var/www/html/web/tests/e2e/scripts/seed-comments-e2e.php';
const SEED_ANNOUNCEMENTS_INSIDE_CONTAINER =
    '/var/www/html/web/tests/e2e/scripts/seed-announcements-e2e.php';
const SEED_LOSTPASSWORD_INSIDE_CONTAINER =
    '/var/www/html/web/tests/e2e/scripts/seed-lostpassword-e2e.php';
const SEED_LOSTPASSWORD_ENUM_ADMIN_INSIDE_CONTAINER =
    '/var/www/html/web/tests/e2e/scripts/seed-lostpassword-enum-admin-e2e.php';
const SET_SETTING_INSIDE_CONTAINER =
    '/var/www/html/web/tests/e2e/scripts/set-setting-e2e.php';
const ORPHAN_BAN_AID_INSIDE_CONTAINER =
    '/var/www/html/web/tests/e2e/scripts/orphan-ban-aid-e2e.php';
const SEED_SERVER_GROUP_INSIDE_CONTAINER =
    '/var/www/html/web/tests/e2e/scripts/seed-server-group-e2e.php';
const DELETE_SERVER_INSIDE_CONTAINER =
    '/var/www/html/web/tests/e2e/scripts/delete-server-e2e.php';
const CLEAR_TEST_EMAIL_THROTTLE_INSIDE_CONTAINER =
    '/var/www/html/web/tests/e2e/scripts/clear-test-email-throttle-e2e.php';
const SEED_SYSTEM_LOG_INSIDE_CONTAINER =
    '/var/www/html/web/tests/e2e/scripts/seed-system-log-e2e.php';

/**
 * Run the PHP shim that drives `Sbpp\Tests\Fixture` against
 * `sourcebans_e2e`. `args` is forwarded as-is.
 */
async function runReset(args: string[] = []): Promise<void> {
    const inContainer = process.env.E2E_IN_CONTAINER === '1';
    const cmd = inContainer ? 'php' : 'docker';
    const cmdArgs = inContainer
        ? [SCRIPT_INSIDE_CONTAINER, ...args]
        : ['compose', 'exec', '-T', 'web', 'php', SCRIPT_INSIDE_CONTAINER, ...args];

    try {
        await execFileP(cmd, cmdArgs, {
            // Generous buffer: the install path can emit a few KB of
            // PDO warnings on a freshly-created DB. Reset prints far
            // less but the cap stays the same.
            maxBuffer: 8 * 1024 * 1024,
            // The host-side path uses `docker compose` which resolves
            // both docker-compose.yml and any worktree-local
            // override (per AGENTS.md "Parallel stacks") from cwd.
            cwd: inContainer ? undefined : process.cwd(),
        });
    } catch (err) {
        const e = err as NodeJS.ErrnoException & { stdout?: string; stderr?: string };
        const stdout = e.stdout ?? '';
        const stderr = e.stderr ?? '';
        throw new Error(
            `reset-e2e-db.php (${args.join(' ') || 'install'}) failed: ${e.message}\n` +
                `stdout:\n${stdout}\nstderr:\n${stderr}`,
        );
    }
}

/**
 * Drop + recreate `sourcebans_e2e` from the install/sql templates and
 * seed the default admin row. Called once from `global-setup.ts`.
 */
export async function resetE2eDb(): Promise<void> {
    await runReset([]);
}

/**
 * Truncate every table in `sourcebans_e2e` and re-seed the rows
 * `data.sql` provides + the admin. Cheaper than a full install and
 * preferred between specs (see Fixture::reset()).
 */
export async function truncateE2eDb(): Promise<void> {
    await runReset(['--truncate']);
}

/**
 * Per-row shape consumed by `seedCommsRawE2e`. `type=silence` maps to
 * `:prefix_comms.type=3` — the SourceComms-fork combined-block label
 * the chip filter (#1274) recognises but `Actions.CommsAdd` doesn't
 * directly emit. See `web/tests/e2e/scripts/seed-comms-e2e.php` for
 * the full `state→length/ends/RemoveType` mapping.
 */
export interface CommsSeedRow {
    steam: string;
    nickname: string;
    type: 'mute' | 'gag' | 'silence';
    state: 'active' | 'unmuted' | 'expired' | 'permanent';
    reason?: string;
}

/**
 * Seed comm-block rows directly via the SQL layer (bypasses
 * `Actions.CommsAdd`). Used by `comms-filter-chips.spec.ts` because
 * the chip filter has to handle `type=3` (silence) rows that the
 * normal API path never emits, plus mixed states (`unmuted`,
 * `expired`, `permanent`) that would otherwise require driving
 * separate API actions per row.
 *
 * Caller responsibility: invoke after `truncateE2eDb()` so the seeded
 * rows are the only ones the spec sees.
 */
export async function seedCommsRawE2e(rows: CommsSeedRow[]): Promise<void> {
    const inContainer = process.env.E2E_IN_CONTAINER === '1';
    const cmd = inContainer ? 'php' : 'docker';
    const cmdArgs = inContainer
        ? [SEED_COMMS_INSIDE_CONTAINER]
        : ['compose', 'exec', '-T', 'web', 'php', SEED_COMMS_INSIDE_CONTAINER];

    const child = execFile(cmd, cmdArgs, {
        // Generous buffer matches runReset; the seeder prints a single
        // confirmation line in the happy path but a noisy PHP stack
        // trace on failure.
        maxBuffer: 8 * 1024 * 1024,
        cwd: inContainer ? undefined : process.cwd(),
    });

    let stdout = '';
    let stderr = '';
    child.stdout?.on('data', (chunk: Buffer) => { stdout += chunk.toString('utf8'); });
    child.stderr?.on('data', (chunk: Buffer) => { stderr += chunk.toString('utf8'); });

    child.stdin?.write(JSON.stringify(rows));
    child.stdin?.end();

    await new Promise<void>((resolve, reject) => {
        child.on('error', reject);
        child.on('exit', (code) => {
            if (code === 0) {
                resolve();
                return;
            }
            reject(new Error(
                `seed-comms-e2e.php exited ${code}\n`
                + `stdout:\n${stdout}\nstderr:\n${stderr}`,
            ));
        });
    });
}

/**
 * Per-row shape consumed by `seedCommentsRawE2e`. `type='B'` attaches
 * the comment to a ban row (the bid is the bans table primary key);
 * `type='C'` attaches to a comm-block row (the bid here is the
 * comms table cid — the column was reused from v1.x without a rename).
 *
 * Used by the banlist-comments-visibility spec because there is no
 * JSON action for adding admin-authored per-row comments — the
 * production write path is the legacy `?p=banlist&comment=N` POST
 * handler. Driving an HTML POST through Playwright would couple the
 * spec to the comment-edit chrome and CSRF handshake, which is
 * unrelated to what we're verifying (the disclosure renders, the
 * drawer paints the same data).
 */
export interface CommentSeedRow {
    type: 'B' | 'C';
    bid: number;
    text: string;
}

/**
 * Seed `:prefix_comments` rows directly via the SQL layer. Caller
 * responsibility: the parent ban / comm row must already exist
 * (`seedBanViaApi` / `seedCommsRawE2e`); the e2e DB must already be
 * truncated.
 */
export async function seedCommentsRawE2e(rows: CommentSeedRow[]): Promise<void> {
    const inContainer = process.env.E2E_IN_CONTAINER === '1';
    const cmd = inContainer ? 'php' : 'docker';
    const cmdArgs = inContainer
        ? [SEED_COMMENTS_INSIDE_CONTAINER]
        : ['compose', 'exec', '-T', 'web', 'php', SEED_COMMENTS_INSIDE_CONTAINER];

    const child = execFile(cmd, cmdArgs, {
        maxBuffer: 8 * 1024 * 1024,
        cwd: inContainer ? undefined : process.cwd(),
    });

    let stdout = '';
    let stderr = '';
    child.stdout?.on('data', (chunk: Buffer) => { stdout += chunk.toString('utf8'); });
    child.stderr?.on('data', (chunk: Buffer) => { stderr += chunk.toString('utf8'); });

    child.stdin?.write(JSON.stringify(rows));
    child.stdin?.end();

    await new Promise<void>((resolve, reject) => {
        child.on('error', reject);
        child.on('exit', (code) => {
            if (code === 0) {
                resolve();
                return;
            }
            reject(new Error(
                `seed-comments-e2e.php exited ${code}\n`
                + `stdout:\n${stdout}\nstderr:\n${stderr}`,
            ));
        });
    });
}

/**
 * Per-row shape consumed by `seedAnnouncementsE2e`. Mirrors the
 * `docs/public/announcements.json` schema that
 * `Sbpp\Announce\AnnouncementFetcher::parseEntries` validates.
 */
export interface AnnouncementSeedRow {
    id: string;
    title: string;
    body_md?: string;
    url?: string;
    published_at?: string;
    expires_at?: string;
}

/**
 * Write an announcements cache file directly to `SB_CACHE` so the
 * dashboard renders the strip without doing the upstream HTTPS
 * fetch. Call `clearAnnouncementsCacheE2e()` in the spec's `afterAll`
 * (or `afterEach`) to undo. The cache file is shared between specs
 * (single SB_CACHE inside the dev container), so a spec that seeds
 * an announcement must clean up afterwards.
 */
export async function seedAnnouncementsE2e(rows: AnnouncementSeedRow[]): Promise<void> {
    await runAnnouncementsHelper(JSON.stringify(rows), []);
}

/**
 * Drop the announcements cache file. Idempotent.
 */
export async function clearAnnouncementsCacheE2e(): Promise<void> {
    await runAnnouncementsHelper(null, ['--clear']);
}

/**
 * Pre-seeded state for the lostpassword happy-path spec (#1403):
 *   - `email` is the seeded admin's address.
 *   - `token` is the `:prefix_admins.validate` value the spec must
 *     pass in `?validation=<token>` so the success branch fires.
 */
export interface LostpasswordSeed {
    email: string;
    token: string;
}

/**
 * Seed the SMTP config (pointing at the dev stack's mailpit) and
 * write a known `:prefix_admins.validate` token for the seeded
 * admin row. Returns `{email, token}` so the spec can drive the
 * `?p=lostpassword&email=…&validation=…` URL deterministically.
 *
 * Mirrors `seedAnnouncementsE2e` / `seedCommsRawE2e`: shells out to
 * `web/tests/e2e/scripts/seed-lostpassword-e2e.php` which is the
 * single source of truth for which settings the happy-path requires
 * (kept out of the TS side so the schema-shape of `:prefix_settings`
 * stays Python-style invisible to the spec author).
 *
 * Pass `email` to seed (and target) a dedicated admin row for that
 * address instead of `admin@example.test`.
 */
export async function seedLostpasswordE2e(email?: string): Promise<LostpasswordSeed> {
    const inContainer = process.env.E2E_IN_CONTAINER === '1';
    const cmd = inContainer ? 'php' : 'docker';
    const scriptArgs = email === undefined
        ? [SEED_LOSTPASSWORD_INSIDE_CONTAINER]
        : [SEED_LOSTPASSWORD_INSIDE_CONTAINER, email];
    const cmdArgs = inContainer
        ? scriptArgs
        : ['compose', 'exec', '-T', 'web', 'php', ...scriptArgs];

    const { stdout, stderr } = await execFileP(cmd, cmdArgs, {
        maxBuffer: 1 * 1024 * 1024,
        cwd: inContainer ? undefined : process.cwd(),
    });
    const trimmed = stdout.trim();
    if (trimmed === '') {
        throw new Error(`seed-lostpassword-e2e.php: empty stdout\nstderr:\n${stderr}`);
    }
    try {
        const parsed = JSON.parse(trimmed) as LostpasswordSeed;
        if (typeof parsed.email !== 'string' || typeof parsed.token !== 'string') {
            throw new Error('missing email/token keys');
        }
        return parsed;
    } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        throw new Error(
            `seed-lostpassword-e2e.php: malformed stdout (${msg})\nstdout:\n${trimmed}\nstderr:\n${stderr}`,
        );
    }
}

/**
 * Shape of the `seedLostpasswordEnumAdminE2e` return value.
 *
 * Only `email` is exposed — the form-POST tests don't need a
 * password / token because they never log in as the seeded user
 * and the handler rolls a fresh `validate` on every match.
 */
export interface LostpasswordEnumAdminSeed {
    email: string;
}

/**
 * Seed a dedicated admin row whose validate column can be freely
 * rolled by the `api_auth_lost_password` handler (#1456 form-POST
 * E2E tests).
 *
 * The seeded user lives separately from `admin@example.test` so
 * the form-POST specs can drive the match branch — which UPDATEs
 * `:prefix_admins.validate` — without racing the marquee #1403
 * happy-path test, which seeds `admin@example.test`'s validate
 * column to a known token and `GET`s a URL keyed on it. Cross-
 * project (chromium ⇄ mobile-chromium) Playwright runs are
 * intrinsically parallel even with `test.describe.configure({
 * mode: 'serial' })` (serial is within-project), so the two
 * tests would otherwise race on the same row.
 *
 * See `web/tests/e2e/scripts/seed-lostpassword-enum-admin-e2e.php`
 * for the per-row contract (idempotent `INSERT IGNORE`, low-
 * privilege, unguessable password).
 */
export async function seedLostpasswordEnumAdminE2e(): Promise<LostpasswordEnumAdminSeed> {
    const inContainer = process.env.E2E_IN_CONTAINER === '1';
    const cmd = inContainer ? 'php' : 'docker';
    const cmdArgs = inContainer
        ? [SEED_LOSTPASSWORD_ENUM_ADMIN_INSIDE_CONTAINER]
        : ['compose', 'exec', '-T', 'web', 'php', SEED_LOSTPASSWORD_ENUM_ADMIN_INSIDE_CONTAINER];

    const { stdout, stderr } = await execFileP(cmd, cmdArgs, {
        maxBuffer: 1 * 1024 * 1024,
        cwd: inContainer ? undefined : process.cwd(),
    });
    const trimmed = stdout.trim();
    if (trimmed === '') {
        throw new Error(`seed-lostpassword-enum-admin-e2e.php: empty stdout\nstderr:\n${stderr}`);
    }
    try {
        const parsed = JSON.parse(trimmed) as LostpasswordEnumAdminSeed;
        if (typeof parsed.email !== 'string') {
            throw new Error('missing email key');
        }
        return parsed;
    } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        throw new Error(
            `seed-lostpassword-enum-admin-e2e.php: malformed stdout (${msg})\nstdout:\n${trimmed}\nstderr:\n${stderr}`,
        );
    }
}

/**
 * Set a single `:prefix_settings` row in the e2e DB. Useful for
 * feature toggles that ship disabled in `data.sql` but need to be
 * on for a spec (e.g. `config.enablegroupbanning` for the
 * group-ban dispatcher regression in #1402). Mirrors the
 * `REPLACE INTO sb_settings` shape that `BansTest.php` uses for the
 * same reason. Caller is responsible for reverting in afterEach;
 * the e2e DB is shared between specs.
 */
export async function setSettingE2e(setting: string, value: string): Promise<void> {
    const inContainer = process.env.E2E_IN_CONTAINER === '1';
    const cmd = inContainer ? 'php' : 'docker';
    const cmdArgs = inContainer
        ? [SET_SETTING_INSIDE_CONTAINER]
        : ['compose', 'exec', '-T', 'web', 'php', SET_SETTING_INSIDE_CONTAINER];

    const child = execFile(cmd, cmdArgs, {
        maxBuffer: 8 * 1024 * 1024,
        cwd: inContainer ? undefined : process.cwd(),
    });

    let stdout = '';
    let stderr = '';
    child.stdout?.on('data', (chunk: Buffer) => { stdout += chunk.toString('utf8'); });
    child.stderr?.on('data', (chunk: Buffer) => { stderr += chunk.toString('utf8'); });

    child.stdin?.write(JSON.stringify({ setting, value }));
    child.stdin?.end();

    await new Promise<void>((resolve, reject) => {
        child.on('error', reject);
        child.on('exit', (code) => {
            if (code === 0) {
                resolve();
                return;
            }
            reject(new Error(
                `set-setting-e2e.php exited ${code}\n`
                + `stdout:\n${stdout}\nstderr:\n${stderr}`,
            ));
        });
    });
}

/**
 * Orphan a `:prefix_bans` row by UPDATE-ing its `aid` to a value that
 * doesn't exist in `:prefix_admins`. Triggers the `page.banlist.php`
 * capital-NOT branch (`'Player NOT Unbanned'`, L159 post-#1409) which
 * fires when the admin INNER JOIN at L72 returns empty even though the
 * bans row itself still exists — the documented "destructive action
 * FAILED" branch the #1409 follow-up converts to a persistent toast
 * (`duration_ms: 0`).
 *
 * Caller responsibility: pass a `bid` returned from `seedBanViaApi` so
 * the underlying bans row has the right shape for the L83 SELECT to
 * resolve; `new_aid` defaults to 99999 (well outside any realistic
 * admin-id sequence — matches the `NONEXISTENT_BID` convention in
 * `banlist-getfallback-toast.spec.ts`). The shim refuses to overwrite
 * with an aid that DOES exist in `:prefix_admins` so a future change
 * to the seed admin layout doesn't silently degrade the scenario.
 *
 * Used by `toast-persistent-duration.spec.ts`. Mirrors the shape of
 * `setSettingE2e`'s shell-out + stdin-JSON pattern.
 */
export async function orphanBanAidE2e(bid: number, newAid = 99999): Promise<void> {
    const inContainer = process.env.E2E_IN_CONTAINER === '1';
    const cmd = inContainer ? 'php' : 'docker';
    const cmdArgs = inContainer
        ? [ORPHAN_BAN_AID_INSIDE_CONTAINER]
        : ['compose', 'exec', '-T', 'web', 'php', ORPHAN_BAN_AID_INSIDE_CONTAINER];

    const child = execFile(cmd, cmdArgs, {
        maxBuffer: 8 * 1024 * 1024,
        cwd: inContainer ? undefined : process.cwd(),
    });

    let stdout = '';
    let stderr = '';
    child.stdout?.on('data', (chunk: Buffer) => { stdout += chunk.toString('utf8'); });
    child.stderr?.on('data', (chunk: Buffer) => { stderr += chunk.toString('utf8'); });

    child.stdin?.write(JSON.stringify({ bid, new_aid: newAid }));
    child.stdin?.end();

    await new Promise<void>((resolve, reject) => {
        child.on('error', reject);
        child.on('exit', (code) => {
            if (code === 0) {
                resolve();
                return;
            }
            reject(new Error(
                `orphan-ban-aid-e2e.php exited ${code}\n`
                + `stdout:\n${stdout}\nstderr:\n${stderr}`,
            ));
        });
    });
}

/**
 * Per-server seed row consumed by `seedServerGroupWithServersE2e`.
 * RFC 5737 documentation IPs (203.0.113.0/24, 198.51.100.0/24,
 * 192.0.2.0/24) are recommended so a real Source server can't ever
 * answer the A2S probe; the spec stubs `Actions.ServersHostPlayers`
 * via `page.route` anyway, but the IPs show up in the SSR fallback.
 *
 * `enabled` defaults to `true` (matches the schema's
 * `:prefix_servers.enabled TINYINT NOT NULL DEFAULT '1'`). Pass
 * `false` to seed a server the admin Server Groups card stack will
 * tag with `data-server-skip="1"` + the visible "Disabled" pill so
 * `server-tile-hydrate.js` short-circuits the per-tile probe
 * (#1406 post-review).
 */
export interface ServerGroupSeedServer {
    ip: string;
    port: number;
    enabled?: boolean;
}

/**
 * Shape returned by `seedServerGroupWithServersE2e`. `gid` is the
 * server-group's `:prefix_groups.gid`; `sids` mirrors the per-server
 * `:prefix_servers.sid` list in insert order so the spec can keyword
 * each `page.route` stub by sid. `enabled` flows through verbatim so
 * specs covering the disabled-server arm can assert against the
 * canonical value the shim wrote without re-deriving it.
 */
export interface ServerGroupSeedResult {
    gid: number;
    sids: number[];
    servers: Array<{ sid: number; ip: string; port: number; enabled: boolean }>;
}

/**
 * Seed a `:prefix_groups (type=3)` server group with N bound
 * `:prefix_servers` rows wired through `:prefix_servers_groups`.
 * Used by the admin Server Groups card-hydration spec (#1406) because
 * there is no JSON action that wires a server into a server group's
 * membership — the legacy master-detail UI write path is the only
 * existing surface, and driving an HTML form post through Playwright
 * would couple the spec to the master-detail chrome (unrelated to
 * what we're verifying: each per-group card carries the hydration
 * testids + the live hostname patches in over the SSR IP:port).
 *
 * Mirrors the `seedCommsRawE2e` / `seedLostpasswordE2e` shape:
 * shells out to a PHP shim that runs against the e2e DB and refuses
 * any other.
 */
export async function seedServerGroupWithServersE2e(
    groupName: string,
    servers: ServerGroupSeedServer[],
): Promise<ServerGroupSeedResult> {
    const inContainer = process.env.E2E_IN_CONTAINER === '1';
    const cmd = inContainer ? 'php' : 'docker';
    const cmdArgs = inContainer
        ? [SEED_SERVER_GROUP_INSIDE_CONTAINER]
        : ['compose', 'exec', '-T', 'web', 'php', SEED_SERVER_GROUP_INSIDE_CONTAINER];

    const child = execFile(cmd, cmdArgs, {
        maxBuffer: 8 * 1024 * 1024,
        cwd: inContainer ? undefined : process.cwd(),
    });

    let stdout = '';
    let stderr = '';
    child.stdout?.on('data', (chunk: Buffer) => { stdout += chunk.toString('utf8'); });
    child.stderr?.on('data', (chunk: Buffer) => { stderr += chunk.toString('utf8'); });

    child.stdin?.write(JSON.stringify({
        group: { name: groupName },
        servers,
    }));
    child.stdin?.end();

    await new Promise<void>((resolve, reject) => {
        child.on('error', reject);
        child.on('exit', (code) => {
            if (code === 0) {
                resolve();
                return;
            }
            reject(new Error(
                `seed-server-group-e2e.php exited ${code}\n`
                + `stdout:\n${stdout}\nstderr:\n${stderr}`,
            ));
        });
    });

    const trimmed = stdout.trim();
    if (trimmed === '') {
        throw new Error(`seed-server-group-e2e.php: empty stdout\nstderr:\n${stderr}`);
    }
    try {
        const parsed = JSON.parse(trimmed) as ServerGroupSeedResult;
        if (typeof parsed.gid !== 'number' || !Array.isArray(parsed.sids) || !Array.isArray(parsed.servers)) {
            throw new Error('missing gid/sids/servers keys');
        }
        return parsed;
    } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        throw new Error(
            `seed-server-group-e2e.php: malformed stdout (${msg})\nstdout:\n${trimmed}\nstderr:\n${stderr}`,
        );
    }
}

/**
 * Delete a `:prefix_servers` row by `sid` via the dedicated e2e shim
 * that **bypasses `api_servers_remove`**'s cleanup cascade. The
 * dispatcher action runs a paired
 * `DELETE FROM :prefix_servers_groups WHERE server_id = ?` (plus
 * sibling cascades on `:prefix_admins_servers_groups`, etc.) which
 * defeats the test purpose of the dangling-membership-row spec arm
 * in `admin-groups-server-cards-hydration.spec.ts`.
 *
 * The whole point of that spec arm is to prove the admin Server
 * Groups page's INNER JOIN (added in #1406) silently drops orphaned
 * `:prefix_servers_groups` rows; the orphan only exists if the
 * server delete LEAVES the membership row in place. The raw SQL
 * shim is the narrow shape that produces the test condition.
 *
 * Idempotent: deleting an already-deleted sid is a no-op and the
 * shim returns `{deleted: 0}` so the caller can sanity-check.
 */
export async function deleteServerE2e(sid: number): Promise<{ sid: number; deleted: number }> {
    const inContainer = process.env.E2E_IN_CONTAINER === '1';
    const cmd = inContainer ? 'php' : 'docker';
    const cmdArgs = inContainer
        ? [DELETE_SERVER_INSIDE_CONTAINER]
        : ['compose', 'exec', '-T', 'web', 'php', DELETE_SERVER_INSIDE_CONTAINER];

    const child = execFile(cmd, cmdArgs, {
        maxBuffer: 8 * 1024 * 1024,
        cwd: inContainer ? undefined : process.cwd(),
    });

    let stdout = '';
    let stderr = '';
    child.stdout?.on('data', (chunk: Buffer) => { stdout += chunk.toString('utf8'); });
    child.stderr?.on('data', (chunk: Buffer) => { stderr += chunk.toString('utf8'); });

    child.stdin?.write(JSON.stringify({ sid }));
    child.stdin?.end();

    await new Promise<void>((resolve, reject) => {
        child.on('error', reject);
        child.on('exit', (code) => {
            if (code === 0) {
                resolve();
                return;
            }
            reject(new Error(
                `delete-server-e2e.php exited ${code}\n`
                + `stdout:\n${stdout}\nstderr:\n${stderr}`,
            ));
        });
    });

    const trimmed = stdout.trim();
    if (trimmed === '') {
        throw new Error(`delete-server-e2e.php: empty stdout\nstderr:\n${stderr}`);
    }
    try {
        const parsed = JSON.parse(trimmed) as { sid: number; deleted: number };
        if (typeof parsed.sid !== 'number' || typeof parsed.deleted !== 'number') {
            throw new Error('missing sid/deleted keys');
        }
        return parsed;
    } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        throw new Error(
            `delete-server-e2e.php: malformed stdout (${msg})\nstdout:\n${trimmed}\nstderr:\n${stderr}`,
        );
    }
}

async function runAnnouncementsHelper(
    stdin: string | null,
    extraArgs: string[],
): Promise<void> {
    const inContainer = process.env.E2E_IN_CONTAINER === '1';
    const cmd = inContainer ? 'php' : 'docker';
    const cmdArgs = inContainer
        ? [SEED_ANNOUNCEMENTS_INSIDE_CONTAINER, ...extraArgs]
        : ['compose', 'exec', '-T', 'web', 'php', SEED_ANNOUNCEMENTS_INSIDE_CONTAINER, ...extraArgs];

    const child = execFile(cmd, cmdArgs, {
        maxBuffer: 8 * 1024 * 1024,
        cwd: inContainer ? undefined : process.cwd(),
    });

    let stdout = '';
    let stderr = '';
    child.stdout?.on('data', (chunk: Buffer) => { stdout += chunk.toString('utf8'); });
    child.stderr?.on('data', (chunk: Buffer) => { stderr += chunk.toString('utf8'); });

    if (stdin !== null) {
        child.stdin?.write(stdin);
    }
    child.stdin?.end();

    await new Promise<void>((resolve, reject) => {
        child.on('error', reject);
        child.on('exit', (code) => {
            if (code === 0) {
                resolve();
                return;
            }
            reject(new Error(
                `seed-announcements-e2e.php exited ${code}\n`
                + `stdout:\n${stdout}\nstderr:\n${stderr}`,
            ));
        });
    });
}

/**
 * Per-row shape consumed by `seedSystemLogE2e` (#1462). Mirrors the
 * `:prefix_log` schema: `type` is the audit letter code
 * (`m`=message, `w`=warning, `e`=error — matches `LogType`). Every
 * field except `type` carries a string default — the spec just
 * needs at least one row to exist so the `{if count($log_items) > 0}`
 * gate in `page_admin_settings_logs.tpl` paints SOMETHING, and the
 * mobile-card / desktop-table parity assertion can run.
 */
export interface SystemLogSeedRow {
    type?: 'm' | 'w' | 'e';
    title?: string;
    message?: string;
    function?: string;
    query?: string;
    host?: string;
}

/**
 * Seed `:prefix_log` rows directly so the System Log sub-tab
 * (`?p=admin&c=settings&section=logs`) actually paints log entries
 * instead of the empty "No log entries." placeholder. The e2e DB's
 * `:prefix_log` table is empty by default (`data.sql` doesn't ship
 * audit rows + `Fixture::truncateAndReseed` truncates every table on
 * reset) and there is no JSON action that emits audit rows directly
 * — they're side effects of authenticated panel writes. Driving e.g.
 * `Actions.BansAdd` to produce a row would couple the System Log
 * spec to the bans-add audit message, so the direct INSERT is the
 * narrow shape the spec needs.
 *
 * Caller responsibility: invoke after `truncateE2eDb()` so the
 * seeded rows are the only ones the spec sees. Mirrors the
 * `seedCommsRawE2e` shape (shell-out + stdin-JSON).
 *
 * Returns the list of inserted `lid` values (in insert order) so
 * the spec can target a specific row via `[data-id="<lid>"]`.
 */
export async function seedSystemLogE2e(rows: SystemLogSeedRow[]): Promise<number[]> {
    const inContainer = process.env.E2E_IN_CONTAINER === '1';
    const cmd = inContainer ? 'php' : 'docker';
    const cmdArgs = inContainer
        ? [SEED_SYSTEM_LOG_INSIDE_CONTAINER]
        : ['compose', 'exec', '-T', 'web', 'php', SEED_SYSTEM_LOG_INSIDE_CONTAINER];

    const child = execFile(cmd, cmdArgs, {
        maxBuffer: 8 * 1024 * 1024,
        cwd: inContainer ? undefined : process.cwd(),
    });

    let stdout = '';
    let stderr = '';
    child.stdout?.on('data', (chunk: Buffer) => { stdout += chunk.toString('utf8'); });
    child.stderr?.on('data', (chunk: Buffer) => { stderr += chunk.toString('utf8'); });

    child.stdin?.write(JSON.stringify(rows));
    child.stdin?.end();

    await new Promise<void>((resolve, reject) => {
        child.on('error', reject);
        child.on('exit', (code) => {
            if (code === 0) {
                resolve();
                return;
            }
            reject(new Error(
                `seed-system-log-e2e.php exited ${code}\n`
                + `stdout:\n${stdout}\nstderr:\n${stderr}`,
            ));
        });
    });

    const trimmed = stdout.trim();
    if (trimmed === '') {
        throw new Error(`seed-system-log-e2e.php: empty stdout\nstderr:\n${stderr}`);
    }
    try {
        const parsed = JSON.parse(trimmed) as { lids: number[] };
        if (!Array.isArray(parsed.lids)) {
            throw new Error('missing lids key');
        }
        return parsed.lids;
    } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        throw new Error(
            `seed-system-log-e2e.php: malformed stdout (${msg})\nstdout:\n${trimmed}\nstderr:\n${stderr}`,
        );
    }
}

/**
 * Clear the `system.test_email` rate-limit cache file (#1455).
 *
 * The handler limits 1 send per 10s per install via a single file at
 * `SB_CACHE/test-email-throttle`. The throttle is install-global
 * (not per-recipient or per-test), so parallel Playwright project
 * profiles colliding on the happy-path test trip each other's
 * 10s window. Reset before each happy-path arm to stay
 * deterministic. Idempotent (no-op when the file is absent).
 */
export async function clearTestEmailThrottleE2e(): Promise<void> {
    const inContainer = process.env.E2E_IN_CONTAINER === '1';
    const cmd = inContainer ? 'php' : 'docker';
    const cmdArgs = inContainer
        ? [CLEAR_TEST_EMAIL_THROTTLE_INSIDE_CONTAINER]
        : ['compose', 'exec', '-T', 'web', 'php', CLEAR_TEST_EMAIL_THROTTLE_INSIDE_CONTAINER];

    await execFileP(cmd, cmdArgs, {
        maxBuffer: 1 * 1024 * 1024,
        cwd: inContainer ? undefined : process.cwd(),
    });
}
