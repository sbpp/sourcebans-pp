<?php

namespace Sbpp\Tests\Api;

use Sbpp\Tests\ApiTestCase;
use Sbpp\Tests\Fixture;

/**
 * Per-handler coverage for web/api/handlers/system.php.
 *
 * The system handlers are mostly thin wrappers around external state
 * (mail, theme files on disk, the upstream version JSON), so the tests
 * here focus on the structured-error envelopes the panel actually
 * branches on, plus the local-only side effects that don't need
 * working RCON / SMTP / network.
 */
final class SystemTest extends ApiTestCase
{
    public function testCheckVersionIsPublicAndReturnsShape(): void
    {
        // Prime the cache so the handler doesn't hit GitHub from CI: the
        // handler always prefers a fresh cache (TTL is 1 day, our payload
        // is `cached_at => now`) and the snapshot then locks the wire
        // shape byte-for-byte without any network dependency. SB_VERSION
        // is `'test'` in the bootstrap and `version_compare` ranks any
        // unrecognised string below every numeric tag, so a tag of
        // `1.8.4` deterministically lands on the "update available"
        // branch; the snapshot pins that.
        $this->primeReleaseCache('1.8.4');

        $env = $this->api('system.check_version', []);
        $this->assertTrue($env['ok']);
        $this->assertSame('1.8.4', $env['data']['release_latest']);
        $this->assertSame(
            'https://github.com/sbpp/sourcebans-pp/releases/tag/1.8.4',
            $env['data']['release_url']
        );
        $this->assertTrue($env['data']['release_update']);
        // The deprecated `dev` / `dev_*` fields from the legacy upstream
        // shape are gone (#1214); guard against a regression that
        // re-introduces them.
        $this->assertArrayNotHasKey('dev',         $env['data']);
        $this->assertArrayNotHasKey('dev_latest',  $env['data']);
        $this->assertArrayNotHasKey('dev_msg',     $env['data']);
        $this->assertArrayNotHasKey('dev_update',  $env['data']);
        $this->assertSnapshot('system/check_version_update_available', $env);
    }

    public function testCheckVersionLatestReleaseFromCache(): void
    {
        // Tag below SB_VERSION = 'test' in version_compare's ordering is
        // impossible (any unrecognised string sorts below every numeric
        // tag), so seed `release_latest` equal to SB_VERSION; the
        // version_compare branch returns 0 and we land on the "you have
        // the latest" copy. This locks the third public response shape
        // without depending on network or on flipping SB_VERSION.
        $this->primeReleaseCache('test');

        $env = $this->api('system.check_version', []);
        $this->assertTrue($env['ok']);
        $this->assertSame('test', $env['data']['release_latest']);
        $this->assertFalse($env['data']['release_update']);
        $this->assertSnapshot('system/check_version_latest_release', $env);
    }

    public function testCheckVersionStripsLeadingVFromTag(): void
    {
        // GitHub releases historically use both `1.8.4` and `v1.8.4`
        // tag shapes; the handler normalises the stored tag so consumers
        // never have to branch on the prefix.
        $this->primeReleaseCache('v9.9.9');

        $env = $this->api('system.check_version', []);
        $this->assertTrue($env['ok']);
        $this->assertSame('9.9.9', $env['data']['release_latest']);
        $this->assertTrue($env['data']['release_update']);
    }

    public function testCheckVersionErrorWhenNoCacheAndUpstreamUnreachable(): void
    {
        // The bootstrap points SB_RELEASE_LATEST_URL at a port that
        // nothing listens on, so the fetch fails immediately
        // (ECONNREFUSED, no 5s wait). Drop the cache and assert the
        // handler reports the documented degraded shape.
        @unlink(SB_CACHE . 'github_release_latest.json');

        $env = $this->api('system.check_version', []);

        $this->assertTrue($env['ok']);
        $this->assertSame('Error', $env['data']['release_latest']);
        $this->assertSame('', $env['data']['release_url']);
        $this->assertFalse($env['data']['release_update']);
        $this->assertSnapshot('system/check_version_error', $env);
    }

    public function testCheckVersionStaleCacheServedWhenUpstreamUnreachable(): void
    {
        // Stale-while-error contract: cache exists but is past the
        // 1-day TTL AND the upstream is unreachable -> serve the cached
        // payload anyway (NOT the `Error` envelope). Prime the cache
        // with `cached_at` one second past the TTL so the in-TTL fast
        // path is skipped and the handler falls into the upstream-fetch
        // branch, where the bootstrap's refused SB_RELEASE_LATEST_URL
        // makes the fetch return null; assert the handler returns the
        // formatted cached shape, not `release_latest: 'Error'`. Re-priming the
        // cache here (rather than relying on a previously-primed file)
        // makes the test order-independent: even if it runs after
        // `testCheckVersionErrorWhenNoCacheAndUpstreamUnreachable`
        // unlinked the file, the stale entry below is what the assertion
        // depends on.
        $this->primeReleaseCache('1.7.2', time() - 86401);

        $env = $this->api('system.check_version', []);

        $this->assertTrue($env['ok']);
        $this->assertSame('1.7.2', $env['data']['release_latest']);
        $this->assertSame(
            'https://github.com/sbpp/sourcebans-pp/releases/tag/1.7.2',
            $env['data']['release_url']
        );
        $this->assertNotSame('Error', $env['data']['release_latest']);
        $this->assertSnapshot('system/check_version_stale_while_error', $env);
    }

    public function testCheckVersionDevSentinelShortCircuitsBeforeVersionCompare(): void
    {
        // Pin the explicit guard added in #1214: a dev-checkout panel
        // (SB_VERSION === 'dev') must NOT compare its local version
        // against the upstream tag with version_compare(), because PHP
        // treats `dev` as a pre-release suffix and ranks it below every
        // numeric tag — `version_compare('1.8.4', 'dev')` returns 1, so
        // a naive compare would falsely advertise an update on every
        // dev checkout. The handler short-circuits that case to return
        // `release_update: false` + a "tracking development build" copy
        // so dev-mode users aren't nagged.
        //
        // SB_VERSION is fixed at 'test' in the bootstrap and PHP can't
        // redefine constants mid-run, so exercise the helper directly
        // with the sentinel as the local-version argument; that's the
        // exact branch the dispatcher would hit on a real dev checkout.
        // The handler file is loaded transitively via Api::bootstrap()
        // in Fixture::install(), so the global helper is in scope by
        // the time setUp() returns. Leading `\` makes it explicit
        // we're reaching for a global function from inside the
        // `Sbpp\Tests\Api` namespace.
        $resp = \_api_system_release_format(
            '1.8.4',
            'https://github.com/sbpp/sourcebans-pp/releases/tag/1.8.4',
            'dev'
        );

        $this->assertSame('1.8.4', $resp['release_latest']);
        $this->assertSame(
            'https://github.com/sbpp/sourcebans-pp/releases/tag/1.8.4',
            $resp['release_url']
        );
        $this->assertSame('Tracking development build.', $resp['release_msg']);
        $this->assertFalse(
            $resp['release_update'],
            'dev sentinel must NOT advertise an update; PHP version_compare("1.8.4", "dev") returns 1.'
        );

        // Belt-and-suspenders: confirm `version_compare` would, in fact,
        // return 1 for the same pair. If a future PHP version changes
        // the comparison, the assertion above is still the correct
        // guard, but this lets a maintainer see immediately why the
        // short-circuit is necessary.
        $this->assertSame(
            1,
            version_compare('1.8.4', 'dev'),
            'PHP semantics changed: version_compare("1.8.4", "dev") no longer returns 1.'
        );
    }

    /**
     * Seed the on-disk cache the handler reads first. The default
     * `cached_at` is `time()`, which (with the 1-day TTL) makes the
     * handler hit the in-TTL fast path and skip the upstream fetch
     * entirely — what the success-path snapshot tests rely on. Pass an
     * older timestamp to exercise the stale-while-error path instead.
     */
    private function primeReleaseCache(string $tagName, ?int $cachedAt = null): void
    {
        $cache = SB_CACHE;
        if (!is_dir($cache) && !@mkdir($cache, 0o775, true) && !is_dir($cache)) {
            $this->markTestSkipped('cache dir not writable');
        }
        file_put_contents($cache . 'github_release_latest.json', (string) json_encode([
            'tag_name'  => $tagName,
            'html_url'  => 'https://github.com/sbpp/sourcebans-pp/releases/tag/' . $tagName,
            'cached_at' => $cachedAt ?? time(),
        ]));
    }

    public function testSelThemeRejectsBlank(): void
    {
        $this->loginAsAdmin();
        $env = $this->api('system.sel_theme', ['theme' => '']);
        $this->assertEnvelopeError($env, 'invalid_theme');
        $this->assertSnapshot('system/sel_theme_invalid', $env);
    }

    public function testSelThemeRejectsTraversal(): void
    {
        // The handler scrubs `../` and `..\\` before basename(), so any
        // injected traversal turns into a stripped basename that won't
        // resolve to a real theme dir.
        $this->loginAsAdmin();
        $env = $this->api('system.sel_theme', ['theme' => '../etc/passwd']);
        $this->assertEnvelopeError($env, 'invalid_theme');
    }

    public function testSelThemeRejectsAnonymous(): void
    {
        $env = $this->api('system.sel_theme', ['theme' => 'default']);
        $this->assertEnvelopeError($env, 'forbidden');
    }

    public function testApplyThemeRejectsInvalid(): void
    {
        $this->loginAsAdmin();
        $env = $this->api('system.apply_theme', ['theme' => 'no-such-theme']);
        $this->assertEnvelopeError($env, 'invalid_theme');
    }

    public function testApplyThemeWritesSetting(): void
    {
        // The dev panel ships only `default`. Pin `config.theme` to
        // something else first so we can prove the handler updated it.
        Fixture::rawPdo()->prepare(sprintf(
            "REPLACE INTO `%s_settings` (`setting`, `value`) VALUES ('config.theme', 'old')",
            DB_PREFIX
        ))->execute();

        $this->loginAsAdmin();
        $env = $this->api('system.apply_theme', ['theme' => 'default']);
        $this->assertTrue($env['ok'], json_encode($env));

        $val = Fixture::rawPdo()->query(sprintf(
            "SELECT value FROM `%s_settings` WHERE setting = 'config.theme'",
            DB_PREFIX
        ))->fetchColumn();
        $this->assertSame('default', $val);
        $this->assertSnapshot('system/apply_theme_success', $env);
    }

    public function testApplyThemeRejectsAnonymous(): void
    {
        $env = $this->api('system.apply_theme', ['theme' => 'default']);
        $this->assertEnvelopeError($env, 'forbidden');
    }

    public function testClearCacheReportsClearedTrue(): void
    {
        $this->loginAsAdmin();

        // Pre-seed a file so we can prove it's gone afterwards.
        $cache = SB_CACHE;
        if (!is_dir($cache) && !@mkdir($cache, 0o775, true) && !is_dir($cache)) {
            $this->markTestSkipped('cache dir not writable');
        }
        file_put_contents($cache . 'sentinel.txt', 'remove me');

        $env = $this->api('system.clear_cache', []);
        $this->assertTrue($env['ok']);
        $this->assertTrue($env['data']['cleared']);
        $this->assertFileDoesNotExist($cache . 'sentinel.txt');
        $this->assertSnapshot('system/clear_cache_success', $env);
    }

    public function testClearCacheRejectsAnonymous(): void
    {
        $env = $this->api('system.clear_cache', []);
        $this->assertEnvelopeError($env, 'forbidden');
    }

    public function testSendMailRejectsBadType(): void
    {
        $this->loginAsAdmin();
        $env = $this->api('system.send_mail', [
            'subject' => 'x', 'message' => 'y', 'type' => 'q', 'id' => 1,
        ]);
        $this->assertEnvelopeError($env, 'bad_type');
        $this->assertSnapshot('system/send_mail_bad_type', $env);
    }

    public function testSendMailRejectsMissingEmail(): void
    {
        $this->loginAsAdmin();
        // No submission seeded → handler reads $row['email'] = '' and
        // throws no_email.
        $env = $this->api('system.send_mail', [
            'subject' => 'x', 'message' => 'y', 'type' => 's', 'id' => 9999,
        ]);
        $this->assertEnvelopeError($env, 'no_email');
        $this->assertSnapshot('system/send_mail_no_email', $env);
    }

    public function testSendMailReportsMailFailureForKnownAddress(): void
    {
        // Seed a submission with an email so we hit the Mail::send path.
        // Without working SMTP the handler turns the false return into
        // the structured `mail_failed` envelope. The wire shape of that
        // failure is what we lock down.
        $pdo = Fixture::rawPdo();
        $pdo->prepare(sprintf(
            'INSERT INTO `%s_submissions`
              (`name`, `SteamId`, `email`, `reason`, `archiv`, `submitted`, `ModID`, `ip`, `server`)
             VALUES (?, ?, ?, ?, "0", ?, 0, "127.0.0.1", 0)',
            DB_PREFIX
        ))->execute(['MailMe', 'STEAM_0:0:1', 'mailme@example.test', 'reason', time()]);
        $sid = (int)$pdo->lastInsertId();

        $this->loginAsAdmin();
        $env = $this->api('system.send_mail', [
            'subject' => 'hi', 'message' => 'hello', 'type' => 's', 'id' => $sid,
        ]);
        $this->assertEnvelopeError($env, 'mail_failed');
        $this->assertSnapshot('system/send_mail_failed', $env);
    }

    public function testSendMailRejectsAnonymous(): void
    {
        $env = $this->api('system.send_mail', [
            'subject' => 'x', 'message' => 'y', 'type' => 's', 'id' => 1,
        ]);
        $this->assertEnvelopeError($env, 'forbidden');
    }

    public function testRehashAdminsReturnsResultsListWithoutServers(): void
    {
        $this->loginAsAdmin();
        $env = $this->api('system.rehash_admins', ['servers' => '']);
        $this->assertTrue($env['ok']);
        $this->assertSame([], $env['data']['results']);
        $this->assertSnapshot('system/rehash_admins_empty', $env);
    }

    public function testRehashAdminsReportsRconFailureForUnknownSid(): void
    {
        $this->loginAsAdmin();
        $env = $this->api('system.rehash_admins', ['servers' => '9999']);
        $this->assertTrue($env['ok']);
        $this->assertCount(1, $env['data']['results']);
        $this->assertSame(9999, (int)$env['data']['results'][0]['sid']);
        $this->assertFalse($env['data']['results'][0]['success']);
    }

    public function testRehashAdminsRejectsAnonymous(): void
    {
        $env = $this->api('system.rehash_admins', ['servers' => '']);
        $this->assertEnvelopeError($env, 'forbidden');
    }

    /**
     * #1207 SET-1: live Markdown preview for the dashboard intro field.
     *
     * The handler is a thin wrapper around
     * `Sbpp\Markup\IntroRenderer::renderIntroText()`; we lock in the
     * rendered shape (CommonMark inline -> safe HTML) plus the two
     * security-critical paths the renderer enforces (raw HTML escaped,
     * `javascript:` links stripped). If a future PR routes preview
     * through a different renderer, this row fires loudly.
     */
    public function testPreviewIntroTextRendersCommonMarkParagraph(): void
    {
        $this->loginAsAdmin();
        $env = $this->api('system.preview_intro_text', [
            'markdown' => 'Hello **world** with [a link](https://example.test).',
        ]);
        $this->assertTrue($env['ok'], json_encode($env));
        $this->assertSame(
            "<p>Hello <strong>world</strong> with <a href=\"https://example.test\">a link</a>.</p>\n",
            $env['data']['html']
        );
        $this->assertSnapshot('system/preview_intro_text_paragraph', $env);
    }

    public function testPreviewIntroTextEscapesRawHtml(): void
    {
        $this->loginAsAdmin();
        $env = $this->api('system.preview_intro_text', [
            'markdown' => 'safe <script>alert(1)</script> text',
        ]);
        $this->assertTrue($env['ok']);
        // CommonMark with html_input=escape renders inline HTML as
        // literal text — the `<script>` shows up entity-encoded, not
        // as a parsed tag, so the preview pane never executes admin
        // input. This is the contract from `IntroRenderer::converter`.
        $this->assertStringNotContainsString('<script>', $env['data']['html']);
        $this->assertStringContainsString('&lt;script&gt;', $env['data']['html']);
    }

    public function testPreviewIntroTextStripsUnsafeLinks(): void
    {
        $this->loginAsAdmin();
        $env = $this->api('system.preview_intro_text', [
            'markdown' => '[click](javascript:alert(1))',
        ]);
        $this->assertTrue($env['ok']);
        // `allow_unsafe_links: false` (IntroRenderer) drops
        // javascript:/data:/vbscript: hrefs entirely.
        $this->assertStringNotContainsString('javascript:', $env['data']['html']);
    }

    public function testPreviewIntroTextRendersEmptyForBlankInput(): void
    {
        $this->loginAsAdmin();
        $env = $this->api('system.preview_intro_text', ['markdown' => '']);
        $this->assertTrue($env['ok']);
        $this->assertSame('', $env['data']['html']);
    }

    public function testPreviewIntroTextRejectsAnonymous(): void
    {
        $env = $this->api('system.preview_intro_text', ['markdown' => 'hi']);
        $this->assertEnvelopeError($env, 'forbidden');
    }

    // ---- system.test_email (#1455) -----------------------------------------

    /**
     * Convenience wrapper around `REPLACE INTO :prefix_settings` so each
     * test_email test can set up the SMTP config it needs without
     * round-tripping through the settings page. Mirrors the helper in
     * `MailerSmtpFromTest::setSetting`. Re-initializes the `Config`
     * cache so the handler sees the new value on its next read.
     */
    private function setSmtpSetting(string $key, string $value): void
    {
        $pdo = Fixture::rawPdo();
        $stmt = $pdo->prepare(sprintf(
            'REPLACE INTO `%s_settings` (`setting`, `value`) VALUES (?, ?)',
            DB_PREFIX
        ));
        $stmt->execute([$key, $value]);
        \Config::init($GLOBALS['PDO']);
    }

    /**
     * Pre-seed SMTP credentials that point at an unroutable address.
     * `Mailer::create()` only checks the three string fields are
     * non-empty, so any non-empty values satisfy the
     * smtp_not_configured short-circuit; the real `Mail::send` call
     * then deterministically lands on the `mail_failed` branch
     * because the SMTP TCP connection never establishes.
     *
     * Used by every test that wants the handler to reach
     * `Mail::send` (the rate-limit + audit-log paths) without
     * actually accepting mail in CI.
     */
    private function seedDeadSmtp(): void
    {
        // 127.0.0.1:1 is a port nothing listens on, so Symfony Mailer's
        // EsmtpTransport raises a TransportException almost
        // immediately (ECONNREFUSED) — no 30s timeout.
        $this->setSmtpSetting('smtp.host', '127.0.0.1');
        $this->setSmtpSetting('smtp.user', 'tester');
        $this->setSmtpSetting('smtp.pass', 'shh');
        $this->setSmtpSetting('smtp.port', '1');
        $this->setSmtpSetting('config.mail.from_email', 'noreply@example.test');
        $this->setSmtpSetting('config.mail.from_name', 'SourceBans++');
    }

    public function testTestEmailRejectsAnonymous(): void
    {
        $env = $this->api('system.test_email', ['to' => 'someone@example.test']);
        $this->assertEnvelopeError($env, 'forbidden');
    }

    public function testTestEmailRejectsMalformedRecipient(): void
    {
        $this->loginAsAdmin();
        $env = $this->api('system.test_email', ['to' => 'not-an-email']);
        $this->assertEnvelopeError($env, 'validation');
        $this->assertSame('to', $env['error']['field'] ?? null);
        // Pin the validation envelope shape so a future copy / paste
        // can't accidentally drop the `field` discriminator the
        // client-side toast wiring uses to know which input to flag.
        $this->assertSnapshot('system/test_email_validation', $env);
    }

    public function testTestEmailRejectsOversizedRecipientViaFilterValidateEmail(): void
    {
        $this->loginAsAdmin();
        // Defence-in-depth coverage: FILTER_VALIDATE_EMAIL is documented
        // to enforce the RFC 5321 254-octet forward-path cap (its
        // internal regex rejects oversized strings outright). This
        // test pins that we reject such inputs cleanly with the
        // `validation` envelope, so a future contributor swapping the
        // recipient validator can't silently widen the surface area
        // for Symfony Mailer to throw a generic
        // RfcComplianceException out of band.
        $local  = str_repeat('a', 60); // 60 chars + '@' = 61
        $domain = implode('.', array_fill(0, 32, 'aaaaaa')); // 223 chars
        $to     = $local . '@' . $domain; // 284 bytes total
        $this->assertGreaterThan(254, strlen($to));
        $env = $this->api('system.test_email', ['to' => $to]);
        $this->assertEnvelopeError($env, 'validation');
        $this->assertSame('to', $env['error']['field'] ?? null);
    }

    public function testTestEmailRejectsWhenSmtpNotConfigured(): void
    {
        $this->loginAsAdmin();
        // Freshly-seeded panel: smtp.host / user / pass are all empty
        // (sb_settings ships them as blank), so Mailer::create()
        // returns null and the handler short-circuits with the
        // pointed `smtp_not_configured` error envelope BEFORE
        // touching Mail::send (and therefore BEFORE the rate-limit
        // file gets stamped).
        $this->setSmtpSetting('smtp.host', '');
        $this->setSmtpSetting('smtp.user', '');
        $this->setSmtpSetting('smtp.pass', '');
        $env = $this->api('system.test_email', ['to' => 'someone@example.test']);
        $this->assertEnvelopeError($env, 'smtp_not_configured');
        // Snapshot pins the operator-facing copy so a UX tweak goes
        // through the snapshot-regen workflow rather than silently
        // landing — the message is the only signal the operator gets
        // about *why* the test couldn't run.
        $this->assertSnapshot('system/test_email_smtp_not_configured', $env);
    }

    public function testTestEmailDefaultsRecipientToAdminEmail(): void
    {
        $this->loginAsAdmin();
        $this->seedDeadSmtp();
        // Throttle cleared per setUp().
        @unlink(SB_CACHE . 'test-email-throttle');
        $env = $this->api('system.test_email', []); // no `to` param
        // Drop into mail_failed because the SMTP TCP connect fails.
        // The important assertion is that the handler resolved the
        // recipient (admin@example.test from Fixture::seedAdmin) and
        // tried to send — i.e. it didn't bail on validation.
        $this->assertEnvelopeError($env, 'mail_failed');
    }

    public function testTestEmailReportsMailFailureWhenSmtpDead(): void
    {
        $this->loginAsAdmin();
        $this->seedDeadSmtp();
        @unlink(SB_CACHE . 'test-email-throttle');

        $env = $this->api('system.test_email', ['to' => 'someone@example.test']);
        $this->assertEnvelopeError($env, 'mail_failed');
        $this->assertSnapshot('system/test_email_mail_failed', $env);

        // Audit-log row landed: failure surfaces under the
        // 'Test email failed' title so an operator can correlate
        // attempts with the underlying 'Mail error' row Mail::send
        // emits. Pin both the count AND the body shape so a future
        // refactor that drops the admin/recipient interpolation
        // (which is the entire diagnostic value of the row) fails
        // loudly.
        $row = Fixture::rawPdo()->query(sprintf(
            "SELECT title, message FROM `%s_log` WHERE title = 'Test email failed'",
            DB_PREFIX
        ))->fetch(\PDO::FETCH_ASSOC);
        $this->assertIsArray($row, 'Expected exactly one Test email failed audit-log row.');
        $this->assertSame('Test email failed', $row['title']);
        // The audit row interpolates BOTH the admin's name AND the
        // attempted recipient — both pieces are operator-actionable
        // when triaging "did this send go anywhere?". The username
        // comes from `$userbank->GetProperty('user')` which the
        // PHPUnit fixture seeds as the lowercase `'admin'`.
        $this->assertStringContainsString("Admin 'admin'", (string) $row['message']);
        $this->assertStringContainsString("'someone@example.test'", (string) $row['message']);
        $this->assertStringContainsString('Mail error', (string) $row['message']);
    }

    public function testTestEmailRateLimitsRepeatCallsWithinWindow(): void
    {
        $this->loginAsAdmin();
        $this->seedDeadSmtp();
        @unlink(SB_CACHE . 'test-email-throttle');

        // First call reaches Mail::send and lands on mail_failed
        // (the SMTP connection fails). The throttle file is stamped
        // at the start of the handler regardless.
        $first = $this->api('system.test_email', ['to' => 'a@example.test']);
        $this->assertEnvelopeError($first, 'mail_failed');

        // Second call within the throttle window is short-circuited
        // before reaching Mail::send — proves the throttle is
        // active and the second SMTP attempt never fires (which is
        // the operator-visible value: an unroutable host shouldn't
        // be hammered).
        $second = $this->api('system.test_email', ['to' => 'b@example.test']);
        $this->assertEnvelopeError($second, 'rate_limited');
        // The retry-after seconds value is interpolated into the
        // message at runtime (10 minus elapsed; clamped to a
        // positive int). It can be 9 or 10 depending on whether
        // the two calls crossed a wall-clock second boundary;
        // either is acceptable, so we assert the SHAPE rather
        // than the exact literal — the snapshot below redacts
        // the message and pins everything else.
        $this->assertMatchesRegularExpression(
            '/Test email throttled — try again in (?:9|10) seconds\./',
            (string) ($second['error']['message'] ?? ''),
        );
        // Snapshot pins the code + (redacted) message structure so
        // a future change to the rate_limited shape goes through
        // the snapshot-regen workflow rather than silently breaking
        // any client-side branch logic.
        $this->assertSnapshot(
            'system/test_email_rate_limited',
            $second,
            ['error.message'],
        );
    }

    public function testTestEmailValidationDoesNotConsumeRateLimitSlot(): void
    {
        $this->loginAsAdmin();
        $this->seedDeadSmtp();
        @unlink(SB_CACHE . 'test-email-throttle');

        // Validation failure happens BEFORE the throttle file is
        // stamped. A typo on the recipient shouldn't cost the
        // operator a 10s wait on the next legitimate attempt.
        $bad = $this->api('system.test_email', ['to' => 'not-an-email']);
        $this->assertEnvelopeError($bad, 'validation');

        // Next call with a valid address reaches Mail::send (and
        // lands on mail_failed because the SMTP connection is
        // dead). If the validation branch had stamped the throttle
        // file, this would be `rate_limited` instead.
        $next = $this->api('system.test_email', ['to' => 'a@example.test']);
        $this->assertEnvelopeError($next, 'mail_failed');
    }

    public function testTestEmailSmtpNotConfiguredDoesNotConsumeRateLimitSlot(): void
    {
        $this->loginAsAdmin();
        $this->setSmtpSetting('smtp.host', '');
        $this->setSmtpSetting('smtp.user', '');
        $this->setSmtpSetting('smtp.pass', '');
        @unlink(SB_CACHE . 'test-email-throttle');

        $env = $this->api('system.test_email', ['to' => 'a@example.test']);
        $this->assertEnvelopeError($env, 'smtp_not_configured');

        // The smtp_not_configured short-circuit runs BEFORE the
        // throttle file is stamped. The operator should be able to
        // immediately retry after fixing the settings, not have to
        // wait out the throttle.
        $this->seedDeadSmtp();
        $next = $this->api('system.test_email', ['to' => 'a@example.test']);
        $this->assertEnvelopeError($next, 'mail_failed');
    }
}
