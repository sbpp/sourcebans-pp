SET SESSION sql_mode='NO_AUTO_VALUE_ON_ZERO';

-- INSERT IGNORE on every seed below so a second pass over data.sql
-- (e.g. the operator hits Back from the wizard's success page and
-- re-submits step 5) is a no-op instead of failing on the first
-- duplicate-key error and leaving :prefix_settings half-populated
-- (#1332 review: major 3).
INSERT IGNORE INTO `{prefix}_mods` (`mid`, `name`, `icon`, `modfolder`, `steam_universe`) VALUES
(0, 'Web', 'web.png', 'NULL', '0'),
(1, 'Half-Life 2 Deathmatch', 'hl2dm.png', 'hl2mp', '0'),
(2, 'Counter-Strike: Source', 'csource.png', 'cstrike', '0'),
(3, 'Day of Defeat: Source', 'dods.png', 'dod', '0'),
(4, 'Insurgency: Source', 'ins.png', 'insurgency', '0'),
(5, 'Dystopia', 'dys.png', 'dystopia_v1', '0'),
(6, 'Hidden: Source', 'hidden.png', 'hidden', '0'),
(7, 'Half-Life 2 Capture the Flag', 'hl2ctf.png', 'hl2ctf', '0'),
(8, 'Pirates Vikings and Knights II', 'pvkii.png', 'pvkii', '0'),
(9, 'Perfect Dark: Source', 'pdark.png', 'pdark', '0'),
(10, 'The Ship', 'ship.png', 'ship', '0'),
(11, 'Fortress Forever', 'hl2-fortressforever.png', 'FortressForever', '0'),
(12, 'Team Fortress 2', 'tf2.png', 'tf', '0'),
(13, 'Zombie Panic', 'zps.png', 'zps', '0'),
(14, "Garry's Mod", 'gmod.png', 'garrysmod', '0'),
(15, "Left 4 Dead", 'l4d.png', 'left4dead', '1'),
(16, "Left 4 Dead 2", 'l4d2.png', 'left4dead2', '1'),
(17, "CSPromod", 'cspromod.png', 'cspromod', '0'),
(18, "Alien Swarm", 'alienswarm.png', 'alienswarm', '0'),
(19, "E.Y.E: Divine Cybermancy", 'eye.png', 'eye', '0'),
(20, "Nuclear Dawn", 'nucleardawn.png', 'nucleardawn', '0'),
(21, "Counter-Strike: Global Offensive", 'csgo.png', 'csgo', '1'),
(22, 'Synergy', 'synergy.png', 'synergy', '0');

INSERT IGNORE INTO `{prefix}_settings` (`setting`, `value`) VALUES
('dash.intro.text', '# Your new SourceBans install\n\nSourceBans++ successfully installed!'),
('dash.intro.title', 'Your SourceBans++ install'),
('dash.lognopopup', '0'),
('banlist.bansperpage', '30'),
('banlist.hideadminname', '1'),
('banlist.nocountryfetch', '1'),
('banlist.hideplayerips', '1'),
('bans.customreasons', ''),
('config.password.minlength', '7'),
('config.debug', '0'),
('template.logo', 'images/favicon.svg'),
('template.title', 'SourceBans++'),
('config.enableprotest', '1'),
('config.enablecomms', '1'),
('config.enablesubmit', '1'),
('config.exportpublic', '0'),
('config.enablepubliccomments', '0'),
('config.enablekickit', '1'),
('config.dateformat', 'Y-m-d H:i:s'),
('config.theme', 'default'),
('config.defaultpage', '0'),
('config.enablegroupbanning', '0'),
('config.enablefriendsbanning', '0'),
('config.enableadminrehashing', '1'),
('protest.emailonlyinvolved', '0'),
('config.version', '705'),
('config.enablesteamlogin', '1'),
('config.enablenormallogin', '1'),
('auth.maxlife', '1440'),
('auth.maxlife.remember', '10080'),
('auth.maxlife.steam', '10080'),
('smtp.host', ''),
('smtp.pass', ''),
('smtp.port', ''),
('smtp.user', ''),
('smtp.verify_peer', ''),
('config.mail.from_email', ''),
('config.mail.from_name', 'SourceBans++'),
('telemetry.enabled', '1'),
('telemetry.last_ping', '0'),
('telemetry.instance_id', ''),
('telemetry.endpoint', 'https://cf-analytics-telemetry.sbpp.workers.dev/v1/ping');

INSERT IGNORE INTO `{prefix}_admins` (`aid` ,	`user` , `authid` ,	`password` , `gid` , `email` ,	`validate` , `extraflags`, `immunity`) VALUES
(0 , 'CONSOLE', 'STEAM_ID_SERVER', '', '0', '', NULL, '0', 0);
