<?php
include_once("init.php");
if (!$userbank->HasAccess(WebPermission::Owner) && !Config::getBool('config.exportpublic')) {
    echo "You don't have access to this feature.";
} else if (!isset($_GET['type'])) {
    echo "You have to specify the type. Only follow links!";
} else {
    if ($_GET['type'] == 'steam') {
        header('Content-Type: application/x-httpd-php php');
        header('Content-Disposition: attachment; filename="banned_user.cfg"');
        $bans = $GLOBALS['PDO']->query(
            "SELECT authid FROM `:prefix_bans` WHERE length = '0' AND RemoveType IS NULL AND type = '0'"
        )->iterate();
        foreach ($bans as $ban) {
            print("banid 0 " . $ban['authid'] . "\r\n");
        }
    } elseif ($_GET['type'] == 'ip') {
        header('Content-Type: application/x-httpd-php php');
        header('Content-Disposition: attachment; filename="banned_ip.cfg"');
        $bans = $GLOBALS['PDO']->query(
            "SELECT ip FROM `:prefix_bans` WHERE length = '0' AND RemoveType IS NULL AND type = '1'"
        )->iterate();
        foreach ($bans as $ban) {
            print("addip 0 " . $ban['ip'] . "\r\n");
        }
    }
}
