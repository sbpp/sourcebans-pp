<?php
// SourceBans++ (c) 2014-2026 SourceBans++ Dev Team
// Licensed under the Elastic License 2.0.
// See LICENSE.txt for the full license text and THIRD-PARTY-NOTICES.txt for attributions.

global $userbank, $theme;
if (!defined("IN_SB")) {
    echo "You should not be here. Only follow links!";
    die();
}

/*
 * #1275 — Pattern A (`?section=…` URL routing).
 *
 * Pre-#1275 admin-bans rode the page-level ToC (#1239 / #1207 ADM-3):
 * every section (Add a ban / Ban protests / Ban submissions / Import
 * bans / Group ban) stacked into one DOM and the sticky sidebar
 * emitted `#fragment` anchor jumps. The chrome looked identical to
 * the Pattern A admin sidebars (servers / mods / groups / settings)
 * after #1266's visual unification, but the routing semantics
 * diverged — clicks emitted `#fragment` URLs, scroll position was
 * lost on browser back, and link sharing broke. #1275 unifies on
 * Pattern A so back-button navigation, link sharing, and the
 * per-section testid contract all match the rest of the admin family.
 *
 * Section split — five sections, one render branch each:
 *   - `add-ban`     — Add a ban (the main form)
 *   - `protests`    — Ban protests queue (sub-views: current / archive
 *                     via `?view=archive`)
 *   - `submissions` — Ban submissions queue (same sub-view shape)
 *   - `import`      — Import bans (file upload)
 *   - `group-ban`   — Group ban (Steam community group banning;
 *                     gated on `config.enablegroupbanning`)
 *
 * Sub-view routing inside protests / submissions:
 *
 * Pre-#1275 each of these sections rendered BOTH the current and the
 * archive view simultaneously and a `.chip-row` toggled visibility via
 * `Swap2ndPane()` — a JS helper that lived in `web/scripts/sourcebans.js`
 * and was deleted at #1123 D1, leaving the chips dead. #1275 promotes
 * the sub-view to a real query param (`?section=protests&view=archive`)
 * so the chips become normal anchors, the back button works, and only
 * the active view's data is queried/rendered. The default for both
 * sections is the live queue (`view=current`).
 *
 * Cross-section "Ban from submission" flow:
 *
 * Pre-#1275 the submissions row's "Ban" button called
 * `Actions.BansSetupBan` and `__sbppApplyBanFields(r.data)` to fill
 * the Add Ban form on the same page, then `swapTab(0)` to scroll up.
 * After Pattern A split, the form lives on a different URL — the
 * button now navigates to `?section=add-ban&fromsub=<subid>` and the
 * add-ban section emits a self-contained prefill snippet (alongside
 * the existing `?rebanid` and `?action=pasteBan` shapes) that calls
 * `BansSetupBan` and `__sbppApplyBanFields` after the form mounts.
 *
 * Legacy fragment URLs (`#protests`, `#submissions`, …) are NOT
 * shimmed — browsers don't send fragments to the server, so the
 * page handler can't observe them. The cleanest fallback is to land
 * on the default section and accept that bookmarks lose their
 * anchor. There are no cross-app deep-links to these fragments other
 * than the dashboard cards (which point at `?p=admin&c=bans` with no
 * fragment).
 */

$canAddBan       = $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::AddBan));
$canProtests     = $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::BanProtests));
$canSubmissions  = $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::BanSubmissions));
$canImport       = $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::BanImport));
// #1421 — same feature-toggle gating shape group-ban has carried since
// #1239: the public-facing `?p=protest` / `?p=submit` pages already
// refuse to render when these toggles are off (see page.protest.php
// line 12 / page.submit.php line 29), but the admin moderation
// queues stayed reachable. Mirror the group-ban contract so the
// toggles drop both the sidebar entry and the section body.
$groupBanEnabled = Config::getBool('config.enablegroupbanning');
$protestEnabled  = Config::getBool('config.enableprotest');
$submitEnabled   = Config::getBool('config.enablesubmit');
$canGroupBan     = $canAddBan && $groupBanEnabled;

/*
 * Top-of-page side effects: toasts for delete/unban redirects and the
 * file-upload `importBans` POST. These run regardless of section
 * because the redirects are out-of-band (banlist row -> "deleted" /
 * "unbanned" toast on bans landing page) and the POST has to hit its
 * dedicated section anyway. Run them before the section body so any
 * echo'd toast lands above the page content.
 */
if (isset($_GET['mode']) && $_GET['mode'] == "delete") {
    echo "<script>sb.message.show('Ban Deleted', 'The ban has been deleted from SourceBans', 'green', '', true);</script>";
} elseif (isset($_GET['mode']) && $_GET['mode']=="unban") {
    echo "<script>sb.message.show('Player Unbanned', 'The Player has been unbanned from SourceBans', 'green', '', true);</script>";
}

if (isset($GLOBALS['IN_ADMIN'])) {
    define('CUR_AID', $userbank->GetAid());
}

if (isset($_POST['action']) && $_POST['action'] == "importBans") {
    $bannedcfg = file($_FILES["importFile"]["tmp_name"]);
    $bancnt    = 0;
    // #1420 follow-up #2: track lines we couldn't import so the
    // operator gets actionable feedback in the success toast instead
    // of silently dropping a malformed row. Pre-fix a single bogus
    // `banid 0 STEAM_INVALID` line in the operator's `banned_user.cfg`
    // would have raised `Exception('Invalid SteamID input!')` from
    // `SteamID::toSteam2()` — the import aborted mid-file with a 500
    // page render and the operator had no idea which line broke or
    // how many of the preceding lines committed (the foreach inserts
    // were not wrapped in a transaction).
    $skipped   = 0;

    foreach ($bannedcfg as $ban) {
        $line = explode(" ", trim($ban));

        // Skip ill-formed lines (comments, blanks, truncated rows).
        // The legacy format is `addip <duration> <ip>` / `banid
        // <duration> <STEAMID>`, three space-separated tokens minimum.
        // Pre-fix this could land on undefined-index warnings or a
        // PHP type error inside `filter_var` / `toSteam2`.
        if (count($line) < 3) {
            continue;
        }

        if ($line[0] === 'addip') {
            if (filter_var($line[2], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $GLOBALS['PDO']->query("SELECT ip FROM `:prefix_bans` WHERE ip = :ip AND RemoveType IS NULL");
                $GLOBALS['PDO']->bind(':ip', $line[2]);
                $check = $GLOBALS['PDO']->single();

                if (!$check) {
                    $bancnt++;

                    $GLOBALS['PDO']->query(
                        "INSERT INTO `:prefix_bans` (`created`, `authid`, `ip`, `name`, `ends`, `length`, `reason`, `aid`, `adminIp`, `type`)
                        VALUES (UNIX_TIMESTAMP(), '', :ip, 'Imported Ban', (UNIX_TIMESTAMP() + 0), 0, 'banned_ip.cfg import', :aid, :admip, :btype)"
                    );
                    $GLOBALS['PDO']->bindMultiple([
                        ':ip' => $line[2],
                        ':aid' => $userbank->GetAid(),
                        ':admip' => $_SERVER['REMOTE_ADDR'],
                        ':btype' => BanType::Ip->value,
                    ]);
                    $GLOBALS['PDO']->execute();
                }
            } else {
                $skipped++;
            }
        } elseif ($line[0] === 'banid') {
            // #1420 follow-up #2 — validate the raw Steam ID shape
            // BEFORE the `SteamID::toSteam2()` conversion. Pre-fix the
            // converter ran on `$line[2]` (the third whitespace token
            // of a `banid …` line in the uploaded `banned_user.cfg`)
            // unconditionally; a malformed Steam ID raised
            // `Exception('Invalid SteamID input!')` from
            // `resolveInputID()`, the exception escaped the page
            // handler unhandled, the import aborted mid-file (no
            // transaction), and the operator got a 500 page render
            // with no signal as to which line broke or how many of
            // the preceding lines committed.
            //
            // The library tightening in follow-up #1 made the throw
            // stricter, which made the abort strictly MORE frequent
            // for any cfg carrying legacy/typo'd rows. Validate-
            // before-convert lets the import skip the bad line and
            // surface a count in the success toast instead.
            if (!\SteamID\SteamID::isValidID($line[2])) {
                $skipped++;
                continue;
            }

            $steam = \SteamID\SteamID::toSteam2($line[2]);

            $GLOBALS['PDO']->query("SELECT authid FROM `:prefix_bans` WHERE authid = :authid AND RemoveType IS NULL");
            $GLOBALS['PDO']->bind(':authid', $steam);
            $check = $GLOBALS['PDO']->single();

            if (!$check) {
                if (!isset($_POST['friendsname']) || $_POST['friendsname'] !== 'on' || ($name = GetCommunityName($steam)) === '') {
                    $name = "Imported Ban";
                }
                $bancnt++;
                $GLOBALS['PDO']->query(
                    "INSERT INTO `:prefix_bans` (`created`, `authid`, `ip`, `name`, `ends`, `length`, `reason`, `aid`, `adminIp`, `type`)
                    VALUES (UNIX_TIMESTAMP(), :authid, '', :name, (UNIX_TIMESTAMP() + 0), 0, 'banned_user.cfg import', :aid, :ip, :btype)"
                );
                $GLOBALS['PDO']->bindMultiple([
                    ':authid' => $steam,
                    ':name' => $name,
                    ':aid' => $userbank->GetAid(),
                    ':ip' => $_SERVER['REMOTE_ADDR'],
                    ':btype' => BanType::Steam->value,
                ]);
                $GLOBALS['PDO']->execute();
            }
        }
    }
    if ($bancnt > 0) {
        Log::add(LogType::Message, "Bans imported", "$bancnt Ban(s) imported");
    }
    // #1420 follow-up #2 — surface skipped-line count alongside the
    // imported count so the operator knows the file had malformed
    // entries. Without this signal a half-bad cfg silently produces a
    // partial import and the operator assumes everything landed.
    // Mirrors the legacy `sb.message.show` shape the rest of this
    // handler uses (the wider toast/sb.message migration is sister
    // scope; this edit stays focused on the validate-before-convert
    // fix).
    $importMsg = "$bancnt ban" . ($bancnt != 1 ? "s have" : " has") . " been imported and posted.";
    if ($skipped > 0) {
        $importMsg .= ' ' . $skipped . ' line' . ($skipped != 1 ? 's were' : ' was') . ' skipped (malformed Steam ID or IP).';
    }
    echo "<script>sb.message.show('Bans Import', '" . addslashes($importMsg) . "', 'green', '');</script>";
}

$validSlugs = ['add-ban', 'protests', 'submissions', 'import', 'group-ban'];
$section    = (string) ($_GET['section'] ?? '');

// Smarter default selection: if the URL carries section-specific
// query params, infer the section so deep links (e.g. the banlist's
// "Reban" → `?p=admin&c=bans&rebanid=…`, or the moderation queue's
// "Ban from submission" cross-section flow) still land on the right
// surface.
if (!in_array($section, $validSlugs, true)) {
    if (isset($_GET['rebanid']) || (isset($_GET['action']) && $_GET['action'] === 'pasteBan') || isset($_GET['fromsub'])) {
        $section = 'add-ban';
    } elseif (isset($_GET['fid'])) {
        $section = 'group-ban';
    } elseif ($canAddBan) {
        $section = 'add-ban';
    } elseif ($canProtests && $protestEnabled) {
        // #1421 — the toggle-paired arms below prefer a WORKING
        // landing surface: if `$canProtests` holds but the feature is
        // off, fall through to `submissions` / `import` / `group-ban`
        // first when any of those are actually reachable so the
        // operator lands on a usable queue. We come back to bare
        // `$canProtests` / `$canSubmissions` (no toggle check) at
        // the tail of the cascade — landing on the disabled-feature
        // stub for a user whose ONLY reachable surface is currently
        // toggled off is more honest and operator-actionable than
        // bouncing them to `add-ban`'s "Access denied" (the stub
        // names the load-bearing setting key; Access denied hides
        // the fact that the feature exists at all).
        $section = 'protests';
    } elseif ($canSubmissions && $submitEnabled) {
        $section = 'submissions';
    } elseif ($canImport) {
        $section = 'import';
    } elseif ($canGroupBan) {
        $section = 'group-ban';
    } elseif ($canProtests) {
        $section = 'protests';
    } elseif ($canSubmissions) {
        $section = 'submissions';
    } else {
        $section = 'add-ban';
    }
}

// ---------------------------------------------------------------- add-ban
if ($section === 'add-ban') {
    /*
     * Self-contained reban / paste-ban / ban-from-submission prefill.
     * All three shapes call `Actions.<Setup>` and pipe the response
     * into the shared `window.__sbppApplyBanFields` helper defined in
     * the section's tail script (same helper sourcebans.js used to
     * provide as `applyBanFields`). `sb.ready` defers the calls until
     * the API client is up.
     */
    if (isset($_GET["rebanid"])) {
        echo '<script type="text/javascript">sb.ready(function(){sb.api.call(Actions.BansPrepareReban,{bid:' . (int) $_GET["rebanid"] . '}).then(function(r){if(r&&r.ok&&r.data&&typeof window.__sbppApplyBanFields==="function")window.__sbppApplyBanFields(r.data);});});</script>';
    }
    if ((isset($_GET['action']) && $_GET['action'] == "pasteBan") && isset($_GET['pName']) && isset($_GET['sid'])) {
        $pNameJs = json_encode((string) $_GET['pName'], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
        echo "<script type=\"text/javascript\">sb.ready(function(){sb.message.show('Loading..','<b>Loading...</b><br><i>Please Wait!</i>','blue','',true);sb.hide('dialog-control');sb.api.call(Actions.BansPaste,{sid:" . (int) $_GET['sid'] . ",name:" . $pNameJs . ",type:0}).then(function(r){if(r&&r.ok&&r.data){if(typeof window.__sbppApplyBanFields==='function')window.__sbppApplyBanFields(r.data);sb.show('dialog-control');sb.hide('dialog-placement');}else if(r&&r.ok===false&&r.error){sb.message.error('Error',r.error.message);sb.show('dialog-control');}});});</script>";
    }
    /*
     * #1275 — "Ban from submission" cross-section prefill. Mirrors
     * the rebanid / pasteBan shape: `?section=add-ban&fromsub=<subid>`
     * dispatches `Actions.BansSetupBan`, fills the form, and the
     * admin can review/edit/submit. The submissions queue's "Ban"
     * button is now a normal anchor to this URL, so clicks are
     * back-button-friendly and the URL is bookmarkable.
     */
    if (isset($_GET['fromsub']) && is_numeric($_GET['fromsub'])) {
        echo '<script type="text/javascript">sb.ready(function(){sb.api.call(Actions.BansSetupBan,{subid:' . (int) $_GET['fromsub'] . '}).then(function(r){if(r&&r.ok&&r.data&&typeof window.__sbppApplyBanFields==="function")window.__sbppApplyBanFields(r.data);});});</script>';
    }

    $customReason = Config::getBool('bans.customreasons')
        ? unserialize((string) Config::get('bans.customreasons'))
        : false;
    /** @var false|list<string> $customReason */

    /*
     * Smart-default pre-fill for SteamID / IP via `?steam=…&type=…`
     * (mirrors the existing `?rebanid=…` / `?action=pasteBan` shapes
     * a few lines above). The public servers list's right-click
     * context menu (restored after #1306) drops admins on
     * `?p=admin&c=bans&section=add-ban&steam=STEAM_…&type=0` to
     * pre-populate the form without firing a JSON action — the form
     * has to be usable on the no-JS path on this surface, so the
     * pre-fill happens server-side via the View DTO rather than
     * through `__sbppApplyBanFields`. Allowed type values are 0
     * (Steam ID) and 1 (IP); anything else falls back to 0 to match
     * the form's default <select> option.
     */
    $prefillSteamRaw = isset($_GET['steam']) ? trim((string) $_GET['steam']) : '';
    $prefillTypeRaw  = isset($_GET['type']) ? (int) $_GET['type'] : 0;
    $prefillNameRaw  = isset($_GET['name']) ? (string) $_GET['name'] : '';
    $prefillSteam    = '';
    $prefillType     = 0;
    if ($prefillSteamRaw !== '') {
        // Allowlist the inbound shape to STEAM_X:Y:Z / [U:1:N] /
        // SteamID64 / dotted IPv4. Anything else is dropped so a
        // hostile / malformed referrer can't smuggle arbitrary text
        // into the form's hidden value before the admin clicks Add.
        // The actual ban validation runs server-side on submit via
        // `Actions.BansAdd`; this is just the pre-fill filter.
        if (preg_match('/^(?:STEAM_[01]:[01]:\d+|\[U:1:\d+\]|\d{17}|\d{1,3}(?:\.\d{1,3}){3})$/', $prefillSteamRaw) === 1) {
            $prefillSteam = $prefillSteamRaw;
            $prefillType  = ($prefillTypeRaw === 1) ? 1 : 0;
        }
    }
    /*
     * Issue #1440 — `?name=<player>` smart-default companion to
     * `?steam=…`. The public servers list's right-click context
     * menu carries the player's display name on `data-name`, so
     * surface it as a URL parameter and pre-fill the Nickname
     * input alongside the SteamID one.
     *
     * Pre-fill sanitisation lives in `Sbpp\Util\PlayerName::sanitisePrefill`
     * — single-source across `admin.bans.php` and the sibling
     * `admin.comms.php` so a future tightening (e.g., adding a
     * new spoofing-vector codepoint to the strip set) lands in
     * one place. See the helper's class docblock for the full
     * contract (strip set, codepoint cap, UTF-8 gate).
     *
     * `prefill_name` is INTENTIONALLY decoupled from `prefill_steam`
     * — they're orthogonal pre-fills, not a gated pair. The context
     * menu always emits both together, but a hand-typed deep-link
     * carrying only `?name=` (without `?steam=`) still pre-fills the
     * Nickname input. Compare `?type=` which DOES gate on a valid
     * steam value (type and steam describe the same row dimension
     * — Steam-ID vs IP — and a type without an identifier is a
     * meaningless pair). The decoupling here is the "name is its
     * own thing" half of the asymmetry.
     */
    $prefillName = \Sbpp\Util\PlayerName::sanitisePrefill($prefillNameRaw);

    \Sbpp\View\Renderer::render($theme, new \Sbpp\View\AdminBansAddView(
        permission_addban: $canAddBan,
        customreason: $customReason,
        prefill_steam: $prefillSteam,
        prefill_type: $prefillType,
        prefill_name: $prefillName,
    ));

    // Tail script: defines `__sbppApplyBanFields` (used by the prefill
    // scripts above) and the legacy `ProcessBan` global (third-party
    // themes still bind `onclick="ProcessBan();"`). The default theme's
    // `page_admin_bans_add.tpl` carries its own self-contained
    // `data-action="addban-submit"` listener that doesn't need
    // `ProcessBan`, but keeping the global preserves theme-fork parity.
    echo <<<'JS'
<script type="text/javascript">
var did = 0;
var dname = "";
function demo(id, name)
{
    did = id;
    dname = name;
    // SECURITY-REVIEW: the original upload filename is untrusted. Render it
    // as text, not HTML, and avoid the removed MooTools `$().setHTML()` API.
    var message = document.getElementById("demo.msg");
    if (message) {
        message.textContent = "Uploaded: " + String(name);
    }
}

function changeReason(szListValue)
{
    $('dreason').style.display = (szListValue == "other" ? "block" : "none");
}


function ProcessBan()
{
    var err = 0;
    var reason = $('listReason')[$('listReason').selectedIndex].value;

    let type = $('type').selectedOptions[0].value;

    if (reason == "other") {
        reason = $('txtReason').value;
    }

    if (!$('nickname').value) {
        $('nick.msg').setHTML('You must enter the nickname of the person you are banning');
        $('nick.msg').setStyle('display', 'block');
        err++;
    } else {
        $('nick.msg').setHTML('');
        $('nick.msg').setStyle('display', 'none');
    }

    if (!/(?:STEAM_[01]:[01]:\d+)|(?:\[U:1:\d+\])|(?:\d{17})/.test($('steam').value) && type == 0) {
        $('steam.msg').setHTML('You must enter a valid STEAM ID or Community ID');
        $('steam.msg').setStyle('display', 'block');
        err++;
    } else {
        $('steam.msg').setHTML('');
        $('steam.msg').setStyle('display', 'none');
    }

    if ($('ip').value.length < 7 && type == 1) {
        $('ip.msg').setHTML('You must enter a valid IP address');
        $('ip.msg').setStyle('display', 'block');
        err++;
    } else {
        $('ip.msg').setHTML('');
        $('ip.msg').setStyle('display', 'none');
    }

    if (!reason) {
        $('reason.msg').setHTML('You must select or enter a reason for this ban.');
        $('reason.msg').setStyle('display', 'block');
        err++;
    } else {
        $('reason.msg').setHTML('');
        $('reason.msg').setStyle('display', 'none');
    }

    if (err) {
        return 0;
    }

    sb.api.call(Actions.BansAdd, {
        nickname: $('nickname').value,
        type:     Number($('type').value),
        steam:    $('steam').value,
        ip:       $('ip').value,
        length:   Number($('banlength').value),
        dfile:    did,
        dname:    dname,
        reason:   reason,
        fromsub:  Number($('fromsub').value || 0),
    }).then(function (r) {
        if (r && r.ok && r.data && r.data.kickit) {
            sb.message.show(
                'Ban Added',
                'The ban has been successfully added<br><iframe id="srvkicker" frameborder="0" width="100%" src="pages/admin.kickit.php?check='
                    + encodeURIComponent(r.data.kickit.check) + '&type=' + encodeURIComponent(r.data.kickit.type) + '"></iframe>',
                'green',
                'index.php?p=admin&c=bans&section=add-ban',
                true
            );
            if (r.data.reload) setTimeout(function () { window.location.href = window.location.href.replace(/[#?].*$/, '') + '?p=admin&c=bans&section=add-ban'; }, 2000);
            return;
        }
        if (!r) return;
        if (r.redirect) return;
        if (r.ok === false) {
            if (r.error) sb.message.error('Error', r.error.message || 'Unknown error');
            return;
        }
        var data = r.data || {};
        if (data.message) {
            sb.message.show(data.message.title, data.message.body, data.message.kind, data.message.redir, data.message.noclose);
        }
        if (data.reload) {
            setTimeout(function () { window.location.href = window.location.href.replace(/[#?].*$/, '') + '?p=admin&c=bans&section=add-ban'; }, 2000);
        }
    });
}

window.__sbppApplyBanFields = function (d) {
    var byId = function (id) { return document.getElementById(id); };
    if (byId('nickname'))   byId('nickname').value   = d.nickname || '';
    if (byId('fromsub'))    byId('fromsub').value    = d.subid    || '';
    if (byId('steam'))      byId('steam').value      = d.steam    || '';
    if (byId('ip'))         byId('ip').value         = d.ip       || '';
    if (byId('txtReason'))  byId('txtReason').value  = '';
    if (byId('demo.msg'))   byId('demo.msg').textContent = '';
    if (typeof window.selectLengthTypeReason === 'function') {
        window.selectLengthTypeReason(d.length || 0, d.type || 0, d.reason || '');
    }
    if (d.demo) {
        if (typeof window.demo === 'function') window.demo(d.demo.filename, d.demo.origname);
        else if (byId('demo.msg')) byId('demo.msg').textContent = String(d.demo.origname || '');
    }
};
</script>
JS;
    return;
}

// ---------------------------------------------------------------- protests
if ($section === 'protests') {
    // #1421 — feature-toggle gate runs BEFORE the permission check so
    // no SQL fires for a disabled section and the message is the
    // operator-actionable one (this is configurable in Settings > Main
    // > Public pages — pointing them at the lever, not just "Access
    // denied"). Mirrors the `group-ban` stub a few branches below.
    if (!$protestEnabled) {
        echo '<div class="card"><div class="card__body"><p class="text-muted m-0">Ban protests are disabled in <strong>config.enableprotest</strong>.</p></div></div>';
        return;
    }
    if (!$canProtests) {
        echo '<div class="card"><div class="card__body"><p class="text-muted m-0">Access denied.</p></div></div>';
        return;
    }

    /*
     * Sub-view chip row — `?view=current` (default) or `?view=archive`.
     * Pre-#1275 these chips called `Swap2ndPane()` (deleted with
     * sourcebans.js at #1123 D1, leaving them dead) to toggle
     * server-rendered hidden divs. Now they're real anchors and the
     * server only renders the active view.
     */
    $protestView = (isset($_GET['view']) && $_GET['view'] === 'archive') ? 'archive' : 'current';
    $currentActive = $protestView === 'current' ? 'true' : 'false';
    $archiveActive = $protestView === 'archive' ? 'true' : 'false';
    echo '<div class="page-section" style="padding-bottom:0">'
        . '<div class="chip-row" role="tablist" aria-label="Protest archive filter" data-testid="protests-archive-tabs" style="margin-bottom:0">'
        . '<a class="chip" data-active="' . $currentActive . '" data-testid="filter-chip-protests-current" role="tab" aria-selected="' . $currentActive . '" href="index.php?p=admin&amp;c=bans&amp;section=protests" title="Show current protests">Current</a>'
        . '<a class="chip" data-active="' . $archiveActive . '" data-testid="filter-chip-protests-archive" role="tab" aria-selected="' . $archiveActive . '" href="index.php?p=admin&amp;c=bans&amp;section=protests&amp;view=archive" title="Show the protest archive">Archive</a>'
        . '</div></div>';

    if ($protestView === 'current') {
        $ItemsPerPage = SB_BANS_PER_PAGE;
        $page         = 1;
        if (isset($_GET['ppage']) && $_GET['ppage'] > 0) {
            $page = (int) $_GET['ppage'];
        }
        $protests       = $GLOBALS['PDO']->query("SELECT * FROM `:prefix_protests` WHERE archiv = '0' ORDER BY pid DESC LIMIT " . (int) (($page - 1) * $ItemsPerPage) . "," . (int) $ItemsPerPage)->resultset();
        $protests_count = $GLOBALS['PDO']->query("SELECT count(pid) AS count FROM `:prefix_protests` WHERE archiv = '0' ORDER BY pid DESC")->single();
        $page_count     = $protests_count['count'];
        $PageStart      = (int) (($page - 1) * $ItemsPerPage);
        $PageEnd        = (int) ($PageStart + $ItemsPerPage);
        if ($PageEnd > $page_count) {
            $PageEnd = $page_count;
        }
        // Pagination URLs carry `&section=protests` so prev/next stays
        // on the section. Pre-#1275 they used `#^1` fragment anchors
        // for the (now-defunct) Swap2ndPane scroll target.
        $prev = $page > 1
            ? CreateLinkR('<i class="fas fa-arrow-left fa-lg"></i> prev', "index.php?p=admin&c=bans&section=protests&ppage=" . ($page - 1))
            : "";
        $next = $PageEnd < $page_count
            ? CreateLinkR('next <i class="fas fa-arrow-right fa-lg"></i>', "index.php?p=admin&c=bans&section=protests&ppage=" . ($page + 1))
            : "";

        $page_nav = 'displaying&nbsp;' . $PageStart . '&nbsp;-&nbsp;' . $PageEnd . '&nbsp;of&nbsp;' . $page_count . '&nbsp;results';
        if ($prev !== '') { $page_nav .= ' | <b>' . $prev . '</b>'; }
        if ($next !== '') { $page_nav .= ' | <b>' . $next . '</b>'; }

        $pages = ceil($page_count / $ItemsPerPage);
        if ($pages > 1) {
            $page_nav .= '&nbsp;<select onchange="if(this.value!==\'0\')window.location.href=\'index.php?p=admin&c=bans&section=protests&ppage=\'+this.value;" aria-label="Jump to page">';
            for ($i = 1; $i <= $pages; $i++) {
                if ($i == $page) {
                    $page_nav .= '<option value="' . $i . '" selected="selected">' . $i . '</option>';
                    continue;
                }
                $page_nav .= '<option value="' . $i . '">' . $i . '</option>';
            }
            $page_nav .= '</select>';
        }

        $delete       = [];
        $protest_list = [];

        $protestBids = array_map(static fn ($p) => (int) $p['bid'], $protests);
        $protestBanDetailsByBid = [];
        if ($protestBids !== []) {
            $banRows = $GLOBALS['PDO']->resultsetInList(
                "SELECT bid, ba.ip, ba.authid, ba.name, created, ends, length, reason, ba.aid, ba.sid AS ba_sid, email, ad.user, CONCAT(se.ip,':',se.port) AS server_addr, se.sid AS se_sid
                 FROM `:prefix_bans` AS ba
                 LEFT JOIN `:prefix_admins` AS ad ON ba.aid = ad.aid
                 LEFT JOIN `:prefix_servers` AS se ON se.sid = ba.sid
                 WHERE bid IN (",
                $protestBids,
                ')',
            );
            foreach ($banRows as $banRow) {
                $protestBanDetailsByBid[(int) $banRow['bid']] = $banRow;
            }
        }

        $protestPids = array_map(static fn ($p) => (int) $p['pid'], $protests);
        $protestCommentsByPid = [];
        if ($protestPids !== []) {
            $cRows = $GLOBALS['PDO']->resultsetInList(
                "SELECT bid, cid, aid, commenttxt, added, edittime,
                    (SELECT user FROM `:prefix_admins` WHERE aid = C.aid) AS comname,
                    (SELECT user FROM `:prefix_admins` WHERE aid = C.editaid) AS editname
                 FROM `:prefix_comments` AS C
                 WHERE type = 'P' AND bid IN (",
                $protestPids,
                ') ORDER BY added desc',
            );
            foreach ($cRows as $cRow) {
                $protestCommentsByPid[(int) $cRow['bid']][] = $cRow;
            }
        }

        foreach ($protests as $prot) {
            $prot['reason'] = wordwrap(htmlspecialchars($prot['reason']), 55, "<br />\n", true);
            $protestb = $protestBanDetailsByBid[(int) $prot['bid']] ?? null;
            if (!$protestb) {
                $delete[] = $prot['bid'];
                continue;
            }

            $prot['name']   = $protestb['name'];
            $prot['authid'] = $protestb['authid'];
            $prot['ip']     = $protestb['ip'];

            $prot['date'] = Config::time($protestb['created']);
            $prot['ends'] = $protestb['ends'] == 'never' ? 'never' : Config::time($protestb['ends']);
            $prot['ban_reason'] = htmlspecialchars($protestb['reason']);
            $prot['admin']      = $protestb['user'];
            $prot['server']     = $protestb['server_addr'] ? $protestb['server_addr'] : "Web Ban";
            $prot['datesubmitted'] = Config::time($prot['datesubmitted']);

            $commentres = $protestCommentsByPid[(int) $prot['pid']] ?? [];
            $prot['commentdata'] = bansBuildComments($commentres, $userbank, (int) $prot['pid'], 'P');
            $prot['protaddcomment'] = CreateLinkR('<i class="fas fa-comment-dots fa-lg"></i> Add Comment', 'index.php?p=banlist&comment=' . (int) $prot['pid'] . '&ctype=P');

            array_push($protest_list, $prot);
        }
        if (count($delete) > 0) {
            $cnt = count($delete);
            $GLOBALS['PDO']->executeInList(
                "UPDATE `:prefix_protests` SET archiv = '2' WHERE bid IN(",
                $delete,
                ") LIMIT $cnt",
            );
        }

        \Sbpp\View\Renderer::render($theme, new \Sbpp\View\AdminBansProtestsView(
            permission_protests: $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::BanProtests)),
            permission_editban: $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::EditAllBans, WebPermission::EditGroupBans, WebPermission::EditOwnBans)),
            protest_nav: $page_nav,
            protest_list: $protest_list,
            protest_count: (int) $page_count - (isset($cnt) ? $cnt : 0),
        ));
    } else {
        // archived protests
        $ItemsPerPage = SB_BANS_PER_PAGE;
        $page         = 1;
        if (isset($_GET['papage']) && $_GET['papage'] > 0) {
            $page = (int) $_GET['papage'];
        }
        $protestsarchiv       = $GLOBALS['PDO']->query("SELECT p.*, (SELECT user FROM `:prefix_admins` WHERE aid = p.archivedby) AS archivedby FROM `:prefix_protests` p WHERE archiv > '0' ORDER BY pid DESC LIMIT " . (int) (($page - 1) * $ItemsPerPage) . "," . (int) $ItemsPerPage)->resultset();
        $protestsarchiv_count = $GLOBALS['PDO']->query("SELECT count(pid) AS count FROM `:prefix_protests` WHERE archiv > '0' ORDER BY pid DESC")->single();
        $page_count           = $protestsarchiv_count['count'];
        $PageStart            = (int) (($page - 1) * $ItemsPerPage);
        $PageEnd              = (int) ($PageStart + $ItemsPerPage);
        if ($PageEnd > $page_count) {
            $PageEnd = $page_count;
        }
        $prev = $page > 1
            ? CreateLinkR('<i class="fas fa-arrow-left fa-lg"></i> prev', "index.php?p=admin&c=bans&section=protests&view=archive&papage=" . ($page - 1))
            : "";
        $next = $PageEnd < $page_count
            ? CreateLinkR('next <i class="fas fa-arrow-right fa-lg"></i>', "index.php?p=admin&c=bans&section=protests&view=archive&papage=" . ($page + 1))
            : "";

        $page_nav = 'displaying&nbsp;' . $PageStart . '&nbsp;-&nbsp;' . $PageEnd . '&nbsp;of&nbsp;' . $page_count . '&nbsp;results';
        if ($prev !== '') { $page_nav .= ' | <b>' . $prev . '</b>'; }
        if ($next !== '') { $page_nav .= ' | <b>' . $next . '</b>'; }

        $pages = ceil($page_count / $ItemsPerPage);
        if ($pages > 1) {
            $page_nav .= '&nbsp;<select onchange="if(this.value!==\'0\')window.location.href=\'index.php?p=admin&c=bans&section=protests&view=archive&papage=\'+this.value;" aria-label="Jump to page">';
            for ($i = 1; $i <= $pages; $i++) {
                if ($i == $page) {
                    $page_nav .= '<option value="' . $i . '" selected="selected">' . $i . '</option>';
                    continue;
                }
                $page_nav .= '<option value="' . $i . '">' . $i . '</option>';
            }
            $page_nav .= '</select>';
        }

        $protest_list_archiv = [];

        $protestArchivBids = [];
        foreach ($protestsarchiv as $prot) {
            if ($prot['archiv'] != "2") {
                $protestArchivBids[] = (int) $prot['bid'];
            }
        }
        $protestArchivBanDetailsByBid = [];
        if ($protestArchivBids !== []) {
            $banRows = $GLOBALS['PDO']->resultsetInList(
                "SELECT bid, ba.ip, ba.authid, ba.name, created, ends, length, reason, ba.aid, ba.sid AS ba_sid, email, ad.user, CONCAT(se.ip,':',se.port) AS server_addr, se.sid AS se_sid
                 FROM `:prefix_bans` AS ba
                 LEFT JOIN `:prefix_admins` AS ad ON ba.aid = ad.aid
                 LEFT JOIN `:prefix_servers` AS se ON se.sid = ba.sid
                 WHERE bid IN (",
                $protestArchivBids,
                ')',
            );
            foreach ($banRows as $banRow) {
                $protestArchivBanDetailsByBid[(int) $banRow['bid']] = $banRow;
            }
        }

        $protestArchivPids = array_map(static fn ($p) => (int) $p['pid'], $protestsarchiv);
        $protestArchivCommentsByPid = [];
        if ($protestArchivPids !== []) {
            $cRows = $GLOBALS['PDO']->resultsetInList(
                "SELECT bid, cid, aid, commenttxt, added, edittime,
                    (SELECT user FROM `:prefix_admins` WHERE aid = C.aid) AS comname,
                    (SELECT user FROM `:prefix_admins` WHERE aid = C.editaid) AS editname
                 FROM `:prefix_comments` AS C
                 WHERE type = 'P' AND bid IN (",
                $protestArchivPids,
                ') ORDER BY added desc',
            );
            foreach ($cRows as $cRow) {
                $protestArchivCommentsByPid[(int) $cRow['bid']][] = $cRow;
            }
        }

        $protestArchivToMarkDeleted = [];
        foreach ($protestsarchiv as $prot) {
            $prot['reason'] = wordwrap(htmlspecialchars($prot['reason']), 55, "<br />\n", true);
            if ($prot['archiv'] != "2") {
                $protestb = $protestArchivBanDetailsByBid[(int) $prot['bid']] ?? null;
                if (!$protestb) {
                    $protestArchivToMarkDeleted[] = (int) $prot['pid'];
                    $prot['archiv']  = "2";
                    $prot['archive'] = "ban has been deleted.";
                } else {
                    $prot['name']   = $protestb['name'];
                    $prot['authid'] = $protestb['authid'];
                    $prot['ip']     = $protestb['ip'];
                    $prot['date']   = Config::time($protestb['created']);
                    $prot['ends']   = $protestb['ends'] == 'never' ? 'never' : Config::time($protestb['ends']);
                    $prot['ban_reason'] = htmlspecialchars($protestb['reason']);
                    $prot['admin']      = $protestb['user'];
                    $prot['server']     = $protestb['server_addr'] ? $protestb['server_addr'] : "Web Ban";
                    if ($prot['archiv'] == "1") {
                        $prot['archive'] = "protest has been archived.";
                    } elseif ($prot['archiv'] == "3") {
                        $prot['archive'] = "ban has expired.";
                    } elseif ($prot['archiv'] == "4") {
                        $prot['archive'] = "ban has been unbanned.";
                    }
                }
            } else {
                $prot['archive'] = "ban has been deleted.";
            }
            $prot['datesubmitted'] = Config::time($prot['datesubmitted']);

            $commentres = $protestArchivCommentsByPid[(int) $prot['pid']] ?? [];
            $prot['commentdata'] = bansBuildComments($commentres, $userbank, (int) $prot['pid'], 'P');
            $prot['protaddcomment'] = CreateLinkR('<i class="fas fa-comment-dots fa-lg"></i> Add Comment', 'index.php?p=banlist&comment=' . (int) $prot['pid'] . '&ctype=P');

            array_push($protest_list_archiv, $prot);
        }
        if ($protestArchivToMarkDeleted !== []) {
            $GLOBALS['PDO']->executeInList(
                "UPDATE `:prefix_protests` SET archiv = '2' WHERE pid IN (",
                $protestArchivToMarkDeleted,
                ')',
            );
        }

        \Sbpp\View\Renderer::render($theme, new \Sbpp\View\AdminBansProtestsArchivView(
            permission_protests: $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::BanProtests)),
            permission_editban: $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::EditAllBans, WebPermission::EditGroupBans, WebPermission::EditOwnBans)),
            aprotest_nav: $page_nav,
            protest_list_archiv: $protest_list_archiv,
            protest_count_archiv: (int) $page_count,
        ));
    }
    return;
}

// ---------------------------------------------------------------- submissions
if ($section === 'submissions') {
    // #1421 — same shape as the protests gate above. The feature-flag
    // check runs first so we never hit the `:prefix_submissions` SELECT
    // on a disabled install and the message points at the toggle key.
    if (!$submitEnabled) {
        echo '<div class="card"><div class="card__body"><p class="text-muted m-0">Ban submissions are disabled in <strong>config.enablesubmit</strong>.</p></div></div>';
        return;
    }
    if (!$canSubmissions) {
        echo '<div class="card"><div class="card__body"><p class="text-muted m-0">Access denied.</p></div></div>';
        return;
    }

    $submissionView = (isset($_GET['view']) && $_GET['view'] === 'archive') ? 'archive' : 'current';
    $currentActive = $submissionView === 'current' ? 'true' : 'false';
    $archiveActive = $submissionView === 'archive' ? 'true' : 'false';
    echo '<div class="page-section" style="padding-bottom:0">'
        . '<div class="chip-row" role="tablist" aria-label="Submission archive filter" data-testid="submissions-archive-tabs" style="margin-bottom:0">'
        . '<a class="chip" data-active="' . $currentActive . '" data-testid="filter-chip-submissions-current" role="tab" aria-selected="' . $currentActive . '" href="index.php?p=admin&amp;c=bans&amp;section=submissions" title="Show current submissions">Current</a>'
        . '<a class="chip" data-active="' . $archiveActive . '" data-testid="filter-chip-submissions-archive" role="tab" aria-selected="' . $archiveActive . '" href="index.php?p=admin&amp;c=bans&amp;section=submissions&amp;view=archive" title="Show the submission archive">Archive</a>'
        . '</div></div>';

    if ($submissionView === 'current') {
        $ItemsPerPage = SB_BANS_PER_PAGE;
        $page         = 1;
        if (isset($_GET['spage']) && $_GET['spage'] > 0) {
            $page = (int) $_GET['spage'];
        }
        $submissions       = $GLOBALS['PDO']->query("SELECT * FROM `:prefix_submissions` WHERE archiv = '0' ORDER BY subid DESC LIMIT " . (int) (($page - 1) * $ItemsPerPage) . "," . (int) $ItemsPerPage)->resultset();
        $submissions_count = $GLOBALS['PDO']->query("SELECT count(subid) AS count FROM `:prefix_submissions` WHERE archiv = '0' ORDER BY subid DESC")->single();
        $page_count        = $submissions_count['count'];
        $PageStart         = (int) (($page - 1) * $ItemsPerPage);
        $PageEnd           = (int) ($PageStart + $ItemsPerPage);
        if ($PageEnd > $page_count) {
            $PageEnd = $page_count;
        }
        $prev = $page > 1
            ? CreateLinkR('<i class="fas fa-arrow-left fa-lg"></i> prev', "index.php?p=admin&c=bans&section=submissions&spage=" . ($page - 1))
            : "";
        $next = $PageEnd < $page_count
            ? CreateLinkR('next <i class="fas fa-arrow-right fa-lg"></i>', "index.php?p=admin&c=bans&section=submissions&spage=" . ($page + 1))
            : "";

        $page_nav = 'displaying&nbsp;' . $PageStart . '&nbsp;-&nbsp;' . $PageEnd . '&nbsp;of&nbsp;' . $page_count . '&nbsp;results';
        if ($prev !== '') { $page_nav .= ' | <b>' . $prev . '</b>'; }
        if ($next !== '') { $page_nav .= ' | <b>' . $next . '</b>'; }

        $pages = ceil($page_count / $ItemsPerPage);
        if ($pages > 1) {
            $page_nav .= '&nbsp;<select onchange="if(this.value!==\'0\')window.location.href=\'index.php?p=admin&c=bans&section=submissions&spage=\'+this.value;" aria-label="Jump to page">';
            for ($i = 1; $i <= $pages; $i++) {
                if ($i == $page) {
                    $page_nav .= '<option value="' . $i . '" selected="selected">' . $i . '</option>';
                    continue;
                }
                $page_nav .= '<option value="' . $i . '">' . $i . '</option>';
            }
            $page_nav .= '</select>';
        }

        $submission_list = [];

        $submissionSubids = array_map(static fn ($s) => (int) $s['subid'], $submissions);

        $submissionDemoFilenameBySubid = [];
        if ($submissionSubids !== []) {
            $demRows = $GLOBALS['PDO']->resultsetInList(
                "SELECT demid, filename FROM `:prefix_demos` WHERE demtype = 'S' AND demid IN (",
                $submissionSubids,
                ')',
            );
            foreach ($demRows as $demRow) {
                $submissionDemoFilenameBySubid[(int) $demRow['demid']] = $demRow['filename'];
            }
        }

        $submissionModIds = [];
        foreach ($submissions as $sub) {
            $submissionModIds[(int) $sub['ModID']] = true;
        }
        $submissionModNameById = [];
        if ($submissionModIds !== []) {
            $modIds  = array_keys($submissionModIds);
            $modRows = $GLOBALS['PDO']->resultsetInList(
                'SELECT mid, name FROM `:prefix_mods` WHERE mid IN (',
                $modIds,
                ')',
            );
            foreach ($modRows as $modRow) {
                $submissionModNameById[(int) $modRow['mid']] = $modRow['name'];
            }
        }

        $submissionCommentsBySubid = [];
        if ($submissionSubids !== []) {
            $cRows = $GLOBALS['PDO']->resultsetInList(
                "SELECT bid, cid, aid, commenttxt, added, edittime,
                    (SELECT user FROM `:prefix_admins` WHERE aid = C.aid) AS comname,
                    (SELECT user FROM `:prefix_admins` WHERE aid = C.editaid) AS editname
                 FROM `:prefix_comments` AS C
                 WHERE type = 'S' AND bid IN (",
                $submissionSubids,
                ') ORDER BY added desc',
            );
            foreach ($cRows as $cRow) {
                $submissionCommentsBySubid[(int) $cRow['bid']][] = $cRow;
            }
        }

        foreach ($submissions as $sub) {
            $sub['name']   = wordwrap(htmlspecialchars($sub['name']), 55, "<br />", true);
            $sub['reason'] = wordwrap(htmlspecialchars($sub['reason']), 55, "<br />", true);

            $demoFilename = $submissionDemoFilenameBySubid[(int) $sub['subid']] ?? null;
            $sub['demo'] = (!empty($demoFilename) && @file_exists(SB_DEMOS . "/" . $demoFilename))
                ? '<a href="getdemo.php?id=' . urlencode($sub['subid']) . '&type=S"><i class=\'fas fa-video fa-lg\'></i> Get Demo</a>'
                : "<a href=\"#\"><i class='fas fa-video-slash fa-lg'></i> No Demo</a>";

            $sub['submitted'] = Config::time($sub['submitted']);

            $sub['mod'] = $submissionModNameById[(int) $sub['ModID']] ?? null;
            $sub['hostname'] = empty($sub['server']) ? '<i><font color="#677882">Other server...</font></i>' : "";

            $commentres = $submissionCommentsBySubid[(int) $sub['subid']] ?? [];
            $sub['commentdata'] = bansBuildComments($commentres, $userbank, (int) $sub['subid'], 'S');
            $sub['subaddcomment'] = CreateLinkR('<i class="fas fa-comment-dots fa-lg"></i> Add Comment', 'index.php?p=banlist&comment=' . (int) $sub['subid'] . '&ctype=S');

            array_push($submission_list, $sub);
        }
        \Sbpp\View\Renderer::render($theme, new \Sbpp\View\AdminBansSubmissionsView(
            permissions_submissions: $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::BanSubmissions)),
            permissions_editsub: $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::EditAllBans, WebPermission::EditGroupBans, WebPermission::EditOwnBans)),
            submission_count: (int) $page_count,
            submission_nav: $page_nav,
            submission_list: $submission_list,
        ));
    } else {
        // submission archive
        $ItemsPerPage = SB_BANS_PER_PAGE;
        $page         = 1;
        if (isset($_GET['sapage']) && $_GET['sapage'] > 0) {
            $page = (int) $_GET['sapage'];
        }
        $submissionsarchiv       = $GLOBALS['PDO']->query("SELECT s.*, (SELECT user FROM `:prefix_admins` WHERE aid = s.archivedby) AS archivedby FROM `:prefix_submissions` s WHERE archiv > '0' ORDER BY subid DESC LIMIT " . (int) (($page - 1) * $ItemsPerPage) . "," . (int) $ItemsPerPage)->resultset();
        $submissionsarchiv_count = $GLOBALS['PDO']->query("SELECT count(subid) AS count FROM `:prefix_submissions` WHERE archiv > '0' ORDER BY subid DESC")->single();
        $page_count              = $submissionsarchiv_count['count'];
        $PageStart               = (int) (($page - 1) * $ItemsPerPage);
        $PageEnd                 = (int) ($PageStart + $ItemsPerPage);
        if ($PageEnd > $page_count) {
            $PageEnd = $page_count;
        }
        $prev = $page > 1
            ? CreateLinkR('<i class="fas fa-arrow-left fa-lg"></i> prev', "index.php?p=admin&c=bans&section=submissions&view=archive&sapage=" . ($page - 1))
            : "";
        $next = $PageEnd < $page_count
            ? CreateLinkR('next <i class="fas fa-arrow-right fa-lg"></i>', "index.php?p=admin&c=bans&section=submissions&view=archive&sapage=" . ($page + 1))
            : "";

        $page_nav = 'displaying&nbsp;' . $PageStart . '&nbsp;-&nbsp;' . $PageEnd . '&nbsp;of&nbsp;' . $page_count . '&nbsp;results';
        if ($prev !== '') { $page_nav .= ' | <b>' . $prev . '</b>'; }
        if ($next !== '') { $page_nav .= ' | <b>' . $next . '</b>'; }

        $pages = ceil($page_count / $ItemsPerPage);
        if ($pages > 1) {
            $page_nav .= '&nbsp;<select onchange="if(this.value!==\'0\')window.location.href=\'index.php?p=admin&c=bans&section=submissions&view=archive&sapage=\'+this.value;" aria-label="Jump to page">';
            for ($i = 1; $i <= $pages; $i++) {
                if ($i == $page) {
                    $page_nav .= '<option value="' . $i . '" selected="selected">' . $i . '</option>';
                    continue;
                }
                $page_nav .= '<option value="' . $i . '">' . $i . '</option>';
            }
            $page_nav .= '</select>';
        }

        $submission_list_archiv = [];

        $submissionArchivSubids = array_map(static fn ($s) => (int) $s['subid'], $submissionsarchiv);

        $submissionArchivDemoFilenameBySubid = [];
        if ($submissionArchivSubids !== []) {
            $demRows = $GLOBALS['PDO']->resultsetInList(
                "SELECT demid, filename FROM `:prefix_demos` WHERE demtype = 'S' AND demid IN (",
                $submissionArchivSubids,
                ')',
            );
            foreach ($demRows as $demRow) {
                $submissionArchivDemoFilenameBySubid[(int) $demRow['demid']] = $demRow['filename'];
            }
        }

        $submissionArchivModIds = [];
        foreach ($submissionsarchiv as $sub) {
            $submissionArchivModIds[(int) $sub['ModID']] = true;
        }
        $submissionArchivModNameById = [];
        if ($submissionArchivModIds !== []) {
            $modIds  = array_keys($submissionArchivModIds);
            $modRows = $GLOBALS['PDO']->resultsetInList(
                'SELECT mid, name FROM `:prefix_mods` WHERE mid IN (',
                $modIds,
                ')',
            );
            foreach ($modRows as $modRow) {
                $submissionArchivModNameById[(int) $modRow['mid']] = $modRow['name'];
            }
        }

        $submissionArchivCommentsBySubid = [];
        if ($submissionArchivSubids !== []) {
            $cRows = $GLOBALS['PDO']->resultsetInList(
                "SELECT bid, cid, aid, commenttxt, added, edittime,
                    (SELECT user FROM `:prefix_admins` WHERE aid = C.aid) AS comname,
                    (SELECT user FROM `:prefix_admins` WHERE aid = C.editaid) AS editname
                 FROM `:prefix_comments` AS C
                 WHERE type = 'S' AND bid IN (",
                $submissionArchivSubids,
                ') ORDER BY added desc',
            );
            foreach ($cRows as $cRow) {
                $submissionArchivCommentsBySubid[(int) $cRow['bid']][] = $cRow;
            }
        }

        foreach ($submissionsarchiv as $sub) {
            $sub['name']   = wordwrap(htmlspecialchars($sub['name']), 55, "<br />", true);
            $sub['reason'] = wordwrap(htmlspecialchars($sub['reason']), 55, "<br />", true);

            $demoFilename = $submissionArchivDemoFilenameBySubid[(int) $sub['subid']] ?? null;
            $sub['demo'] = (!empty($demoFilename) && @file_exists(SB_DEMOS . "/" . $demoFilename))
                ? '<a href="getdemo.php?id=' . urlencode($sub['subid']) . '&type=S"><i class=\'fas fa-video fa-lg\'></i> Get Demo</a>'
                : "<a href=\"#\"><i class='fas fa-video-slash fa-lg'></i> No Demo</a>";

            $sub['submitted'] = Config::time($sub['submitted']);

            $sub['mod'] = $submissionArchivModNameById[(int) $sub['ModID']] ?? null;
            $sub['hostname'] = empty($sub['server']) ? '<i><font color="#677882">Other server...</font></i>' : "";
            if ($sub['archiv'] == "3") {
                $sub['archive'] = "player has been banned.";
            } elseif ($sub['archiv'] == "2") {
                $sub['archive'] = "submission has been accepted.";
            } elseif ($sub['archiv'] == "1") {
                $sub['archive'] = "submission has been archived.";
            }

            $commentres = $submissionArchivCommentsBySubid[(int) $sub['subid']] ?? [];
            $sub['commentdata'] = bansBuildComments($commentres, $userbank, (int) $sub['subid'], 'S');
            $sub['subaddcomment'] = CreateLinkR('<i class="fas fa-comment-dots fa-lg"></i> Add Comment', 'index.php?p=banlist&comment=' . (int) $sub['subid'] . '&ctype=S');

            array_push($submission_list_archiv, $sub);
        }
        \Sbpp\View\Renderer::render($theme, new \Sbpp\View\AdminBansSubmissionsArchivView(
            permissions_submissions: $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::BanSubmissions)),
            permissions_editsub: $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::EditAllBans, WebPermission::EditGroupBans, WebPermission::EditOwnBans)),
            submission_count_archiv: (int) $page_count,
            asubmission_nav: $page_nav,
            submission_list_archiv: $submission_list_archiv,
        ));
    }
    return;
}

// ---------------------------------------------------------------- import
if ($section === 'import') {
    if (!$canImport) {
        echo '<div class="card"><div class="card__body"><p class="text-muted m-0">Access denied.</p></div></div>';
        return;
    }
    \Sbpp\View\Renderer::render($theme, new \Sbpp\View\AdminBansImportView(
        permission_import: true,
        extreq: ini_get('safe_mode') != 1,
    ));
    return;
}

// ---------------------------------------------------------------- group-ban
// At this point `$section` is structurally guaranteed to be 'group-ban'
// (every other slug in `$validSlugs` has its own `if` branch above and
// each one returns; the default-section guard above narrows `$section`
// to a member of `$validSlugs`). PHPStan flags the redundant
// `if ($section === 'group-ban')` wrapper as `identical.alwaysTrue`,
// so we emit the section directly. If a new slug ever lands in
// `$validSlugs`, the test suite catches the mismatch (the responsive
// admin-tabs spec enumerates the slug list against the rendered
// sidebar).
if (!$canGroupBan) {
    echo '<div class="card"><div class="card__body"><p class="text-muted m-0">'
        . (!$canAddBan ? 'Access denied.' : 'Group banning is disabled in <strong>config.enablegroupbanning</strong>.')
        . '</p></div></div>';
    return;
}
\Sbpp\View\Renderer::render($theme, new \Sbpp\View\AdminBansGroupsView(
    permission_addban: $canAddBan,
    groupbanning_enabled: $groupBanEnabled,
    list_steam_groups: isset($_GET['fid']) ? (string) $_GET['fid'] : false,
    // `player_name` is rendered next to the steam-groups list when an
    // admin reaches Group Ban via "Ban groups of player X" from the
    // banlist (?fid=…). The pre-v2.0.0 template emitted `{$player_name}`
    // unguarded but no caller ever assigned it; we pass an empty
    // string so the SmartyTemplateRule contract holds and the
    // template can render the placeholder when wired up.
    player_name: '',
));
// #1402: page-tail dispatcher for the group-ban surface. Replaces
// the dead `ProcessGroupBan` / `CheckGroupBan` / `LoadGroupBan` /
// `TickSelectAll` globals (the v1.x sourcebans.js helpers, deleted
// at #1123 D1). The pre-fix `<script>` block here defined
// `ProcessGroupBan` + `CheckGroupBan` but BOTH still called
// `LoadGroupBan(...)` — which lived in the deleted sourcebans.js —
// so every "Add group ban" click threw
// `ReferenceError: LoadGroupBan is not defined`. Same shape on the
// "Tick all" button (`TickSelectAll` was also in sourcebans.js).
//
// The replacement uses the existing `Actions.BansGroupBan` +
// `Actions.BansBanMemberOfGroup` API pair (both already registered
// in `_register.php`; the issue body's suggestion to ship a new
// `Actions.GroupbanCheck` is unnecessary — the existing
// `bans.group_ban` IS the URL-parse step the legacy `LoadGroupBan`
// performed first, and `bans.ban_member_of_group` is the bulk
// banning step it chained to). The page-tail dispatcher binds via
// `data-action="groupban-*"` per the canonical-shape rule from
// AGENTS.md "Add a confirm + reason modal …" — no more legacy
// global helpers in scope.
echo <<<'JS'
<script type="text/javascript">
(function () {
    'use strict';

    function api()     { return (window.sb && window.sb.api) || null; }
    function actions() { return window.Actions || null; }
    /**
     * Local wrapper around window.SBPP.setBusy with a `disabled`-only
     * fallback (mirror of SbppGroupsAddSetBusy in page_admin_groups_add.tpl).
     */
    function setBusy(btn, busy) {
        if (!btn) return;
        var S = window.SBPP;
        if (S && typeof S.setBusy === 'function') S.setBusy(btn, busy);
        else btn.disabled = busy === undefined ? true : !!busy;
    }
    function toast(kind, title, body, redir) {
        var S = window.SBPP;
        if (S && typeof S.showToast === 'function') {
            S.showToast({ kind: kind, title: title, body: body || '' });
        }
        if (redir) {
            // Match the v1.x post-success redirect: the operator wants to
            // see the freshly-populated banlist, not the now-empty form.
            setTimeout(function () { window.location.href = redir; }, 1500);
        }
    }
    function showMsg(id, msg, show) {
        var el = document.getElementById(id);
        if (!el) return;
        el.textContent = msg;
        el.style.display = show ? 'block' : 'none';
    }
    /**
     * Status indicator for the bulk-from-friends path: surfaces the
     * "Banning all members of <grp>" intermediate state while the API
     * fans out across multiple groups. Falls through to a no-op if the
     * #steamGroupStatus div is absent (single-URL submit path).
     */
    function status(html) {
        var el = document.getElementById('steamGroupStatus');
        if (el) el.innerHTML = html;
    }

    /**
     * Wraps the two-step chain that the v1.x `LoadGroupBan(uri, isgrp,
     * queue, reason, last)` helper performed: first parse the URL into
     * a group name (Actions.BansGroupBan), then enumerate + ban the
     * members (Actions.BansBanMemberOfGroup). The `queue` and `last`
     * args drive the post-bulk success toast — `queue==="yes" &&
     * grpurl===last` is the final tick of the bulk loop, so we redirect
     * the operator to the banlist; otherwise we just append to the
     * status panel and let the loop keep firing.
     */
    function loadGroupBan(groupuri, isgrpurl, queue, reason, last, submitBtn) {
        var a = api(), A = actions();
        if (!a || !A) return Promise.resolve();
        // #1402 adversarial review MEDIUM 4: defensive .catch() arms on
        // BOTH the outer Actions.BansGroupBan and inner
        // Actions.BansBanMemberOfGroup chains so a throw inside either
        // success callback (or a sb.api.call internal failure) doesn't
        // leave the submit button busy forever. The legacy single-URL
        // path and the bulk-from-friends loop both share this helper,
        // so a flaky branch in either path is silently captured here.
        return a.call(A.BansGroupBan, {
            groupuri: groupuri,
            isgrpurl: isgrpurl,
            queue:    queue,
            reason:   reason,
            last:     last,
        }).then(function (r) {
            if (!r || r.ok === false || !r.data || !r.data.grpname) {
                setBusy(submitBtn, false);
                var em = (r && r.error && r.error.message) || 'Error parsing the group url.';
                showMsg('groupurl.msg', em, true);
                toast('error', 'Group ban failed', em);
                return;
            }
            var d = r.data;
            // Surface the "Please wait…" toast the legacy helper used
            // to render via $('steamGroupStatus').setHTML(...).
            status('<em>Banning all members of <strong>' +
                String(d.grpname).replace(/[<>&"]/g, function (c) {
                    return { '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' }[c] || c;
                }) + '</strong>&hellip;</em>');

            return a.call(A.BansBanMemberOfGroup, {
                grpurl: d.grpname,
                queue:  d.queue,
                reason: d.reason,
                last:   d.last,
            }).then(function (r2) {
                if (!r2 || r2.ok === false || !r2.data) {
                    setBusy(submitBtn, false);
                    var em2 = (r2 && r2.error && r2.error.message) || 'Failed to ban group members.';
                    toast('error', 'Group ban failed', em2);
                    status('');
                    return;
                }
                var d2 = r2.data;
                var amt = d2.amount || { total: 0, banned: 0, before: 0, failed: 0 };
                // The legacy helper only emitted a final success toast on
                // the last iteration of the bulk loop (and always on the
                // single-URL path). Mirror that contract: queue==='no'
                // is the single-URL path; queue==='yes' && grpurl===last
                // is the final tick.
                if (d2.queue === 'no' || (d2.queue === 'yes' && String(d2.grpurl) === String(d2.last))) {
                    setBusy(submitBtn, false);
                    var body = 'Banned ' + (amt.total - amt.before - amt.failed) + '/' +
                                amt.total + ' players. ' + amt.before +
                                ' were already banned, ' + amt.failed + ' failed.';
                    toast('success', 'Group banned', body, 'index.php?p=banlist');
                    status('<strong>' + body + '</strong>');
                }
            }).catch(function (err2) {
                // Inner-call defensive: release the button + surface
                // the error so a bulk loop doesn't silently stall
                // after one row throws.
                setBusy(submitBtn, false);
                toast('error', 'Group ban failed', String(err2 && err2.message ? err2.message : err2));
                status('');
            });
        }).catch(function (err) {
            // Outer-call defensive: same shape as the inner catch.
            setBusy(submitBtn, false);
            toast('error', 'Group ban failed', String(err && err.message ? err.message : err));
            status('');
        });
    }

    // ---- single-URL submit ----
    document.addEventListener('click', function (e) {
        var t = e.target;
        if (!t || !t.closest) return;
        var btn = t.closest('[data-action="groupban-submit"]');
        if (!btn) return;
        e.preventDefault();
        var urlEl = document.getElementById('groupurl');
        var reasonEl = document.getElementById('groupreason');
        if (!urlEl || !urlEl.value.trim()) {
            showMsg('groupurl.msg', 'You must enter the group link of the group you are banning', true);
            return;
        }
        showMsg('groupurl.msg', '', false);
        setBusy(btn, true);
        loadGroupBan(urlEl.value.trim(), 'no', 'no', reasonEl ? reasonEl.value : '', '', btn);
    });

    // ---- bulk-from-friends submit ----
    document.addEventListener('click', function (e) {
        var t = e.target;
        if (!t || !t.closest) return;
        var btn = t.closest('[data-action="groupban-bulk-submit"]');
        if (!btn) return;
        e.preventDefault();
        var reasonEl = document.getElementById('groupreason');
        var reason = reasonEl ? reasonEl.value : '';
        // Find the last-ticked checkbox; the legacy helper used this
        // sentinel to know which API response should trigger the final
        // success toast (so a 20-group bulk-ban doesn't fire 20 toasts).
        var last = '';
        for (var i = 0; document.getElementById('chkb_' + i); i++) {
            var cb = document.getElementById('chkb_' + i);
            if (cb.checked) last = cb.value;
        }
        if (!last) {
            toast('error', 'No groups selected', 'Tick at least one group to ban.');
            return;
        }
        setBusy(btn, true);
        for (var j = 0; document.getElementById('chkb_' + j); j++) {
            var cb2 = document.getElementById('chkb_' + j);
            if (cb2.checked) {
                loadGroupBan(cb2.value, 'yes', 'yes', reason, last, btn);
            }
        }
    });

    // ---- select-all toggle ----
    document.addEventListener('click', function (e) {
        var t = e.target;
        if (!t || !t.closest) return;
        var btn = t.closest('[data-action="groupban-select-all"]');
        if (!btn) return;
        e.preventDefault();
        var allChecked = true;
        var any = false;
        for (var i = 0; document.getElementById('chkb_' + i); i++) {
            any = true;
            if (!document.getElementById('chkb_' + i).checked) { allChecked = false; break; }
        }
        if (!any) return;
        for (var j = 0; document.getElementById('chkb_' + j); j++) {
            document.getElementById('chkb_' + j).checked = !allChecked;
        }
        var tickBtn = document.getElementById('tickswitch');
        var tickLink = document.getElementById('tickswitchlink');
        if (tickBtn) tickBtn.textContent = allChecked ? '+' : '\u2212';
        if (tickLink) tickLink.textContent = allChecked ? 'Select all' : 'Deselect all';
    });
})();
</script>
JS;

/*
 * Comment-thread builder used by both protests + submissions sections.
 * Consolidated here because the per-section foreach loops in the
 * original file were a verbatim duplicate (the only difference was
 * the `type` argument 'P' vs 'S'). Returns a list<array> ready to
 * splat into the View DTO.
 *
 * @param list<array<string,mixed>> $commentres
 * @return 'None'|list<array<string,mixed>>
 */
function bansBuildComments(
    array $commentres,
    \Sbpp\Auth\UserManager $userbank,
    int $rowId,
    string $type,
): string|array
{
    if (count($commentres) === 0) {
        return "None";
    }

    $comments = [];
    $morecom  = 0;
    foreach ($commentres as $crow) {
        $cdata            = [];
        $cdata['morecom'] = ($morecom == 1 ? true : false);
        if ($crow['aid'] == $userbank->GetAid() || $userbank->HasAccess(WebPermission::Owner)) {
            $cdata['editcomlink'] = CreateLinkR('<i class="fas fa-edit fa-lg"></i>', 'index.php?p=banlist&comment=' . $rowId . '&ctype=' . $type . '&cid=' . $crow['cid'], 'Edit Comment');
            if ($userbank->HasAccess(WebPermission::Owner)) {
                // #1402: see web/scripts/comment-actions.js for the dispatcher.
            // $type is the literal letter 'P' (protests) or 'S' (submissions);
            // the api handler's `ctype` arm consumes both. No paginator on the
            // moderation queues, so data-page is the sentinel -1.
            $cdata['delcomlink'] = '<a href="#" class="tip" title="Delete Comment" target="_self"'
                . ' data-action="comment-delete"'
                . ' data-cid="' . (int) $crow['cid'] . '"'
                . ' data-ctype="' . htmlspecialchars($type, ENT_QUOTES, 'UTF-8') . '"'
                . ' data-page="-1"'
                . '><i class="fas fa-trash fa-lg"></i></a>';
            }
        } else {
            $cdata['editcomlink'] = "";
            $cdata['delcomlink']  = "";
        }

        $cdata['comname']    = $crow['comname'];
        $cdata['added']      = Config::time($crow['added']);
        $commentText         = encodePreservingBr((string) $crow['commenttxt']);
        $commentText         = preg_replace('@(https?://([-\w\.]+)+(:\d+)?(/([\w/_\.]*(\?[^\s<]+)?)?)?)@', '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>', $commentText);
        $cdata['commenttxt'] = $commentText;

        if (!empty($crow['edittime'])) {
            $cdata['edittime'] = Config::time($crow['edittime']);
            $cdata['editname'] = $crow['editname'];
        } else {
            $cdata['edittime'] = "";
            $cdata['editname'] = "";
        }

        $morecom = 1;
        $comments[] = $cdata;
    }
    return $comments;
}
