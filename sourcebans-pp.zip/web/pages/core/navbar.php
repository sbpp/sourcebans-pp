<?php
global $userbank, $theme;

use Sbpp\View\AdminNavCatalog;

$navbar = [
     [
        'title' => 'Dashboard',
        'endpoint' => 'home',
        'description' => 'This page shows an overview of your bans and servers.',
        'permission' => true
    ],
    [
        'title' => 'Servers',
        'endpoint' => 'servers',
        'description' => 'All of your servers and their status can be viewed here.',
        'permission' => true
    ],
    [
        'title' => 'Bans',
        'endpoint' => 'banlist',
        'description' => 'All of the bans in the database can be viewed from here.',
        'permission' => true
    ],
    [
        'title' => 'Comms',
        'endpoint' => 'commslist',
        'description' => 'All of the communication bans (such as chat gags and voice mutes) in the database can be viewed from here.',
        'permission' => Config::getBool('config.enablecomms')
    ],
    [
        'title' => 'Report a Player',
        'endpoint' => 'submit',
        'description' => 'You can submit a demo or screenshot of a suspected cheater here. It will then be up for review by one of the admins.',
        'permission' => Config::getBool('config.enablesubmit')
    ],
    [
        'title' => 'Appeal a Ban',
        'endpoint' => 'protest',
        'description' => 'Here you can appeal your ban. And prove your case as to why you should be unbanned.',
        'permission' => Config::getBool('config.enableprotest')
    ],
    [
        'title' => 'Admin Panel',
        'endpoint' => 'admin',
        'description' => 'This is the control panel for SourceBans where you can setup new admins, add new server, etc.',
        'permission' => $userbank->is_admin()
    ]
];

$admin = [
    [
        'title' => 'Admins',
        'endpoint' => 'admins',
        'permission' => ADMIN_OWNER|ADMIN_LIST_ADMINS|ADMIN_ADD_ADMINS|ADMIN_EDIT_ADMINS|ADMIN_DELETE_ADMINS
    ],
    [
        'title' => 'Servers',
        'endpoint' => 'servers',
        'permission' => ADMIN_OWNER|ADMIN_LIST_SERVERS|ADMIN_ADD_SERVER|ADMIN_EDIT_SERVERS|ADMIN_DELETE_SERVERS
    ],
    [
        'title' => 'Bans',
        'endpoint' => 'bans',
        'permission' => ADMIN_OWNER|ADMIN_ADD_BAN|ADMIN_EDIT_OWN_BANS|ADMIN_EDIT_GROUP_BANS|ADMIN_EDIT_ALL_BANS|ADMIN_BAN_PROTESTS|ADMIN_BAN_SUBMISSIONS
    ],
    [
        'title' => 'Comms',
        'endpoint' => 'comms',
        'permission' => ADMIN_OWNER|ADMIN_ADD_BAN|ADMIN_EDIT_OWN_BANS|ADMIN_EDIT_ALL_BANS
    ],
    [
        'title' => 'Groups',
        'endpoint' => 'groups',
        'permission' => ADMIN_OWNER|ADMIN_LIST_GROUPS|ADMIN_ADD_GROUP|ADMIN_EDIT_GROUPS|ADMIN_DELETE_GROUPS
    ],
    [
        'title' => 'Settings',
        'endpoint' => 'settings',
        'permission' => ADMIN_OWNER|ADMIN_WEB_SETTINGS
    ],
    [
        'title' => 'Mods',
        'endpoint' => 'mods',
        'permission' => ADMIN_OWNER|ADMIN_LIST_MODS|ADMIN_ADD_MODS|ADMIN_EDIT_MODS|ADMIN_DELETE_MODS
    ],
    [
        // Full data export — owner-only (every PII category in scope).
        // Same gate as page-builder.php's `$adminRoutes['export']`
        // entry, the page handler's `CheckAdminAccess(ADMIN_OWNER)`,
        // and the entry point at `web/export.php`.
        'title' => 'Export',
        'endpoint' => 'export',
        'permission' => ADMIN_OWNER
    ]
];

$active    = $_GET['p'] ?? null;
$activeCat = $_GET['c'] ?? null;
foreach ($navbar as $key => $tab) {
    $isActive = ($active === $tab['endpoint']);
    // The 'admin' parent is the leaf only when no sub-route is selected.
    // On ?p=admin&c=<sub> the sub-route's own entry owns the active
    // state; otherwise both rows would carry aria-current="page", which
    // misreports the current location to assistive tech (#1233).
    if ($tab['endpoint'] === 'admin' && $activeCat !== null && $activeCat !== '') {
        $isActive = false;
    }
    $navbar[$key]['state'] = $isActive ? 'active' : 'nonactive';

    if (!$tab['permission']) {
        unset($navbar[$key]);
    }
}

if ($userbank->is_admin()) {
    $cat = $_GET['c'] ?? null;
    $section = (string) ($_GET['section'] ?? '');
    foreach ($admin as $key => $tab) {
        if (!$userbank->HasAccess($tab['permission'])) {
            unset($admin[$key]);
            continue;
        }

        $isCategoryActive = ($cat === $tab['endpoint']);
        $children = AdminNavCatalog::filterForUser(
            AdminNavCatalog::sectionsFor($tab['endpoint']),
            $userbank,
        );

        $childRows = [];
        foreach ($children as $idx => $child) {
            $childActive = $isCategoryActive && (
                $section === $child['slug']
                || ($section === '' && $idx === 0)
            );
            $childRows[] = [
                'slug'  => $child['slug'],
                'name'  => $child['name'],
                'url'   => $child['url'],
                'icon'  => $child['icon'] ?? 'circle-dot',
                'state' => $childActive ? 'active' : '',
            ];
        }

        $admin[$key]['children'] = $childRows;
        $admin[$key]['open'] = $isCategoryActive;
        // Category row itself is never aria-current when children exist;
        // the matching child leaf owns the active state (#1233 / #1490).
        $admin[$key]['state'] = ($isCategoryActive && $childRows === []) ? 'active' : '';
    }
}

$theme->assign('navbar', array_values($navbar));
$theme->assign('adminbar', array_values($admin));
$theme->assign('isAdmin', $userbank->is_admin());
$theme->assign('login', $userbank->is_logged_in());
$theme->assign('username', $userbank->GetProperty("user"));
$theme->display('core/navbar.tpl');
