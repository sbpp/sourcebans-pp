<?php
// SourceBans++ (c) 2014-2026 SourceBans++ Dev Team
// Licensed under the Elastic License 2.0.
// See LICENSE.txt for the full license text and THIRD-PARTY-NOTICES.txt for attributions.

if (!defined("IN_SB")) {
    echo "You should not be here. Only follow links!";
    die();
}
global $userbank, $theme;

/*
 * #1275 — Pattern A (`?section=…` URL routing).
 *
 * Pre-#1275 admin-admins rode the page-level ToC pattern (#1207 ADM-3)
 * — every section (search / admins / add-admin / overrides /
 * add-override) stacked into one DOM and the sidebar emitted
 * `#fragment` anchor jumps. The chrome looked identical to the
 * Pattern A admin sidebars (servers / mods / groups / settings) after
 * #1266's visual unification but the routing semantics diverged
 * (#fragment vs ?section=). #1275 unifies on Pattern A so back-button
 * navigation, link sharing, and the per-section testid contract all
 * match the rest of the admin family.
 *
 * Section split — judgment call (deviates from the issue body's
 * 5-section starting suggestion):
 *
 *   - `admins` (default) — the admin list with the advanced-search
 *     box embedded above it. The pre-#1275 ToC split this in two
 *     (`search` ↔ `admins`) but those were anchor jumps within the
 *     SAME `<form>`-driven surface — the search box submits filters
 *     into the list. Splitting them across separate URLs would force
 *     the user to jump between pages to iterate filters, which is
 *     worse UX than the long-scroll the migration is supposed to
 *     fix. Pattern A's contract is "small fixed set of UNRELATED
 *     sub-tasks" (see AGENTS.md "Sub-paged admin routes"); search +
 *     list are tightly related, so they share a section.
 *   - `add-admin` — the create-admin form. Distinct surface from
 *     the list, so it gets its own URL.
 *   - `overrides` — the SourceMod command/group overrides editor.
 *     The pre-#1275 ToC split this into `overrides` (table) ↔
 *     `add-override` (add row) but both live inside the SAME `<form>`
 *     with one Save button — the legacy split was a scroll anchor,
 *     not a separate POST handler. Splitting them into two Pattern A
 *     sections would require splitting the form. Single section.
 *
 * Legacy URL shim — there is no shim for `#fragment` deeplinks.
 * Browsers don't send fragments to the server (fragments are
 * client-side only), so the page handler can't observe them. Per
 * the issue body's discussion, the cleanest fallback is to land on
 * the default section and accept that bookmarks like
 * `?p=admin&c=admins#add-admin` lose their anchor target. The
 * cross-link from the admin home's Overrides card has been updated
 * to `?p=admin&c=admins&section=overrides` in the same PR so the
 * one in-app deep-link keeps working.
 */

/** @var bool $canListAdmins */
$canListAdmins   = $userbank->HasAccess(WebPermission::mask(
    WebPermission::Owner,
    WebPermission::ListAdmins,
    WebPermission::EditAdmins,
    WebPermission::DeleteAdmins,
));
/** @var bool $canAddAdmins */
$canAddAdmins    = $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::AddAdmins));
/** @var bool $canEditAdmins */
$canEditAdmins   = $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::EditAdmins));
/** @var bool $canDeleteAdmins */
$canDeleteAdmins = $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::DeleteAdmins));

/*
 * #1275 / #1490 — `$sections` comes from AdminNavCatalog (main
 * sidebar accordion). Permission filters happen in
 * AdminNavCatalog::filterForUser when the navbar builds children.
 */
$sections = \Sbpp\View\AdminNavCatalog::sectionsFor('admins');
$validSlugs = array_column($sections, 'slug');
$section    = (string) ($_GET['section'] ?? '');
if (!in_array($section, $validSlugs, true)) {
    if ($canListAdmins) {
        $section = 'admins';
    } elseif ($canAddAdmins) {
        $section = 'add-admin';
    } else {
        $section = 'admins';
    }
}

// ---------------------------------------------------------------- add-admin
if ($section === 'add-admin') {
    $group_list              = $GLOBALS['PDO']->query("SELECT * FROM `:prefix_groups` WHERE type = '3'")->resultset();
    $servers                 = $GLOBALS['PDO']->query("SELECT * FROM `:prefix_servers`")->resultset();
    $server_admin_group_list = $GLOBALS['PDO']->query("SELECT * FROM `:prefix_srvgroups`")->resultset();
    $server_group_list       = $GLOBALS['PDO']->query("SELECT * FROM `:prefix_groups` WHERE type != 3")->resultset();
    // #1404 — the pre-fix loop also built a `$serverscript` `<script>`
    // blob that emitted `LoadServerHost('sid', 'id', 'saSID');` per
    // server. The `LoadServerHost` helper was deleted with
    // `sourcebans.js` at #1123 D1, so every page load raised
    // `ReferenceError: LoadServerHost is not defined` once per
    // configured server with no visible effect (the `sa<SID>` <span>
    // already renders bare `IP:port` text from `$server_list`).
    //
    // #1405 — the additive replacement: the template's per-server rows
    // now ride the shared `web/scripts/server-tile-hydrate.js` helper
    // (the same one driving the public servers list, admin Server
    // Management list, and dashboard Servers widget). The View DTO
    // does NOT carry a new property — hydration is purely client-side
    // off the existing `$server_list` rows (each row already exposes
    // `sid` / `ip` / `port`, which is all the helper needs to fire
    // `Actions.ServersHostPlayers` per row and patch the live hostname
    // into the `[data-testid="server-host"]` slot). See AGENTS.md
    // "Hydrate server-tile cards…" for the per-surface contract.
    $server_list = [];
    foreach ($servers as $server) {
        $info['sid']  = $server['sid'];
        $info['ip']   = $server['ip'];
        $info['port'] = $server['port'];
        array_push($server_list, $info);
    }

    \Sbpp\View\Renderer::render($theme, new \Sbpp\View\AdminAdminsAddView(
        // See AdminAdminsListView for why we don't splat Perms::for().
        can_add_admins: $canAddAdmins,
        group_list: $group_list,
        server_list: $server_list,
        server_admin_group_list: $server_admin_group_list,
        server_group_list: $server_group_list,
        // #1402 adversarial review HIGH 1: gate the OWNER checkbox so a
        // non-owner with ADMIN_ADD_ADMINS can't see/tick it. Paired with
        // the server-side guard in api_admins_add (the load-bearing
        // half; this is the visible-affordance half).
        can_grant_owner: $userbank->HasAccess(WebPermission::Owner),
    ));
    return;
}

// ---------------------------------------------------------------- overrides
if ($section === 'overrides') {
    // Overrides — extracted into its own handler in #1123 B17. The
    // require lands the AdminOverridesView for us (it does its own
    // POST processing + Renderer::render). admin.overrides.php is
    // unchanged; this require keeps the existing POST URL
    // (`?p=admin&c=admins`) working for the form's submit.
    require(TEMPLATES_PATH . "/admin.overrides.php");
    return;
}

// ---------------------------------------------------------------- admins (default)
$AdminsPerPage = SB_BANS_PER_PAGE;
$page = 1;
if (isset($_GET['page']) && $_GET['page'] > 0) {
    $page = (int) $_GET['page'];
}

/*
 * #1207 ADM-4: collapse the eight per-row Search buttons into one
 * combined filter form and AND the populated filters server-side.
 *
 * The new wire format reads each filter from its own query parameter
 * (`name`, `steamid`, `admemail`, `webgroup`,
 * `srvadmgroup`, `srvgroup`, `admwebflag[]`, `admsrvflag[]`, `server`)
 * so a single GET submit carries the full filter snapshot. Text filters
 * always substring-match (`LIKE %…%`). URL-shareable searches are
 * preserved by the legacy-shim block below: any incoming
 * `?advType=…&advSearch=…` is translated into the modern shape so old
 * bookmarks and cross-page links keep working.
 *
 * Server-side filters are AND-combined: a request with two non-empty
 * filters narrows to admins matching both, which matches the typical
 * search-UI mental model the audit called out (an admin in group X
 * AND with permission Y). The pre-fix shape only honoured one filter
 * at a time and silently dropped the rest.
 */
$where        = "";
$whereParams  = [];
$joinAdminsServersGroups = false;
$joinServersGroups       = false;
$joinWebGroups           = false;
$joinSrvAdminGroups      = false;
/** @var array<string, string|list<string>> $activeFilters */
$activeFilters = [];

// Legacy `advType=…&advSearch=…` URLs still flow through any external
// links / bookmarks. Translate them into the modern shape so the rest
// of this handler operates on a single, consistent input source.
if (isset($_GET['advType']) && isset($_GET['advSearch']) && $_GET['advSearch'] !== '') {
    /** @var string $legacyType */
    $legacyType  = (string) $_GET['advType'];
    /** @var string $legacyValue */
    $legacyValue = (string) $_GET['advSearch'];
    switch ($legacyType) {
        case 'name':
        case 'admemail':
        case 'webgroup':
        case 'srvadmgroup':
        case 'srvgroup':
        case 'server':
        case 'steamid':
            if (!isset($_GET[$legacyType]) || $_GET[$legacyType] === '') {
                $_GET[$legacyType] = $legacyValue;
            }
            break;
        case 'steam':
            // The legacy form distinguished exact (`steamid`) from
            // partial (`steam`) matches as two distinct advTypes. The
            // modern form folds both onto `steamid` (always partial).
            if (!isset($_GET['steamid']) || $_GET['steamid'] === '') {
                $_GET['steamid'] = $legacyValue;
            }
            break;
        case 'admwebflag':
        case 'admsrvflag':
            if (!isset($_GET[$legacyType]) || $_GET[$legacyType] === '' || (is_array($_GET[$legacyType]) && empty($_GET[$legacyType]))) {
                $_GET[$legacyType] = explode(',', $legacyValue);
            }
            break;
    }
}

// 1) Login name (partial against ADM.user).
if (!empty($_GET['name']) && is_string($_GET['name'])) {
    $where                       .= " AND ADM.user LIKE ?";
    $whereParams[]                = '%' . $_GET['name'] . '%';
    $activeFilters['name']        = (string) $_GET['name'];
}

// 2) Steam ID (partial against ADM.authid).
if (!empty($_GET['steamid']) && is_string($_GET['steamid'])) {
    $where                        .= " AND ADM.authid LIKE ?";
    $whereParams[]                 = '%' . $_GET['steamid'] . '%';
    $activeFilters['steamid']      = (string) $_GET['steamid'];
}

// 3) E-mail (partial). Gated on the same flag the search box gates
//    the input field on so URL forgery can't bypass the visibility gate.
if (!empty($_GET['admemail']) && is_string($_GET['admemail']) && $userbank->HasAccess(WebPermission::mask(WebPermission::Owner, WebPermission::EditAdmins))) {
    $where                         .= " AND ADM.email LIKE ?";
    $whereParams[]                  = '%' . $_GET['admemail'] . '%';
    $activeFilters['admemail']      = (string) $_GET['admemail'];
}

// 4) Web group (`:prefix_groups.gid` -> `:prefix_admins.gid`).
if (!empty($_GET['webgroup']) && is_scalar($_GET['webgroup'])) {
    $where                       .= " AND ADM.gid = ?";
    $whereParams[]                = (int) $_GET['webgroup'];
    $activeFilters['webgroup']    = (string) $_GET['webgroup'];
}

// 5) SourceMod admin group (matched by name against ADM.srv_group).
if (!empty($_GET['srvadmgroup']) && is_string($_GET['srvadmgroup'])) {
    $where                          .= " AND ADM.srv_group = ?";
    $whereParams[]                   = $_GET['srvadmgroup'];
    $activeFilters['srvadmgroup']    = $_GET['srvadmgroup'];
}

// 6) Server group (`:prefix_groups.gid` -> `:prefix_admins_servers_groups.srv_group_id`).
if (!empty($_GET['srvgroup']) && is_scalar($_GET['srvgroup'])) {
    $joinAdminsServersGroups       = true;
    $where                        .= " AND ASG.srv_group_id = ?";
    $whereParams[]                 = (int) $_GET['srvgroup'];
    $activeFilters['srvgroup']     = (string) $_GET['srvgroup'];
}

// 7) Web permission flags (multi). Submitted as either `admwebflag[]=X&admwebflag[]=Y`
// or the legacy comma-joined string. Resolve each name to its bit and
// OR-combine into a single bitmask. The SQL predicate mirrors
// UserManager::HasAccess(): direct extraflags OR inherited web-group
// flags, with any requested bit counting as a match.
$rawWebFlags = $_GET['admwebflag'] ?? null;
if (is_string($rawWebFlags)) {
    $rawWebFlags = explode(',', $rawWebFlags);
}
if (is_array($rawWebFlags)) {
    /** @var list<string> $webFlagNames */
    $webFlagNames = [];
    foreach ($rawWebFlags as $candidate) {
        if (is_string($candidate) && preg_match('/^ADMIN_[A-Z_]+$/', $candidate) && defined($candidate)) {
            $webFlagNames[] = $candidate;
        }
    }
    if (!empty($webFlagNames)) {
        $flagBits = array_map(fn(string $name): int => (int) constant($name), $webFlagNames);
        $flagMask = array_reduce($flagBits, static fn (int $mask, int $bit): int => $mask | $bit, 0);
        $joinWebGroups = true;
        $where .= ' AND (((ADM.extraflags | COALESCE(WG.flags, 0)) & ?) <> 0)';
        $whereParams[] = $flagMask;
        $activeFilters['admwebflag'] = $webFlagNames;
    }
}

// 8) Server permission flags (multi). SM_* constants are single-char
// strings (`SM_ROOT` = `z`). Match against the concatenated direct +
// inherited group flags, mirroring UserManager::HasAccess(). SM_ROOT
// implies every requested server flag.
$rawSrvFlags = $_GET['admsrvflag'] ?? null;
if (is_string($rawSrvFlags)) {
    $rawSrvFlags = explode(',', $rawSrvFlags);
}
if (is_array($rawSrvFlags)) {
    /** @var list<string> $srvFlagNames */
    $srvFlagNames = [];
    foreach ($rawSrvFlags as $candidate) {
        if (is_string($candidate) && preg_match('/^SM_[A-Z0-9_]+$/', $candidate) && defined($candidate)) {
            $srvFlagNames[] = $candidate;
        }
    }
    if (!empty($srvFlagNames)) {
        /** @var list<string> $flagChars */
        $flagChars = array_map(fn(string $name): string => (string) constant($name), $srvFlagNames);
        $flagChars[] = SM_ROOT;
        $flagChars = array_values(array_unique($flagChars));
        $joinSrvAdminGroups = true;
        $serverFlagClauses = [];
        foreach ($flagChars as $flagChar) {
            // SourceMod flags are case-sensitive in UserManager::HasAccess().
            // BINARY prevents the table's case-insensitive collation from
            // treating `A` as the lower-case `a` reserved-slot flag.
            $serverFlagClauses[] = "INSTR(BINARY CONCAT(COALESCE(ADM.srv_flags, ''), COALESCE(SAG.flags, '')), BINARY ?) > 0";
            $whereParams[] = $flagChar;
        }
        $where .= ' AND (' . implode(' OR ', $serverFlagClauses) . ')';
        $activeFilters['admsrvflag'] = $srvFlagNames;
    }
}

// 9) Server (`:prefix_servers.sid`). Either via direct admin->server
// access (`ASG.server_id`) or via the server's group attachment
// (`SGS.server_id`). Reuses the ASG join above when "server group" is
// also active so the WHERE still ANDs cleanly.
if (!empty($_GET['server']) && is_scalar($_GET['server'])) {
    $joinAdminsServersGroups   = true;
    $joinServersGroups         = true;
    $where                    .= " AND (ASG.server_id = ? OR SGS.server_id = ?)";
    $whereParams[]             = (int) $_GET['server'];
    $whereParams[]             = (int) $_GET['server'];
    $activeFilters['server']   = (string) $_GET['server'];
}

$join = "";
if ($joinAdminsServersGroups) {
    $join .= " LEFT JOIN `:prefix_admins_servers_groups` AS ASG ON ASG.admin_id = ADM.aid";
}
if ($joinServersGroups) {
    $join .= " LEFT JOIN `:prefix_servers_groups` AS SGS ON SGS.group_id = ASG.srv_group_id";
}
if ($joinWebGroups) {
    $join .= " LEFT JOIN `:prefix_groups` AS WG ON WG.gid = ADM.gid";
}
if ($joinSrvAdminGroups) {
    $join .= " LEFT JOIN `:prefix_srvgroups` AS SAG ON SAG.name = ADM.srv_group";
}

// Pagination needs the active-filter snapshot baked into every "next"
// page link so subsequent navigation preserves the search. Pre-#1275
// the section was implicit (`?p=admin&c=admins`); now the page links
// must carry `&section=admins` too so back/forward stays on the
// admins list rather than ricocheting to the default section.
// `http_build_query` handles array values (`admwebflag[]=…&admwebflag[]=…`)
// natively, so multi-select filters round-trip without manual joining.
$advSearchString = empty($activeFilters) ? '' : '&' . http_build_query($activeFilters);
$offset = (int) (($page - 1) * $AdminsPerPage);
// DISTINCT runs before LIMIT so joins cannot consume page slots with
// duplicate admins. The count uses the same one-row-per-aid contract.
$admins = $GLOBALS['PDO']->query(
    "SELECT DISTINCT ADM.* FROM `:prefix_admins` AS ADM".$join." WHERE ADM.aid > 0".$where." ORDER BY ADM.user LIMIT "
    . $offset . "," . (int) $AdminsPerPage
)->resultset($whereParams);
$query = $GLOBALS['PDO']->query(
    "SELECT COUNT(DISTINCT ADM.aid) AS cnt FROM `:prefix_admins` AS ADM".$join." WHERE ADM.aid > 0".$where
)->single($whereParams);
$admin_count = $query['cnt'];

if (isset($_GET['page']) && $_GET['page'] > 0) {
    $page = (int) $_GET['page'];
}

$AdminsStart = (int) (($page - 1) * $AdminsPerPage);
$AdminsEnd   = (int) ($AdminsStart + $AdminsPerPage);
if ($AdminsEnd > $admin_count) {
    $AdminsEnd = $admin_count;
}

$userbank->GetAllAdmins();

$adminAids        = array_map(static fn ($a) => (int) $a['aid'], $admins);
$banCountByAid    = [];
$nodemoCountByAid = [];
if ($adminAids !== []) {
    $banCountRows = $GLOBALS['PDO']->resultsetInList(
        'SELECT aid, count(authid) AS num FROM `:prefix_bans` WHERE aid IN (',
        $adminAids,
        ') GROUP BY aid',
    );
    foreach ($banCountRows as $banCountRow) {
        $banCountByAid[(int) $banCountRow['aid']] = (int) $banCountRow['num'];
    }

    $nodemoCountRows = $GLOBALS['PDO']->resultsetInList(
        'SELECT B.aid AS aid, count(B.bid) AS num FROM `:prefix_bans` AS B WHERE B.aid IN (',
        $adminAids,
        ') AND NOT EXISTS (SELECT D.demid FROM `:prefix_demos` AS D WHERE D.demid = B.bid) GROUP BY B.aid',
    );
    foreach ($nodemoCountRows as $nodemoCountRow) {
        $nodemoCountByAid[(int) $nodemoCountRow['aid']] = (int) $nodemoCountRow['num'];
    }
}

// List Page
$admin_list = [];
foreach ($admins as $admin) {
    $admin['immunity']     = $userbank->GetProperty("srv_immunity", $admin['aid']);
    $admin['web_group']    = $userbank->GetProperty("group_name", $admin['aid']);
    $admin['server_group'] = $userbank->GetProperty("srv_groups", $admin['aid']);
    if (empty($admin['web_group']) || $admin['web_group'] == " ") {
        $admin['web_group'] = "No groups";
    }
    if (empty($admin['server_group']) || $admin['server_group'] == " ") {
        $admin['server_group'] = "No groups";
    }
    $admin['bancount']    = $banCountByAid[(int) $admin['aid']] ?? 0;
    $admin['aid']         = $admin['aid'];
    $admin['nodemocount'] = $nodemoCountByAid[(int) $admin['aid']] ?? 0;

    $admin['name']               = stripslashes($admin['user']);
    $admin['server_flag_string'] = SmFlagsToSb($userbank->GetProperty("srv_flags", $admin['aid']));
    $admin['web_flag_string']    = BitToString($userbank->GetProperty("extraflags", $admin['aid']));

    $lastvisit = $userbank->GetProperty("lastvisit", $admin['aid']);
    if (!$lastvisit) {
        $admin['lastvisit'] = "Never";
    } else {
        $admin['lastvisit'] = Config::time($userbank->GetProperty("lastvisit", $admin['aid']));
    }
    array_push($admin_list, $admin);
}

// Page links carry &section=admins so prev/next/picker keep the user
// on this section rather than ricocheting to the default landing.
if ($page > 1) {
    $prev = CreateLinkR('<i class="fas fa-arrow-left fa-lg"></i> prev', "index.php?p=admin&c=admins&section=admins&page=" . ($page - 1) . $advSearchString);
} else {
    $prev = "";
}
if ($AdminsEnd < $admin_count) {
    $next = CreateLinkR('next <i class="fas fa-arrow-right fa-lg"></i>', "index.php?p=admin&c=admins&section=admins&page=" . ($page + 1) . $advSearchString);
} else {
    $next = "";
}

//=================[ Start Layout ]==================================
$admin_nav = 'displaying&nbsp;' . $AdminsStart . '&nbsp;-&nbsp;' . $AdminsEnd . '&nbsp;of&nbsp;' . $admin_count . '&nbsp;results';

if ($prev !== '') {
    $admin_nav .= ' | <b>' . $prev . '</b>';
}
if ($next !== '') {
    $admin_nav .= ' | <b>' . $next . '</b>';
}

$pages = ceil($admin_count / $AdminsPerPage);
if ($pages > 1) {
    // The dropdown's `onchange` navigates to the keyed page directly.
    // The legacy code reached for `changePage(this, 'A', advSearch,
    // advType)` from `sourcebans.js`, but the bulk file was removed at
    // #1123 D1 — clicking the picker therefore raised `ReferenceError`
    // on origin/main. Inline a vanilla snippet that builds the URL
    // from the same `$advSearchString` the prev/next links use, so the
    // multi-filter snapshot round-trips through the picker too.
    //
    // `htmlspecialchars` on the base URL is what stops the ADM-4
    // multi-filter `&admwebflag[]=…` from breaking out of the
    // attribute string.
    $baseUrl    = 'index.php?p=admin&c=admins&section=admins' . $advSearchString . '&page=';
    $baseUrlAttr = htmlspecialchars($baseUrl, ENT_QUOTES, 'UTF-8');
    $admin_nav .= '&nbsp;<select onchange="window.location.href=\'' . $baseUrlAttr . '\'+encodeURIComponent(this.value);"'
        . ' aria-label="Jump to page">';
    for ($i = 1; $i <= $pages; $i++) {
        if (isset($_GET['page']) && $i === (int) $_GET['page']) {
            $admin_nav .= '<option value="' . $i . '" selected="selected">' . $i . '</option>';
            continue;
        }
        $admin_nav .= '<option value="' . $i . '">' . $i . '</option>';
    }
    $admin_nav .= '</select>';
}

\Sbpp\View\Renderer::render($theme, new \Sbpp\View\AdminAdminsListView(
    // We pass the can_* gates explicitly rather than splatting
    // ...Perms::for($userbank): the helper's @return array<string,bool>
    // doesn't expose a constant key shape, so PHPStan can't prove the
    // splat fills these named params and reports argument.missing.
    // Listing them by hand keeps the page handler PHPStan-clean while
    // the View itself still follows the can_* convention from
    // Sbpp\View\View's class-level docblock.
    can_list_admins: $canListAdmins,
    can_edit_admins: $canEditAdmins,
    can_delete_admins: $canDeleteAdmins,
    admin_count: (int) $admin_count,
    admin_nav: (string) $admin_nav,
    admins: $admin_list,
));
