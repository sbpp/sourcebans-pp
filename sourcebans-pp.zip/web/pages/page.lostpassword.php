<?php

global $theme, $userbank;

use Sbpp\Mail\EmailType;
use Sbpp\Mail\Mail;
use Sbpp\Mail\Mailer;

// Issue #1207 AUTH-1: a user trying to recover their password is by
// definition logged out, so a logged-in admin (or any authenticated
// visitor) reaching this URL should be sent home rather than rendering
// the form with the admin sidebar leaking around it. Mirrors the
// equivalent guard in page.login.php (which redirects logged-in users
// to `index.php` so the form is never shown to them either).
//
// JS redirect rather than `header('Location:')` because this handler
// runs INSIDE `build()` — `pages/core/header.php`,
// `pages/core/navbar.php`, and `pages/core/title.php` have already
// flushed ~9 KB of HTML (including the admin sidebar this guard exists
// to suppress) by the time we get here. PHP's `header()` is a no-op
// after output starts, so the redirect would silently fail and the
// admin chrome leak the audit screenshot caught would still ship —
// just with the form body missing on top, because `die()` halts
// rendering mid-page. `page.login.php`'s 200-line-old equivalent
// guard (`page.login.php:27-30`) uses the same JS redirect for the
// same reason; mirror it here so the user-observable behaviour is
// identical to the login surface.
if ($userbank->is_logged_in()) {
    echo "<script>window.location.href = 'index.php';</script>";
    exit;
}

// Issue #1102 / #1456: when normal login is disabled the entire
// password-recovery flow is meaningless — a reset password can't be
// used to log in. Bounce both the form and the recovery-link branch
// back to the login page. The companion email-enumeration leak the
// original #1102 comment referenced (the "not_registered" error
// envelope) has since been closed by #1456 — `api_auth_lost_password`
// now returns the same generic envelope regardless of whether the
// email matches an admin row — but the disable-normal-login bounce
// is still load-bearing because rendering the form on a panel where
// normal login is off would surface a non-functional UI to the user.
if (!Config::getBool('config.enablenormallogin')) {
    header('Location: index.php?p=login');
    die();
}

if (isset($_GET['email'], $_GET['validation']) && (!empty($_GET['email']) || !empty($_GET['validation']))) {
    $email = $_GET['email'];
    $validation = $_GET['validation'];

    if (is_array($email) || is_array($validation)) {
        \Sbpp\View\Toast::emit('error', 'Error', 'Invalid request.');
        Log::add(LogType::Warning, "Hacking attempt", "Attempted SQL-Injection.");
        PageDie();
    }

    if (strlen((string) $validation) < 10) {
        \Sbpp\View\Toast::emit('error', 'Error', 'Invalid validation string.');
        PageDie();
    }

    // Both columns use a case- and accent-insensitive collation, so SQL
    // only narrows by email: the token is checked byte-exact here, and
    // the new password goes to the stored address, never the
    // collation-equal request value.
    $GLOBALS['PDO']->query("SELECT aid, user, email, validate FROM `:prefix_admins` WHERE `email` = :email");
    $GLOBALS['PDO']->bind(':email', $email);
    $candidates = $GLOBALS['PDO']->resultset();

    $result = null;
    foreach ($candidates as $candidate) {
        $storedToken = (string) $candidate['validate'];
        if ($storedToken !== '' && hash_equals($storedToken, (string) $validation)) {
            $result = $candidate;
            break;
        }
    }

    if ($result === null) {
        \Sbpp\View\Toast::emit('error', 'Error', 'The validation string does not match the email for this reset request.');
        PageDie();
    }

    // #1269: send the new password BEFORE mutating the DB row so a
    // misconfigured mailer (e.g. an upgraded panel where the 1.x
    // installer left `config.smtp.*` empty) doesn't silently lock the
    // admin out. Pre-fix: the password was rolled to a random string,
    // mail send was attempted, the result was assigned to $isEmailSent
    // but never checked, and the user got "Your password has been
    // reset and sent to your email" regardless. With mail broken that
    // means the old password is gone, the new password was never
    // delivered, and the validation token is consumed — no recovery
    // path. Now: roll only after the mailer has accepted the message;
    // surface the error otherwise so the user can retry once SMTP is
    // configured.
    $password    = Crypto::genSecret(MIN_PASS_LENGTH + 8);
    $isEmailSent = Mail::send((string) $result['email'], EmailType::PasswordResetSuccess, [
        '{password}' => $password,
        '{name}'     => $result['user'],
        '{home}'     => Host::complete(true)
    ]);

    if (!$isEmailSent) {
        \Sbpp\View\Toast::emit(
            'error',
            'Error',
            'Could not send the new password by email. Your old password is still active. Please contact an administrator if this persists.',
        );
        PageDie();
    }

    $GLOBALS['PDO']->query("UPDATE `:prefix_admins` SET `password` = :password, `validate` = NULL WHERE `aid` = :aid");
    $GLOBALS['PDO']->bind(':password', password_hash($password, PASSWORD_BCRYPT));
    $GLOBALS['PDO']->bind(':aid', $result['aid']);
    $GLOBALS['PDO']->execute();

    // Body line-breaks (`<br />`) converted to spaces so the body reads
    // as a single line — `showToast` (theme.js) `escapeHtml`s the value
    // so raw tags surface as visible literal text.
    \Sbpp\View\Toast::emit(
        'info',
        'Password Reset',
        'Your password has been reset and sent to your email. '
            . 'Please check your spam folder too. '
            . 'Please login using this password, then use the change password link in Your Account.',
    );
    PageDie();
} else {
    \Sbpp\View\Renderer::render($theme, new \Sbpp\View\LostPasswordView());
}
