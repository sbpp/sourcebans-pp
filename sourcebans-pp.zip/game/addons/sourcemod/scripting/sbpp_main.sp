// *************************************************************************
//  This file is part of SourceBans++.
//
//  Copyright (C) 2014-2024 SourceBans++ Dev Team <https://github.com/sbpp>
//
//  SourceBans++ is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, per version 3 of the License.
//
//  SourceBans++ is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with SourceBans++. If not, see <http://www.gnu.org/licenses/>.
//
//  This file is based off work(s) covered by the following copyright(s):
//
//   SourceBans 1.4.11
//   Copyright (C) 2007-2015 SourceBans Team - Part of GameConnect
//   Licensed under GNU GPL version 3, or later.
//   Page: <http://www.sourcebans.net/> - <https://github.com/GameConnect/sourcebansv1>
//
// *************************************************************************

#pragma semicolon 1

#include <sourcemod>
#include <sourcebanspp>
#include <sbpp_server_ip>

#undef REQUIRE_PLUGIN
#include <adminmenu>

#pragma newdecls required

//GLOBAL DEFINES
#define DISABLE_ADDBAN		1
#define DISABLE_UNBAN		2

#define FLAG_LETTERS_SIZE 26

#define AUTO_ADD_SERVER_DISABLED     0
#define AUTO_ADD_SERVER_WITH_RCON    2

//#define DEBUG

enum State/* ConfigState */
{
	ConfigStateNone = 0,
	ConfigStateConfig,
	ConfigStateReasons,
	ConfigStateHacking,
	ConfigStateTime
}

State ConfigState;

#define Prefix "\x04[SourceBans++]\x01 "

/* Admin Stuff */
AdminCachePart loadPart;

AdminFlag g_FlagLetters[FLAG_LETTERS_SIZE];

/* Cvar handle */
ConVar CvarHostIp;
ConVar CvarPort;

ConVar sb_id;

/* Database handle */
Database DB;
Database SQLiteDB;

char
	ServerIp[SBPP_SERVER_IP_LENGTH]
	, ConfiguredServerIp[SBPP_SERVER_IP_LENGTH]
	, ServerIpEscaped[SBPP_SERVER_IP_LENGTH * 2 + 1]
	, ServerPort[7]
	, DatabasePrefix[10] = "sb"
	, WebsiteAddress[128]
	, groupsLoc[128] /* Admin KeyValues */
	, adminsLoc[128]
	, overridesLoc[128]
	, logFile[256] /* Log Stuff */
	, g_sSteamIDs[MAXPLAYERS + 1][MAX_AUTHID_LENGTH]
	, g_sName[MAXPLAYERS + 1][MAX_NAME_LENGTH]
	, g_sPlayerIP[MAXPLAYERS + 1][16];

float RetryTime = 15.0;

bool
	loadAdmins /* Admin Stuff*/
	, loadGroups
	, loadOverrides
	, LateLoaded
	, g_bConnecting = false
	, requireSiteLogin = false /* Require a lastvisited from SB site */
	, backupConfig = true
	, enableAdmins = true
	, PlayerStatus[MAXPLAYERS + 1] /* Player ban check status */
	, PlayerCheckPending[MAXPLAYERS + 1]; /* Ban check query in flight */

int
	g_BanTarget[MAXPLAYERS + 1] =  { -1, ... }
	, g_BanTime[MAXPLAYERS + 1] =  { -1, ... }
	, g_BanTargetUserId[MAXPLAYERS + 1] =  { -1, ... }
	, AutoAdd = 0
	, curLoading
	, serverID = -1
	, ProcessQueueTime = 5
	, g_ownReasons[MAXPLAYERS + 1] =  { false, ... } /* Own Chat Reason */
	, CommandDisable /* Disable of addban and unban */
	, g_iUserIDs[MAXPLAYERS + 1];


SMCParser ConfigParser;

GlobalForward g_hFwd_OnBanAdded
			, g_hFwd_OnReportAdded
			, g_hFwd_OnClientPreAdminCheck
			, g_hFwd_OnClientPostAdminCheck;

Handle PlayerRecheck[MAXPLAYERS + 1] =  { INVALID_HANDLE, ... }; /* Timer handle */

DataPack PlayerDataPack[MAXPLAYERS + 1] =  { null, ... };

TopMenu	hTopMenu = null;

Menu
	TimeMenuHandle
	, ReasonMenuHandle
	, HackingMenuHandle;

public Plugin myinfo =
{
	name = "SourceBans++: Main Plugin",
	author = "SourceBans Development Team, SourceBans++ Dev Team",
	description = "Advanced ban management for the Source engine",
	version = SB_VERSION,
	url = "https://sbpp.github.io"
};

public APLRes AskPluginLoad2(Handle myself, bool late, char[] error, int err_max)
{
	RegPluginLibrary("sourcebans++");

	CreateNative("SBBanPlayer", Native_SBBanPlayer);
	CreateNative("SBPP_BanPlayer", Native_SBBanPlayer);
	CreateNative("SBPP_BanPlayerBySteamId", Native_SBPP_BanPlayerBySteamId);
	CreateNative("SBPP_ReportPlayer", Native_SBReportPlayer);

	g_hFwd_OnBanAdded = CreateGlobalForward("SBPP_OnBanPlayer", ET_Ignore, Param_Cell, Param_Cell, Param_Cell, Param_String);
	g_hFwd_OnReportAdded = CreateGlobalForward("SBPP_OnReportPlayer", ET_Ignore, Param_Cell, Param_Cell, Param_String);
	g_hFwd_OnClientPreAdminCheck = CreateGlobalForward("SBPP_OnClientPreAdminCheck", ET_Ignore, Param_Cell);
	g_hFwd_OnClientPostAdminCheck = CreateGlobalForward("SBPP_OnClientPostAdminCheck", ET_Ignore, Param_Cell);

	LateLoaded = late;

	return APLRes_Success;
}

public void OnPluginStart()
{
	LoadTranslations("common.phrases");
	LoadTranslations("plugin.basecommands");
	LoadTranslations("sbpp_main.phrases");
	LoadTranslations("basebans.phrases");
	loadAdmins = loadGroups = loadOverrides = false;

	CvarHostIp = FindConVar("hostip");
	CvarPort = FindConVar("hostport");
	CreateConVar("sb_version", SB_VERSION, _, FCVAR_SPONLY | FCVAR_REPLICATED | FCVAR_NOTIFY);
	RegServerCmd("sm_rehash", sm_rehash, "Reload SQL admins");
	RegAdminCmd("sm_ban", CommandBan, ADMFLAG_BAN, "sm_ban <#userid|name> <minutes|0> [reason]", "sourcebans");
	RegAdminCmd("sm_banip", CommandBanIp, ADMFLAG_BAN, "sm_banip <ip|#userid|name> <time> [reason]", "sourcebans");
	RegAdminCmd("sm_addban", CommandAddBan, ADMFLAG_RCON, "sm_addban <time> <steamid> [reason]", "sourcebans");
	RegAdminCmd("sm_unban", CommandUnban, ADMFLAG_UNBAN, "sm_unban <steamid|ip> [reason]", "sourcebans");
	RegAdminCmd("sb_reload", CommandReload, ADMFLAG_RCON, "Reload sourcebans config and ban reason menu options", "sourcebans");

	RegConsoleCmd("say", ChatHook);
	RegConsoleCmd("say_team", ChatHook);

	HookEvent("player_changename", Event_OnPlayerName, EventHookMode_Post);

	sb_id = CreateConVar("sb_id", "-1", "Set to a value other than -1 to override the serverid in sourcebans.cfg", FCVAR_NONE, true, -1.0, false);
	HookConVarChange(sb_id, sbid_reload);

	if ((TimeMenuHandle = CreateMenu(MenuHandler_BanTimeList, MenuAction_Select|MenuAction_Cancel|MenuAction_DrawItem)) != INVALID_HANDLE)
	{
		TimeMenuHandle.Pagination = 8;
		TimeMenuHandle.ExitBackButton = true;
	}

	if ((ReasonMenuHandle = new Menu(ReasonSelected)) != INVALID_HANDLE)
	{
		ReasonMenuHandle.Pagination = 8;
		ReasonMenuHandle.ExitBackButton = true;
	}

	if ((HackingMenuHandle = new Menu(HackingSelected)) != INVALID_HANDLE)
	{
		HackingMenuHandle.Pagination = 8;
		HackingMenuHandle.ExitBackButton = true;
	}

	g_FlagLetters = CreateFlagLetters();

	BuildPath(Path_SM, logFile, sizeof(logFile), "logs/sourcebans.log");
	g_bConnecting = true;

	// Read the server identity before the asynchronous database callback builds queries.
	ResetSettings();

	// Catch config error and show link to FAQ
	if (!SQL_CheckConfig("sourcebans"))
	{
		if (ReasonMenuHandle != INVALID_HANDLE)
			CloseHandle(ReasonMenuHandle);
		if (HackingMenuHandle != INVALID_HANDLE)
			CloseHandle(HackingMenuHandle);
		LogToFile(logFile, "Database failure: Could not find Database conf \"sourcebans\". See Docs: https://sbpp.github.io/docs/");
		SetFailState("Database failure: Could not find Database conf \"sourcebans\"");
		return;
	}

	Database.Connect(GotDatabase, "sourcebans");

	BuildPath(Path_SM, groupsLoc, sizeof(groupsLoc), "configs/sourcebans/sb_admin_groups.cfg");

	BuildPath(Path_SM, adminsLoc, sizeof(adminsLoc), "configs/sourcebans/sb_admins.cfg");

	BuildPath(Path_SM, overridesLoc, sizeof(overridesLoc), "configs/sourcebans/overrides_backup.cfg");

	InitializeBackupDB();

	// This timer is what processes the SQLite queue when the database is unavailable
	CreateTimer(float(ProcessQueueTime * 60), ProcessQueue);

	if (LateLoaded)
	{
		AccountForLateLoading();
	}
}

public void OnAllPluginsLoaded()
{
	TopMenu topmenu;
	#if defined DEBUG
	LogToFile(logFile, "OnAllPluginsLoaded()");
	#endif

	if (LibraryExists("adminmenu") && ((topmenu = GetAdminTopMenu()) != INVALID_HANDLE))
	{
		OnAdminMenuReady(topmenu);
	}
}

public void OnConfigsExecuted()
{
	char filename[200];
	BuildPath(Path_SM, filename, sizeof(filename), "plugins/basebans.smx");
	if (FileExists(filename))
	{
		char newfilename[200];
		BuildPath(Path_SM, newfilename, sizeof(newfilename), "plugins/disabled/basebans.smx");
		ServerCommand("sm plugins unload basebans");
		if (FileExists(newfilename))
			DeleteFile(newfilename);
		RenameFile(newfilename, filename);
		LogToFile(logFile, "plugins/basebans.smx was unloaded and moved to plugins/disabled/basebans.smx");
	}
}

public void OnMapStart()
{
	if (ResetSettings())
	{
		sm_rehash(0);
	}
}

void sbid_reload(ConVar convar, const char[] oldValue, const char[] newValue)
{
	if (ResetSettings())
	{
		sm_rehash(0);
	}
}

public void OnMapEnd()
{
	for (int i = 0; i <= MaxClients; i++)
	{
		ClearPendingBanState(i);
	}
}

// CLIENT CONNECTION FUNCTIONS //

public Action OnClientPreAdminCheck(int client)
{
	if (!DB || GetUserAdmin(client) != INVALID_ADMIN_ID)
		return Plugin_Continue;

	return curLoading > 0 ? Plugin_Handled : Plugin_Continue;
}

public void OnClientDisconnect(int client)
{
	if (PlayerRecheck[client] != INVALID_HANDLE)
	{
		delete PlayerRecheck[client];
	}

	ClearPendingBanState(client);

	PlayerCheckPending[client] = false;
	FormatEx(g_sSteamIDs[client], sizeof(g_sSteamIDs[]), "\0");
	FormatEx(g_sPlayerIP[client], sizeof(g_sPlayerIP[]), "\0");
	FormatEx(g_sName[client], sizeof(g_sName[]), "\0");
	g_iUserIDs[client] = -1;
}

public bool OnClientConnect(int client, char[] rejectmsg, int maxlen)
{
	PlayerStatus[client] = false;
	PlayerCheckPending[client] = false;
	return true;
}

public void OnClientConnected(int client)
{
	char sIP[16], auth[MAX_AUTHID_LENGTH];
	SBPP_GetClientPublicIP(client, sIP, sizeof(sIP));
	FormatEx(g_sPlayerIP[client], sizeof(g_sPlayerIP[]), "%s", sIP);

	GetClientAuthId(client, AuthId_Steam2, auth, sizeof(auth));
	FormatEx(g_sSteamIDs[client], sizeof(g_sSteamIDs[]), "%s", auth);

	FormatEx(g_sName[client], sizeof(g_sName[]), "%N", client);

	g_iUserIDs[client] = GetClientUserId(client);

	// If the authid is detected as SteamID Pending, try to get the real SteamID
	// by skip the backend validation status. #948
	if (strncmp(auth[6], "ID_", 3) == 0)
		GetClientAuthId(client, AuthId_Steam2, g_sSteamIDs[client], sizeof(g_sSteamIDs[]), false);

	/* Do not check bots nor check player with lan steamid. */
	if (auth[0] == 'B' || auth[9] == 'L')
	{
		PlayerStatus[client] = true;
		return;
	}
}

public void OnClientAuthorized(int client, const char[] auth)
{
	CheckClientBan(client);
}

// Queries the ban tables for a connected, authorized client. Safe to call
// repeatedly: it no-ops once the client passed a check, while a query is in
// flight or a retry is scheduled, and while the database is unavailable
// (GotDatabase re-runs it for everyone once the connection is up).
void CheckClientBan(int client)
{
	if (PlayerStatus[client] || PlayerCheckPending[client] || PlayerRecheck[client] != INVALID_HANDLE || DB == INVALID_HANDLE)
		return;

	// The SteamID cached in OnClientConnected can still be STEAM_ID_PENDING.
	char auth[MAX_AUTHID_LENGTH];
	if (!GetClientAuthId(client, AuthId_Steam2, auth, sizeof(auth)))
		return;

	strcopy(g_sSteamIDs[client], sizeof(g_sSteamIDs[]), auth);

	if (auth[0] == 'B' || auth[9] == 'L')
	{
		PlayerStatus[client] = true;
		return;
	}

	char Query[256];
	if (g_sPlayerIP[client][0] == '\0')
	{
		/* No usable IP (e.g. SDR client): only check by SteamID. */
		FormatEx(Query, sizeof(Query), "SELECT bid, ip FROM %s_bans WHERE (type = 0 AND authid REGEXP '^STEAM_[0-9]:%s$') AND (length = '0' OR ends > UNIX_TIMESTAMP()) AND RemoveType IS NULL", DatabasePrefix, g_sSteamIDs[client][8]);
	}
	else
	{
		FormatEx(Query, sizeof(Query), "SELECT bid, ip FROM %s_bans WHERE ((type = 0 AND authid REGEXP '^STEAM_[0-9]:%s$') OR (type = 1 AND ip = '%s')) AND (length = '0' OR ends > UNIX_TIMESTAMP()) AND RemoveType IS NULL", DatabasePrefix, g_sSteamIDs[client][8], g_sPlayerIP[client]);
	}

	#if defined DEBUG
	LogToFile(logFile, "Checking ban for: %s", g_sSteamIDs[client]);
	#endif

	PlayerCheckPending[client] = true;
	DB.Query(VerifyBan, Query, GetClientUserId(client), DBPrio_High);
}

void CheckConnectedClientBans()
{
	for (int i = 1; i <= MaxClients; i++)
	{
		if (IsClientConnected(i) && IsClientAuthorized(i))
		{
			CheckClientBan(i);
		}
	}
}

public void OnRebuildAdminCache(AdminCachePart part)
{
	loadPart = part;
	switch (loadPart)
	{
		case AdminCache_Overrides:
		loadOverrides = true;
		case AdminCache_Groups:
		loadGroups = true;
		case AdminCache_Admins:
		loadAdmins = true;
	}
	if (DB == INVALID_HANDLE) {
		if (!g_bConnecting) {
			g_bConnecting = true;
			Database.Connect(GotDatabase, "sourcebans");
		}
	}
	else {
		GotDatabase(DB, "", 0);
	}
}

// OTHER CLIENT CODE //

public void Event_OnPlayerName(Handle event, const char[] name, bool dontBroadcast)
{
	int client = GetClientOfUserId(GetEventInt(event, "userid"));
	if (client > 0 && IsClientInGame(client))
		GetEventString(event, "newname", g_sName[client], sizeof(g_sName[]));
}

// COMMAND CODE //

public Action ChatHook(int client, int args)
{
	// is this player preparing to ban someone
	if (g_ownReasons[client] && !IsChatTrigger())
	{
		// get the reason
		char reason[512];
		GetCmdArgString(reason, sizeof(reason));
		StripQuotes(reason);

		g_ownReasons[client] = false;

		if (strcmp(reason[0], "!noreason", false) == 0)
		{
			ClearPendingBanState(client);
			PrintToChat(client, "%s%t", Prefix, "Chat Reason Aborted");
			return Plugin_Handled;
		}

		// ban him!
		PrepareBan(client, g_BanTarget[client], g_BanTime[client], reason, g_BanTargetUserId[client]);

		// block the reason to be sent in chat
		return Plugin_Handled;
	}
	return Plugin_Continue;
}

public Action CommandReload(int client, int args)
{
	if (ResetSettings())
	{
		sm_rehash(0);
	}
	return Plugin_Handled;
}

public Action CommandBan(int client, int args)
{
	if ( !args && client )
	{
		DisplayBanTargetMenu(client);
		return Plugin_Handled;
	}
	else if ( args < 2 )
	{
		ReplyToCommand(client, "%sUsage: sm_ban <#userid|name> <time|0> [reason]", Prefix);
		return Plugin_Handled;
	}

	// This is mainly for me sanity since client used to be called admin and target used to be called client
	int admin = client;

	// Get the target, find target returns a message on failure so we do not
	char buffer[100];

	GetCmdArg(1, buffer, sizeof(buffer));

	int  target = FindTarget(client, buffer, true);

	if (target == -1)
	{
		return Plugin_Handled;
	}

	// Without a database the check can't run; the ban goes to the SQLite queue instead.
	if (!PlayerStatus[target] && DB != INVALID_HANDLE)
	{
		// The target has not been banned verify. It must be completed before you can ban anyone.
		ReplyToCommand(admin, "%s%t", Prefix, "Ban Not Verified");
		return Plugin_Handled;
	}

	// Get the ban time
	GetCmdArg(2, buffer, sizeof(buffer));

	int time = StringToInt(buffer);
	
	if (!StringToIntEx(buffer, time) || time < 0)
	{
		ReplyToCommand(client, "%sUsage: sm_ban <#userid|name> <time|0> [reason]", Prefix);
		return Plugin_Handled;
	}

	if (!time && client && !(CheckCommandAccess(client, "sm_unban", ADMFLAG_UNBAN | ADMFLAG_ROOT)))
	{
		ReplyToCommand(client, "You do not have Perm Ban Permission");
		return Plugin_Handled;
	}

	// Get the reason
	char reason[128];

	if (args >= 3)
	{
		GetCmdArg(3, reason, sizeof(reason));
		for (int i = 4; i <= args; i++)
		{
			GetCmdArg(i, buffer, sizeof(buffer));
			Format(reason, sizeof(reason), "%s %s", reason, buffer);
		}
	}
	else
	{
		reason[0] = '\0';
	}

	if (client != 0)
		CancelClientMenu(client);
	ClearPendingBanState(client);

	g_BanTarget[client] = target;
	g_BanTime[client] = time;
	g_BanTargetUserId[client] = GetClientUserId(target);

	bool banStarted = CreateBan(client, target, time, reason);
	if (!banStarted || reason[0] != '\0')
		ClearPendingBanState(client);

	return Plugin_Handled;
}

public Action CommandBanIp(int client, int args)
{
	if (args < 2)
	{
		ReplyToCommand(client, "%sUsage: sm_banip <ip|#userid|name> <time> [reason]", Prefix);
		return Plugin_Handled;
	}

	int len, next_len;
	char Arguments[256], arg[MAX_AUTHID_LENGTH], time[20];

	GetCmdArgString(Arguments, sizeof(Arguments));
	len = BreakString(Arguments, arg, sizeof(arg));

	if ((next_len = BreakString(Arguments[len], time, sizeof(time))) != -1)
	{
		len += next_len;
	}
	else
	{
		len = 0;
		Arguments[0] = '\0';
	}

	char target_name[MAX_TARGET_LENGTH];
	int target_list[1];
	bool tn_is_ml;

	int target = -1;

	if (ProcessTargetString(arg, client, target_list, 1, COMMAND_FILTER_CONNECTED | COMMAND_FILTER_NO_MULTI, target_name, sizeof(target_name), tn_is_ml) > 0)
	{
		target = target_list[0];
	}

	if (target == -1)
	{
		return Plugin_Handled;
	}

	char adminIp[16], adminAuth[MAX_AUTHID_LENGTH];
	int minutes = StringToInt(time);

	if (!StringToIntEx(time, minutes) || minutes < 0)
	{
		ReplyToCommand(client, "%sUsage: sm_banip <#userid|name> <time> [reason]", Prefix);
		return Plugin_Handled;
	}

	if (!minutes && client && !(CheckCommandAccess(client, "sm_unban", ADMFLAG_UNBAN | ADMFLAG_ROOT)))
	{
		ReplyToCommand(client, "You do not have Perm Ban Permission");
		return Plugin_Handled;
	}
	if (g_sPlayerIP[target][0] == '\0')
	{
		// No usable IP (e.g. Steam Networking / SDR client): an IP ban can't work.
		ReplyToCommand(client, "%s%t", Prefix, "Cannot IP Ban No IP", target);
		return Plugin_Handled;
	}

	if (!client)
	{
		// setup dummy adminAuth and adminIp for server
		strcopy(adminAuth, sizeof(adminAuth), "STEAM_ID_SERVER");
		strcopy(adminIp, sizeof(adminIp), ServerIp);
	} else {
		strcopy(adminAuth, sizeof(adminAuth), g_sSteamIDs[client]);
		strcopy(adminIp, sizeof(adminIp), g_sPlayerIP[client]);
	}

	// Pack everything into a data pack so we can retain it
	DataPack dataPack = new DataPack();
	dataPack.WriteCell(client == 0 ? 0 : GetClientUserId(client));
	dataPack.WriteCell(minutes);
	dataPack.WriteString(Arguments[len]);
	dataPack.WriteString(g_sPlayerIP[target]);
	dataPack.WriteString(g_sName[target]);
	dataPack.WriteString(g_sSteamIDs[target]);
	dataPack.WriteString(adminAuth);
	dataPack.WriteString(adminIp);

	char sQuery[256], argEscaped[sizeof(arg) * 2 + 1];
	DB.Escape(arg, argEscaped, sizeof(argEscaped));

	FormatEx(sQuery, sizeof(sQuery), "SELECT bid FROM %s_bans WHERE type = 1 AND ip     = '%s' AND (length = 0 OR ends > UNIX_TIMESTAMP()) AND RemoveType IS NULL",
		DatabasePrefix, argEscaped);

	DB.Query(SelectBanIpCallback, sQuery, dataPack, DBPrio_High);

	return Plugin_Handled;
}

public Action CommandUnban(int client, int args)
{
	if (args < 1)
	{
		ReplyToCommand(client, "%sUsage: sm_unban <steamid|ip> [reason]", Prefix);
		return Plugin_Handled;
	}

	if (CommandDisable & DISABLE_UNBAN)
	{
		// They must go to the website to unban people
		ReplyToCommand(client, "%s%t", Prefix, "Can Not Unban", WebsiteAddress);
		return Plugin_Handled;
	}

	int len;
	char Arguments[256], arg[MAX_AUTHID_LENGTH], adminAuth[MAX_AUTHID_LENGTH];

	GetCmdArgString(Arguments, sizeof(Arguments));

	if ((len = BreakString(Arguments, arg, sizeof(arg))) == -1)
	{
		len = 0;
		Arguments[0] = '\0';
	}

	bool isSteamId = strncmp(arg, "STEAM_", 6) == 0;
	char steam3[MAX_AUTHID_LENGTH];
	if (isSteamId && !Steam2ToSteam3(arg, steam3, sizeof(steam3)))
	{
		ReplyToCommand(client, "%s%t", Prefix, "Invalid SteamID", arg);
		return Plugin_Handled;
	}

	if (!client)
	{
		// setup dummy adminAuth and adminIp for server
		strcopy(adminAuth, sizeof(adminAuth), "STEAM_ID_SERVER");
	} else {
		strcopy(adminAuth, sizeof(adminAuth), g_sSteamIDs[client]);
	}

	// Pack everything into a data pack so we can retain it
	DataPack dataPack = new DataPack();
	dataPack.WriteCell(client == 0 ? 0 : GetClientUserId(client));
	dataPack.WriteString(Arguments[len]); // Reason
	dataPack.WriteString(arg); // Steamid - IP
	dataPack.WriteString(adminAuth); // Admin SteamID

	char query[512], argEscaped[sizeof(arg) * 2 + 1];
	DB.Escape(arg, argEscaped, sizeof(argEscaped));

	if (isSteamId)
	{
		// Either universe, like the ban check on connect: the web panel stores STEAM_0, some games
		// report STEAM_1
		char argYzEscaped[sizeof(arg) * 2 + 1];
		DB.Escape(arg[8], argYzEscaped, sizeof(argYzEscaped));
		Format(query, sizeof(query), "SELECT bid FROM %s_bans WHERE (type = 0 AND (authid = '%s' OR authid REGEXP '^STEAM_[0-9]:%s$')) AND (length = '0' OR ends > UNIX_TIMESTAMP()) AND RemoveType IS NULL", DatabasePrefix, argEscaped, argYzEscaped);
	} else {
		Format(query, sizeof(query), "SELECT bid FROM %s_bans WHERE (type = 1 AND ip     = '%s') AND (length = '0' OR ends > UNIX_TIMESTAMP()) AND RemoveType IS NULL", DatabasePrefix, argEscaped);
	}

	DB.Query(SelectUnbanCallback, query, dataPack);

	return Plugin_Handled;
}

public Action CommandAddBan(int client, int args)
{
	if (args < 2)
	{
		ReplyToCommand(client, "%sUsage: sm_addban <time> <steamid> [reason]", Prefix);
		return Plugin_Handled;
	}

	if (CommandDisable & DISABLE_ADDBAN)
	{
		// They must go to the website to add bans
		ReplyToCommand(client, "%s%t", Prefix, "Can Not Add Ban", WebsiteAddress);
		return Plugin_Handled;
	}

	char arg_string[256], time[16], authid[MAX_AUTHID_LENGTH];

	GetCmdArgString(arg_string, sizeof(arg_string));

	int len, total_len;

	/* Get time */
	if ((len = BreakString(arg_string, time, sizeof(time))) == -1)
	{
		ReplyToCommand(client, "%sUsage: sm_addban <time> <steamid> [reason]", Prefix);
		return Plugin_Handled;
	}
	total_len += len;

	/* Get steamid */
	if ((len = BreakString(arg_string[total_len], authid, sizeof(authid))) != -1)
	{
		total_len += len;
	}
	else
	{
		total_len = 0;
		arg_string[0] = '\0';
	}

	char adminIp[16], adminAuth[MAX_AUTHID_LENGTH];

	int minutes = StringToInt(time);

	if (!StringToIntEx(time, minutes) || minutes < 0)
	{
		ReplyToCommand(client, "%sUsage: sm_addban <time> <steamid> [reason]", Prefix);
		return Plugin_Handled;
	}

	// A ban of anything else never matches a player, as their SteamIDs have this form
	char steam3[MAX_AUTHID_LENGTH];
	if (!Steam2ToSteam3(authid, steam3, sizeof(steam3)))
	{
		ReplyToCommand(client, "%s%t", Prefix, "Invalid SteamID", authid);
		return Plugin_Handled;
	}
	// Stored as STEAM_0, like the web panel stores SteamIDs
	authid[6] = '0';

	if (!minutes && client && !(CheckCommandAccess(client, "sm_unban", ADMFLAG_UNBAN | ADMFLAG_ROOT)))
	{
		ReplyToCommand(client, "You do not have Perm Ban Permission");
		return Plugin_Handled;
	}
	if (!client)
	{
		// setup dummy adminAuth and adminIp for server
		strcopy(adminAuth, sizeof(adminAuth), "STEAM_ID_SERVER");
		strcopy(adminIp, sizeof(adminIp), ServerIp);
	} else {
		strcopy(adminAuth, sizeof(adminAuth), g_sSteamIDs[client]);
		strcopy(adminIp, sizeof(adminIp), g_sPlayerIP[client]);
	}

	// Pack everything into a data pack so we can retain it
	DataPack dataPack = new DataPack();
	dataPack.WriteCell(client == 0 ? 0 : GetClientUserId(client));
	dataPack.WriteCell(minutes);
	dataPack.WriteString(arg_string[total_len]);
	dataPack.WriteString(authid);
	dataPack.WriteString(adminAuth);
	dataPack.WriteString(adminIp);

	char sQuery[512], authidEscaped[sizeof(authid) * 2 + 1], authidYzEscaped[sizeof(authid) * 2 + 1];
	DB.Escape(authid, authidEscaped, sizeof(authidEscaped));
	DB.Escape(authid[8], authidYzEscaped, sizeof(authidYzEscaped));

	// An existing ban of either universe, as SBPP_BanPlayerBySteamId looks for
	FormatEx(sQuery, sizeof sQuery, "SELECT bid FROM %s_bans WHERE type = 0 AND (authid = '%s' OR authid REGEXP '^STEAM_[0-9]:%s$') AND (length = 0 OR ends > UNIX_TIMESTAMP()) AND RemoveType IS NULL",
		DatabasePrefix, authidEscaped, authidYzEscaped);

	DB.Query(SelectAddbanCallback, sQuery, dataPack, DBPrio_High);

	return Plugin_Handled;
}

public Action sm_rehash(int args)
{
	if (enableAdmins)
		DumpAdminCache(AdminCache_Groups, true);
	DumpAdminCache(AdminCache_Overrides, true);
	return Plugin_Handled;
}



// MENU CODE //

public void OnAdminMenuReady(Handle hTemp)
{
	TopMenu topmenu = view_as<TopMenu>(hTemp);
	#if defined DEBUG
	LogToFile(logFile, "OnAdminMenuReady()");
	#endif

	/* Block us from being called twice */
	if (topmenu == hTopMenu)
	{
		return;
	}

	/* Save the Handle */
	hTopMenu = topmenu;

	/* Find the "Player Commands" category */
	TopMenuObject player_commands = hTopMenu.FindCategory(ADMINMENU_PLAYERCOMMANDS);

	if (player_commands != INVALID_TOPMENUOBJECT)
	{
		// just to avoid "unused variable 'res'" warning
		#if defined DEBUG
		TopMenuObject res = hTopMenu.AddItem(
			"sm_ban",  // Name
			AdminMenu_Ban,  // Handler function
			player_commands,  // We are a submenu of Player Commands
			"sm_ban",  // The command to be finally called (Override checks)
			ADMFLAG_BAN); // What flag do we need to see the menu option
		char temp[125];
		Format(temp, 125, "Result of AddToTopMenu: %d", res);
		LogToFile(logFile, temp);
		LogToFile(logFile, "Added Ban option to admin menu");
		#else
		hTopMenu.AddItem(
			"sm_ban",  // Name
			AdminMenu_Ban,  // Handler function
			player_commands,  // We are a submenu of Player Commands
			"sm_ban",  // The command to be finally called (Override checks)
			ADMFLAG_BAN); // What flag do we need to see the menu option
		#endif
	}
}

public void AdminMenu_Ban(TopMenu topmenu,
	TopMenuAction action,  // Action being performed
	TopMenuObject object_id,  // The object ID (if used)
	int param,  // client idx of admin who chose the option (if used)
	char[] buffer,  // Output buffer (if used)
	int maxlength) // Output buffer (if used)
{
	#if defined DEBUG
	LogToFile(logFile, "AdminMenu_Ban()");
	#endif

	switch (action)
	{
		// We are only being displayed, We only need to show the option name
		case TopMenuAction_DisplayOption:
		{
			FormatEx(buffer, maxlength, "%T", "Ban player", param);

			#if defined DEBUG
			LogToFile(logFile, "AdminMenu_Ban() -> Formatted the Ban option text");
			#endif
		}

		case TopMenuAction_SelectOption:
		{
			DisplayBanTargetMenu(param); // Someone chose to ban someone, show the list of users menu

			#if defined DEBUG
			LogToFile(logFile, "AdminMenu_Ban() -> DisplayBanTargetMenu()");
			#endif
		}
	}
}

public int ReasonSelected(Menu menu, MenuAction action, int param1, int param2)
{
	switch (action)
	{
		case MenuAction_Select:
		{
			char info[128], key[128];

			menu.GetItem(param2, key, sizeof(key), _, info, sizeof(info));

			if (strcmp("Hacking", key, false) == 0)
			{
				HackingMenuHandle.Display(param1, MENU_TIME_FOREVER);
				return 0;
			}

			else if (strcmp("Own Reason", key, false) == 0) // admin wants to use his own reason
			{
				g_ownReasons[param1] = true;
				PrintToChat(param1, "%s%t", Prefix, "Chat Reason");
				return 0;
			}

			else if (g_BanTarget[param1] != -1 && g_BanTime[param1] != -1)
				PrepareBan(param1, g_BanTarget[param1], g_BanTime[param1], info, g_BanTargetUserId[param1]);
		}

		case MenuAction_Cancel:
		{
			if (param2 == MenuCancel_ExitBack)
			{
				CleanupPendingBanDataPack(param1);
				DisplayBanTimeMenu(param1);
			}
			else
			{
				ClearPendingBanState(param1);
			}
		}
	}
	return 0;
}

public int HackingSelected(Menu menu, MenuAction action, int param1, int param2)
{
	switch (action)
	{
		case MenuAction_Select:
		{
			char info[128], key[128];

			menu.GetItem(param2, key, sizeof(key), _, info, sizeof(info));

			if (g_BanTarget[param1] != -1 && g_BanTime[param1] != -1)
				PrepareBan(param1, g_BanTarget[param1], g_BanTime[param1], info, g_BanTargetUserId[param1]);
		}

		case MenuAction_Cancel:
		{
			if (param2 == MenuCancel_ExitBack)
			{
				DisplayMenu(ReasonMenuHandle, param1, MENU_TIME_FOREVER);
			}
			else
			{
				ClearPendingBanState(param1);
			}
		}
	}
	return 0;
}

public int MenuHandler_BanPlayerList(Menu menu, MenuAction action, int param1, int param2)
{
	#if defined DEBUG
	LogToFile(logFile, "MenuHandler_BanPlayerList()");
	#endif

	switch (action)
	{
		case MenuAction_End:
		{
			delete menu;
		}

		case MenuAction_Cancel:
		{
			ClearPendingBanState(param1);

			if (param2 == MenuCancel_ExitBack && hTopMenu != INVALID_HANDLE)
			{
				hTopMenu.Display(param1, TopMenuPosition_LastCategory);
			}
		}

		case MenuAction_Select:
		{
			char info[32], name[MAX_NAME_LENGTH];
			int userid, target;

			menu.GetItem(param2, info, sizeof(info), _, name, sizeof(name));
			userid = StringToInt(info);

			if ((target = GetClientOfUserId(userid)) == 0)
			{
				PrintToChat(param1, "%s%t", Prefix, "Player no longer available");
			}
			else if (!CanUserTarget(param1, target))
			{
				PrintToChat(param1, "%s%t", Prefix, "Unable to target");
			}
			else
			{
				g_BanTarget[param1] = target;
				g_BanTargetUserId[param1] = userid;
				DisplayBanTimeMenu(param1);
			}
		}
	}
	return 0;
}

public int MenuHandler_BanTimeList(Menu menu, MenuAction action, int param1, int param2)
{
	#if defined DEBUG
	LogToFile(logFile, "MenuHandler_BanTimeList()");
	#endif

	switch (action)
	{
		case MenuAction_Cancel:
		{
			ClearPendingBanState(param1);

			if (param2 == MenuCancel_ExitBack && hTopMenu != INVALID_HANDLE)
			{
				hTopMenu.Display(param1, TopMenuPosition_LastCategory);
			}
		}

		case MenuAction_Select:
		{
			char info[32];

			menu.GetItem(param2, info, sizeof(info));
			g_BanTime[param1] = StringToInt(info);

			//DisplayBanReasonMenu(param1);
			ReasonMenuHandle.Display(param1, MENU_TIME_FOREVER);
		}

		case MenuAction_DrawItem:
		{
			char time[16];

			menu.GetItem(param2, time, sizeof(time));

			return (StringToInt(time) > 0 || CheckCommandAccess(param1, "sm_unban", ADMFLAG_UNBAN | ADMFLAG_ROOT)) ? ITEMDRAW_DEFAULT : ITEMDRAW_DISABLED;
		}
	}

	return 0;
}

stock void DisplayBanTargetMenu(int client)
{
	#if defined DEBUG
	LogToFile(logFile, "DisplayBanTargetMenu()");
	#endif

	CancelClientMenu(client);
	ClearPendingBanState(client);

	Menu menu = new Menu(MenuHandler_BanPlayerList); // Create a new menu, pass it the handler.

	char title[128];

	FormatEx(title, sizeof(title), "%T:", "Ban player", client);

	menu.SetTitle(title); // Set the title
	menu.ExitBackButton = true; // Yes we want back/exit

	AddTargetsToMenu2(menu, // Add clients to our menu
		client, // The client that called the display
		COMMAND_FILTER_NO_BOTS); // We dont want FakeClients

	menu.Display(client, MENU_TIME_FOREVER); // Show the menu to the client FOREVER!
}

stock void DisplayBanTimeMenu(int client)
{
	#if defined DEBUG
	LogToFile(logFile, "DisplayBanTimeMenu()");
	#endif

	char title[128];
	FormatEx(title, sizeof(title), "%T:", "Ban player", client);
	SetMenuTitle(TimeMenuHandle, title);

	DisplayMenu(TimeMenuHandle, client, MENU_TIME_FOREVER);
}

stock void ResetMenu()
{
	if (TimeMenuHandle != INVALID_HANDLE)
	{
		RemoveAllMenuItems(TimeMenuHandle);
	}

	if (ReasonMenuHandle != INVALID_HANDLE)
	{
		RemoveAllMenuItems(ReasonMenuHandle);
	}

	if (HackingMenuHandle != INVALID_HANDLE)
	{
		RemoveAllMenuItems(HackingMenuHandle);
	}
}

// QUERY CALL BACKS //

public void GotDatabase(Database db, const char[] error, any data)
{
	if (db == INVALID_HANDLE)
	{
		LogToFile(logFile, "Database failure: %s. See Docs: https://sbpp.github.io/docs/", error);
		g_bConnecting = false;

		// Parse the overrides backup!
		ParseBackupConfig_Overrides();
		return;
	}

	DB = db;

	char query[1024];

	// Set character set to UTF8MB4 in the database
	// Use SetCharset to ensure charset is set synchronously before any operations
	if (!DB.SetCharset("utf8mb4"))
	{
		LogToFile(logFile, "Failed to set database charset to utf8mb4, trying async method");
		// Fallback to async method
		Format(query, sizeof(query), "SET NAMES utf8mb4");
		DB.Query(ErrorCheckCallback, query);
	}

	InsertServerInfo();

	//CreateTimer(900.0, PruneBans);

	if (loadOverrides)
	{
		Format(query, sizeof(query), "SELECT type, name, flags FROM %s_overrides", DatabasePrefix);
		DB.Query(OverridesDone, query);
		loadOverrides = false;
	}

	if (loadGroups && enableAdmins)
	{
		FormatEx(query, sizeof(query), "SELECT name, flags, immunity, groups_immune   \
					FROM %s_srvgroups ORDER BY id", DatabasePrefix);
		curLoading++;
		DB.Query(GroupsDone, query);

		#if defined DEBUG
		LogToFile(logFile, "Fetching Group List");
		#endif
		loadGroups = false;
	}

	if (loadAdmins && enableAdmins)
	{
		char queryLastLogin[50] = "";

		if (requireSiteLogin)
			queryLastLogin = "lastvisit IS NOT NULL AND lastvisit != '' AND";

		if (serverID == -1)
		{
			FormatEx(query, sizeof(query), "SELECT authid, srv_password, (SELECT name FROM %s_srvgroups WHERE name = srv_group AND flags != '') AS srv_group, srv_flags, user, immunity  \
						FROM %s_admins_servers_groups AS asg \
						LEFT JOIN %s_admins AS a ON a.aid = asg.admin_id \
						WHERE %s (server_id = (SELECT sid FROM %s_servers WHERE ip = '%s' AND port = '%s' LIMIT 0,1)  \
						OR srv_group_id = ANY (SELECT group_id FROM %s_servers_groups WHERE server_id = (SELECT sid FROM %s_servers WHERE ip = '%s' AND port = '%s' LIMIT 0,1))) \
						GROUP BY aid, authid, srv_password, srv_group, srv_flags, user",
				DatabasePrefix, DatabasePrefix, DatabasePrefix, queryLastLogin, DatabasePrefix, ServerIpEscaped, ServerPort, DatabasePrefix, DatabasePrefix, ServerIpEscaped, ServerPort);
		} else {
			FormatEx(query, sizeof(query), "SELECT authid, srv_password, (SELECT name FROM %s_srvgroups WHERE name = srv_group AND flags != '') AS srv_group, srv_flags, user, immunity  \
						FROM %s_admins_servers_groups AS asg \
						LEFT JOIN %s_admins AS a ON a.aid = asg.admin_id \
						WHERE %s server_id = %d  \
						OR srv_group_id = ANY (SELECT group_id FROM %s_servers_groups WHERE server_id = %d) \
						GROUP BY aid, authid, srv_password, srv_group, srv_flags, user",
				DatabasePrefix, DatabasePrefix, DatabasePrefix, queryLastLogin, serverID, DatabasePrefix, serverID);
		}
		curLoading++;
		DB.Query(AdminsDone, query);

		#if defined DEBUG
		LogToFile(logFile, "Fetching Admin List");
		LogToFile(logFile, query);
		#endif
		loadAdmins = false;
	}
	g_bConnecting = false;

	CheckConnectedClientBans();
}

public void VerifyInsert(Database db, DBResultSet results, const char[] error, DataPack dataPack)
{
	if (dataPack == INVALID_HANDLE)
	{
		LogToFile(logFile, "%t: %s", "Ban Fail", error);

		return;
	}

	dataPack.Reset();

	int adminIndex = dataPack.ReadCell();
	int client = dataPack.ReadCell();
	int adminUserId = dataPack.ReadCell();
	int targetUserId = dataPack.ReadCell();
	int time = dataPack.ReadCell();

	DataPack reasonPack = view_as<DataPack>(dataPack.ReadCell());

	char reason[128], name[MAX_NAME_LENGTH], auth[MAX_AUTHID_LENGTH], gameAuth[MAX_AUTHID_LENGTH], ip[16], adminAuth[MAX_AUTHID_LENGTH], adminIp[16];

	if (reasonPack != null)
	{
		reasonPack.Reset();
		reasonPack.ReadString(reason, sizeof(reason));
	}

	dataPack.ReadString(name, sizeof(name));
	dataPack.ReadString(auth, sizeof(auth));
	dataPack.ReadString(gameAuth, sizeof(gameAuth));
	dataPack.ReadString(ip, sizeof(ip));
	dataPack.ReadString(adminAuth, sizeof(adminAuth));
	dataPack.ReadString(adminIp, sizeof(adminIp));

	CleanupBanDataPack(dataPack);

	int admin = adminIndex == 0 ? 0 : GetClientOfUserId(adminUserId);

	if (results == null)
	{
		LogToFile(logFile, "Verify Insert Query Failed: %s", error);
		UTIL_InsertTempBan(admin, client, targetUserId, time, name, auth, gameAuth, ip, reason, adminAuth, adminIp);
		return;
	}

	if (!IsClientConnected(client) || IsFakeClient(client) || GetClientUserId(client) != targetUserId)
		return;

	if (!time)
	{
		if (reason[0] == '\0')
		{
			ShowActivity2(admin, Prefix, "%t", "Permabanned Player", name);
		} else {
			ShowActivity2(admin, Prefix, "%t", "Permabanned Player Reason", name, reason);
		}
	} else {
		if (reason[0] == '\0')
		{
			ShowActivity2(admin, Prefix, "%t", "Banned Player", name, time);
		} else {
			ShowActivity2(admin, Prefix, "%t", "Banned Player Reason", name, time, reason);
		}
	}

	LogAction(admin, client, "%t", "Ban Log", admin, client, time, reason);

	// Kick player
	if (g_iUserIDs[client] == targetUserId)
	{
		char length[32];
		if(time == 0)
			FormatEx(length, sizeof(length), "%T", "permanent", client);
		else
			FormatEx(length, sizeof(length), "%d %T", time, time == 1 ? "minute" : "minutes", client);

		KickClient(client, "%t\n\n%t", "Banned Check Site", WebsiteAddress, "Kick Reason", admin, reason, length);
	}
}

public void SelectBanIpCallback(Database db, DBResultSet results, const char[] error, DataPack dataPack)
{
	int admin, minutes;
	char adminAuth[MAX_AUTHID_LENGTH], adminIp[16], banReason[256], ip[16], reason[128], Query[512];
	char targetName[MAX_NAME_LENGTH], sTEscapedName[MAX_NAME_LENGTH * 2 + 1], targetAuth[MAX_AUTHID_LENGTH];

	dataPack.Reset();
	int adminUserId = dataPack.ReadCell();
	admin = adminUserId == 0 ? 0 : GetClientOfUserId(adminUserId);
	minutes = dataPack.ReadCell();
	dataPack.ReadString(reason, sizeof(reason));
	dataPack.ReadString(ip, sizeof(ip));
	dataPack.ReadString(targetName, sizeof(targetName));
	dataPack.ReadString(targetAuth, sizeof(targetAuth));
	dataPack.ReadString(adminAuth, sizeof(adminAuth));
	dataPack.ReadString(adminIp, sizeof(adminIp));
	DB.Escape(reason, banReason, sizeof(banReason));
	DB.Escape(targetName, sTEscapedName, sizeof(sTEscapedName));

	if (results == null)
	{
		LogToFile(logFile, "Ban IP Select Query Failed: %s", error);
		if (admin && IsClientInGame(admin))
			PrintToChat(admin, "%s%t", Prefix, "Ban Fail");
		else
			PrintToServer("%s%t", Prefix, "Ban Fail");

		delete dataPack;
		return;
	}
	if (results.RowCount)
	{
		if (admin && IsClientInGame(admin))
			PrintToChat(admin, "%s%t", Prefix, "Already Banned", ip);
		else
			PrintToServer("%s%t", Prefix, "Already Banned", ip);

		delete dataPack;
		return;
	}
	if (serverID == -1)
	{
		FormatEx(Query, sizeof(Query), "INSERT INTO %s_bans (type, ip, authid, name, created, ends, length, reason, aid, adminIp, sid, country) VALUES \
						(1, '%s', '%s', '%s', UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + %d, %d, '%s', (SELECT aid FROM %s_admins WHERE authid = '%s' OR authid REGEXP '^STEAM_[0-9]:%s$'), '%s', \
						(SELECT sid FROM %s_servers WHERE ip = '%s' AND port = '%s' LIMIT 0,1), ' ')",
			DatabasePrefix, ip, targetAuth, sTEscapedName, (minutes * 60), (minutes * 60), banReason, DatabasePrefix, adminAuth, adminAuth[8], adminIp, DatabasePrefix, ServerIpEscaped, ServerPort);
	} else {
		FormatEx(Query, sizeof(Query), "INSERT INTO %s_bans (type, ip, authid, name, created, ends, length, reason, aid, adminIp, sid, country) VALUES \
						(1, '%s', '%s', '%s', UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + %d, %d, '%s', (SELECT aid FROM %s_admins WHERE authid = '%s' OR authid REGEXP '^STEAM_[0-9]:%s$'), '%s', \
						%d, ' ')",
			DatabasePrefix, ip, targetAuth, sTEscapedName, (minutes * 60), (minutes * 60), banReason, DatabasePrefix, adminAuth, adminAuth[8], adminIp, serverID);
	}

	db.Query(InsertBanIpCallback, Query, dataPack, DBPrio_High);
}

public void InsertBanIpCallback(Database db, DBResultSet results, const char[] error, DataPack dataPack)
{
	// if the pack is good unpack it and close the handle
	int admin, minutes;
	int target = -1;
	char reason[128];
	char targetIP[16];

	if (dataPack != null)
	{
		dataPack.Reset();
		int adminUserId = dataPack.ReadCell();
		admin = adminUserId == 0 ? 0 : GetClientOfUserId(adminUserId);
		minutes = dataPack.ReadCell();
		dataPack.ReadString(reason, sizeof(reason));
		dataPack.ReadString(targetIP, sizeof(targetIP));
		
		for(int i = 1; i <= MaxClients; i++)
		{
			if(!IsClientInGame(i) || IsFakeClient(i))
				continue;

			if(targetIP[0] != '\0' && strcmp(targetIP, g_sPlayerIP[i], false) == 0)
			{
				target = i;
				break;
			}
		}

		// Kick player
		if(target != -1)
		{
			char length[32];
			if(minutes == 0)
				FormatEx(length, sizeof(length), "permanent");
			else
				FormatEx(length, sizeof(length), "%d %s", minutes, minutes == 1 ? "minute" : "minutes");

			if (IsClientConnected(target))
				KickClient(target, "%t\n\n%t", "Banned Check Site", WebsiteAddress, "Kick Reason", admin, reason, length);
		}

		delete dataPack;
	} else {
		// Technically this should not be possible
		ThrowError("Invalid Handle in InsertBanIpCallback");
	}

	// If error is not an empty string the query failed
	if (results == null)
	{
		LogToFile(logFile, "Ban IP Insert Query Failed: %s", error);
		if (admin && IsClientInGame(admin))
			PrintToChat(admin, "%ssm_banip failed", Prefix);
		return;
	}

	LogAction(admin, -1, "%t", "Ban Added", admin, minutes, targetIP, reason);

	if (admin && IsClientInGame(admin))
		PrintToChat(admin, "%s%t", Prefix, "Ban Success Name", targetIP);
	else
		PrintToServer("%s%t", Prefix, "Ban Success Name", targetIP);
}

public void SelectUnbanCallback(Database db, DBResultSet results, const char[] error, DataPack dataPack)
{
	int admin;
	char arg[MAX_AUTHID_LENGTH], adminAuth[MAX_AUTHID_LENGTH], unbanReason[256];
	char reason[128];

	dataPack.Reset();
	int adminUserId = dataPack.ReadCell();
	admin = adminUserId == 0 ? 0 : GetClientOfUserId(adminUserId);
	dataPack.ReadString(reason, sizeof(reason)); // Reason
	dataPack.ReadString(arg, sizeof(arg)); // SteamID - IP
	dataPack.ReadString(adminAuth, sizeof(adminAuth)); // Admin SteamID

	db.Escape(reason, unbanReason, sizeof(unbanReason));

	// If error is not an empty string the query failed
	if (results == null)
	{
		LogToFile(logFile, "Unban Select Query Failed: %s", error);
		if (admin && IsClientInGame(admin))
		{
			PrintToChat(admin, "%ssm_unban failed", Prefix);
		}
		delete dataPack;
		return;
	}

	// If there was no results then a ban does not exist for that id
	if (!results.RowCount)
	{
		if (admin && IsClientInGame(admin))
			PrintToChat(admin, "%s%t", Prefix, "No Active Ban");
		else
			PrintToServer("%s%t", Prefix, "No Active Ban");

		delete dataPack;

		return;
	}

	// Every active ban that matches, as there can be more than one, e.g. of either universe: the connect
	// check would still find one that's left
	char bids[512];
	for (int i = 0; results.FetchRow(); i++)
	{
		Format(bids, sizeof(bids), "%s%s%d", bids, i ? "," : "", results.FetchInt(0));
	}

	char query[1024];
	Format(query, sizeof(query), "UPDATE %s_bans SET RemovedBy = (SELECT aid FROM %s_admins WHERE authid = '%s' OR authid REGEXP '^STEAM_[0-9]:%s$'), RemoveType = 'U', RemovedOn = UNIX_TIMESTAMP(), ureason = '%s' WHERE bid IN (%s)",
		DatabasePrefix, DatabasePrefix, adminAuth, adminAuth[8], unbanReason, bids);

	db.Query(InsertUnbanCallback, query, dataPack);
}

public void InsertUnbanCallback(Database db, DBResultSet results, const char[] error, DataPack dataPack)
{
	// if the pack is good unpack it and close the handle
	int admin;
	char arg[MAX_AUTHID_LENGTH];
	char reason[128];

	if (dataPack != null)
	{
		dataPack.Reset();
		int adminUserId = dataPack.ReadCell();
		admin = adminUserId == 0 ? 0 : GetClientOfUserId(adminUserId);
		dataPack.ReadString(reason, sizeof(reason)); // Reason
		dataPack.ReadString(arg, sizeof(arg)); // SteamID - IP
		delete dataPack;
	} else {
		// Technically this should not be possible
		ThrowError("Invalid Handle in InsertUnbanCallback");
	}

	// If error is not an empty string the query failed
	if (results == null)
	{
		LogToFile(logFile, "Unban Insert Query Failed: %s", error);
		if (admin && IsClientInGame(admin))
		{
			PrintToChat(admin, "%ssm_unban failed", Prefix);
		}
		return;
	}

	LogAction(admin, -1, "%t", "Ban Removed", admin, arg, reason);
	
	if (admin && IsClientInGame(admin))
		PrintToChat(admin, "%s%t", Prefix, "Unban Success Name", arg);
	else
		PrintToServer("%s%t", Prefix, "Unban Success Name", arg);
}

public void SelectAddbanCallback(Database db, DBResultSet results, const char[] error, DataPack dataPack)
{
	int admin, minutes;
	char adminAuth[MAX_AUTHID_LENGTH], adminIp[16], authid[MAX_AUTHID_LENGTH], authidEscaped[sizeof(authid) * 2 + 1], banReason[256], Query[1024];
	char reason[128];

	dataPack.Reset();
	int adminUserId = dataPack.ReadCell();
	admin = adminUserId == 0 ? 0 : GetClientOfUserId(adminUserId);
	minutes = dataPack.ReadCell();
	dataPack.ReadString(reason, sizeof(reason));
	dataPack.ReadString(authid, sizeof(authid));
	dataPack.ReadString(adminAuth, sizeof(adminAuth));
	dataPack.ReadString(adminIp, sizeof(adminIp));
	db.Escape(reason, banReason, sizeof(banReason));
	db.Escape(authid, authidEscaped, sizeof(authidEscaped));

	if (results == null)
	{
		LogToFile(logFile, "Add Ban Select Query Failed: %s", error);

		if (admin && IsClientInGame(admin))
			PrintToChat(admin, "%s%t", Prefix, "Ban Fail");
		else
			PrintToServer("%s%t", Prefix, "Ban Fail");

		delete dataPack;
		return;
	}
	if (results.RowCount)
	{
		if (admin && IsClientInGame(admin))
			PrintToChat(admin, "%s%t", Prefix, "Already Banned", authid);
		else
			PrintToServer("%s%t", Prefix, "Already Banned", authid);

		delete dataPack;
		return;
	}
	if (serverID == -1)
	{
		FormatEx(Query, sizeof(Query), "INSERT INTO %s_bans (authid, name, created, ends, length, reason, aid, adminIp, sid, country) VALUES \
						('%s', '', UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + %d, %d, '%s', (SELECT aid FROM %s_admins WHERE authid = '%s' OR authid REGEXP '^STEAM_[0-9]:%s$'), '%s', \
						(SELECT sid FROM %s_servers WHERE ip = '%s' AND port = '%s' LIMIT 0,1), ' ')",
			DatabasePrefix, authidEscaped, (minutes * 60), (minutes * 60), banReason, DatabasePrefix, adminAuth, adminAuth[8], adminIp, DatabasePrefix, ServerIpEscaped, ServerPort);
	} else {
		FormatEx(Query, sizeof(Query), "INSERT INTO %s_bans (authid, name, created, ends, length, reason, aid, adminIp, sid, country) VALUES \
						('%s', '', UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + %d, %d, '%s', (SELECT aid FROM %s_admins WHERE authid = '%s' OR authid REGEXP '^STEAM_[0-9]:%s$'), '%s', \
						%d, ' ')",
			DatabasePrefix, authidEscaped, (minutes * 60), (minutes * 60), banReason, DatabasePrefix, adminAuth, adminAuth[8], adminIp, serverID);
	}

	db.Query(InsertAddbanCallback, Query, dataPack, DBPrio_High);
}

public void InsertAddbanCallback(Database db, DBResultSet results, const char[] error, DataPack dataPack)
{
	int admin, minutes;
	char authid[MAX_AUTHID_LENGTH];
	char reason[128];

	dataPack.Reset();
	int adminUserId = dataPack.ReadCell();
	admin = adminUserId == 0 ? 0 : GetClientOfUserId(adminUserId);
	minutes = dataPack.ReadCell();
	dataPack.ReadString(reason, sizeof(reason));
	dataPack.ReadString(authid, sizeof(authid));
	delete dataPack;

	// If error is not an empty string the query failed
	if (results == null)
	{
		LogToFile(logFile, "Add Ban Insert Query Failed: %s", error);
		if (admin && IsClientInGame(admin))
		{
			PrintToChat(admin, "%ssm_addban failed", Prefix);
		}
		return;
	}

	LogAction(admin, -1, "%t", "Ban Added", admin, minutes, authid, reason);

	if (admin && IsClientInGame(admin))
		PrintToChat(admin, "%s%t", Prefix, "Ban Success Name", authid);
	else
		PrintToServer("%s%t", Prefix, "Ban Success Name", authid);
}

// ProcessQueueCallback is called as the result of selecting all the rows from the queue table
public void ProcessQueueCallback(Database db, DBResultSet results, const char[] error, any data)
{
	if (results == null)
	{
		LogToFile(logFile, "Failed to retrieve queued bans from sqlite database, %s", error);
		return;
	}
	if (DB == INVALID_HANDLE)
	{
		CreateTimer(float(ProcessQueueTime * 60), ProcessQueue);
		return;
	}

	char auth[MAX_AUTHID_LENGTH];
	int time;
	int startTime;
	char reason[128];
	char name[MAX_NAME_LENGTH];
	char ip[16];
	char adminAuth[MAX_AUTHID_LENGTH];
	char adminIp[16];
	char gameAuth[MAX_AUTHID_LENGTH];
	char query[1024];
	char banName[MAX_NAME_LENGTH * 2 + 1];
	char banReason[256];
	while (results.MoreRows)
	{
		// Oh noes! What happened?!
		if (!results.FetchRow())
			continue;

		// if we get to here then there are rows in the queue pending processing
		results.FetchString(0, auth, sizeof(auth));
		time = results.FetchInt(1);
		startTime = results.FetchInt(2);
		results.FetchString(3, reason, sizeof(reason));
		results.FetchString(4, name, sizeof(name));
		results.FetchString(5, ip, sizeof(ip));
		results.FetchString(6, adminAuth, sizeof(adminAuth));
		results.FetchString(7, adminIp, sizeof(adminIp));
		results.FetchString(8, gameAuth, sizeof(gameAuth));
		if (!DB.Escape(name, banName, sizeof(banName)) || !DB.Escape(reason, banReason, sizeof(banReason)))
		{
			LogToFile(logFile, "Failed to escape queued ban data for %s", auth);
			continue;
		}
		if (startTime + time * 60 > GetTime() || time == 0)
		{
			// This ban is still valid and should be entered into the db
			if (serverID == -1)
			{
				FormatEx(query, sizeof(query),
					"INSERT INTO %s_bans (ip, authid, name, created, ends, length, reason, aid, adminIp, sid) VALUES  \
						('%s', '%s', '%s', %d, %d, %d, '%s', (SELECT aid FROM %s_admins WHERE authid = '%s' OR authid REGEXP '^STEAM_[0-9]:%s$'), '%s', \
						(SELECT sid FROM %s_servers WHERE ip = '%s' AND port = '%s' LIMIT 0,1))",
					DatabasePrefix, ip, auth, banName, startTime, startTime + time * 60, time * 60, banReason, DatabasePrefix, adminAuth, adminAuth[8], adminIp, DatabasePrefix, ServerIpEscaped, ServerPort);
			}
			else
			{
				FormatEx(query, sizeof(query),
					"INSERT INTO %s_bans (ip, authid, name, created, ends, length, reason, aid, adminIp, sid) VALUES  \
						('%s', '%s', '%s', %d, %d, %d, '%s', (SELECT aid FROM %s_admins WHERE authid = '%s' OR authid REGEXP '^STEAM_[0-9]:%s$'), '%s', \
						%d)",
					DatabasePrefix, ip, auth, banName, startTime, startTime + time * 60, time * 60, banReason, DatabasePrefix, adminAuth, adminAuth[8], adminIp, serverID);
			}
			DataPack authPack = new DataPack();
			authPack.WriteString(auth);
			authPack.WriteString(gameAuth);
			authPack.Reset();
			DB.Query(AddedFromSQLiteCallback, query, authPack);
		} else {
			// The ban is no longer valid and should be deleted from the queue
			FormatEx(query, sizeof(query), "DELETE FROM queue WHERE steam_id = '%s'", auth);
			SQLiteDB.Query(ErrorCheckCallback, query);
		}
	}
	// We have finished processing the queue but should process again in ProcessQueueTime minutes
	CreateTimer(float(ProcessQueueTime * 60), ProcessQueue);
}

public void AddedFromSQLiteCallback(Database db, DBResultSet results, const char[] error, DataPack dataPack)
{
	char buffer[512];
	char auth[MAX_AUTHID_LENGTH], gameAuth[MAX_AUTHID_LENGTH];

	dataPack.ReadString(auth, sizeof(auth));
	dataPack.ReadString(gameAuth, sizeof(gameAuth));
	ResolveQueuedGameAuth(auth, gameAuth, sizeof(gameAuth));

	if (results != null)
	{
		// The insert was successful so delete the record from the queue
		FormatEx(buffer, sizeof(buffer), "DELETE FROM queue WHERE steam_id = '%s'", auth);
		SQLiteDB.Query(ErrorCheckCallback, buffer);

		// They are added to main banlist, so remove the temp ban
		RemoveBan(gameAuth, BANFLAG_AUTHID);

	} else {
		// the insert failed so we leave the record in the queue and increase our temporary ban
		BanIdentity(gameAuth, ProcessQueueTime, BANFLAG_AUTHID, "", "", 0);
	}
	delete dataPack;
}

public void ServerInfoCallback(Database db, DBResultSet results, const char[] error, any data)
{
	DataPack serverInfo = view_as<DataPack>(data);
	char serverIpEscaped[sizeof(ServerIpEscaped)], serverPort[sizeof(ServerPort)], databasePrefix[sizeof(DatabasePrefix)];
	serverInfo.ReadString(serverIpEscaped, sizeof(serverIpEscaped));
	serverInfo.ReadString(serverPort, sizeof(serverPort));
	serverInfo.ReadString(databasePrefix, sizeof(databasePrefix));
	int autoAdd = serverInfo.ReadCell();
	delete serverInfo;

	if (results == null)
	{
		LogToFile(logFile, "Server Select Query Failed: %s", error);
		return;
	}

	if (!results.RowCount)
	{
		// get the game folder name used to determine the mod
		char desc[64], query[512], rcon[128];
		char descEscaped[sizeof(desc) * 2 + 1], rconEscaped[sizeof(rcon) * 2 + 1];
		GetGameFolderName(desc, sizeof(desc));
		Format(rcon, sizeof(rcon), "");

		if (autoAdd == AUTO_ADD_SERVER_WITH_RCON)
		{
			ConVar cvarRconPassword = FindConVar("rcon_password");
			if (cvarRconPassword != null)
			{
				cvarRconPassword.GetString(rcon, sizeof(rcon));
			}
		}

		db.Escape(desc, descEscaped, sizeof(descEscaped));
		db.Escape(rcon, rconEscaped, sizeof(rconEscaped));
		FormatEx(query, sizeof(query), "INSERT INTO %s_servers (ip, port, rcon, modid) VALUES ('%s', '%s', '%s', (SELECT mid FROM %s_mods WHERE modfolder = '%s'))", databasePrefix, serverIpEscaped, serverPort, rconEscaped, databasePrefix, descEscaped);
		db.Query(ErrorCheckCallback, query);
	}
}

public void ErrorCheckCallback(Database db, DBResultSet results, const char[] error, any data)
{
	if (results == null)
	{
		LogToFile(logFile, "Query Failed: %s", error);
	}
}

public void VerifyBan(Database db, DBResultSet results, const char[] error, int userid)
{
	char clientAuth[MAX_AUTHID_LENGTH], clientIp[16];

	int client = GetClientOfUserId(userid);

	if (!client)
		return;

	PlayerCheckPending[client] = false;

	/* Failure happen. Do retry with delay */
	if (results == null)
	{
		LogToFile(logFile, "Verify Ban Query Failed: %s", error);
		if (PlayerRecheck[client] == INVALID_HANDLE)
			PlayerRecheck[client] = CreateTimer(RetryTime, ClientRecheck, client);
		return;
	}

	strcopy(clientAuth, sizeof(clientAuth), g_sSteamIDs[client]);
	strcopy(clientIp, sizeof(clientIp), g_sPlayerIP[client]);

	if (results.RowCount > 0)
	{
		char Name[MAX_NAME_LENGTH], Query[512];

		// Amending to ban record's IP field
		if (results.FetchRow())
		{
			char sIP[16];

			int iBid = results.FetchInt(0);
			results.FetchString(1, sIP, sizeof sIP);

			if (StrEqual(sIP, "") && clientIp[0] != '\0')
			{
				char sQuery[256];

				FormatEx(sQuery, sizeof sQuery, "UPDATE %s_bans SET `ip` = '%s' WHERE `bid` = '%d'", DatabasePrefix, clientIp, iBid);

				DB.Query(SQL_OnIPMend, sQuery, client);
			}
		}

		DB.Escape(g_sName[client], Name, sizeof Name);

		// Without a usable IP (e.g. SDR client) never match IP bans: an empty
		// address would otherwise match any type=1 row with a blank IP.
		char ipCondition[64];
		if (clientIp[0] != '\0')
			FormatEx(ipCondition, sizeof(ipCondition), "ip = '%s'", clientIp);
		else
			strcopy(ipCondition, sizeof(ipCondition), "1 = 0");

		if (serverID == -1)
		{
			FormatEx(Query, sizeof(Query), "INSERT INTO %s_banlog (sid ,time ,name ,bid) VALUES  \
				((SELECT sid FROM %s_servers WHERE ip = '%s' AND port = '%s' LIMIT 0,1), UNIX_TIMESTAMP(), '%s', \
				(SELECT bid FROM %s_bans WHERE ((type = 0 AND authid REGEXP '^STEAM_[0-9]:%s$') OR (type = 1 AND %s)) AND RemoveType IS NULL LIMIT 0,1))",
				DatabasePrefix, DatabasePrefix, ServerIpEscaped, ServerPort, Name, DatabasePrefix, clientAuth[8], ipCondition);
		}
		else
		{
			FormatEx(Query, sizeof(Query), "INSERT INTO %s_banlog (sid ,time ,name ,bid) VALUES  \
				(%d, UNIX_TIMESTAMP(), '%s', \
				(SELECT bid FROM %s_bans WHERE ((type = 0 AND authid REGEXP '^STEAM_[0-9]:%s$') OR (type = 1 AND %s)) AND RemoveType IS NULL LIMIT 0,1))",
				DatabasePrefix, serverID, Name, DatabasePrefix, clientAuth[8], ipCondition);
		}

		db.Query(ErrorCheckCallback, Query, client, DBPrio_High);

		char kickMessage[256], gameAuth[MAX_AUTHID_LENGTH];
		FormatEx(kickMessage, sizeof(kickMessage), "%T", "Banned Check Site", client, WebsiteAddress);

		// Don't use BanClient() here: it needs the player entity, which may not exist
		// yet (OnClientAuthorized can precede OnClientPutInServer). Ban the engine auth
		// string (Synergy rejects Steam2), falling back to IP on LAN or lookup failure.
		if (GetClientAuthId(client, AuthId_Engine, gameAuth, sizeof(gameAuth))
			&& BanIdentity(gameAuth, 5, BANFLAG_AUTHID, kickMessage, "", 0))
		{
			KickClient(client, "%s", kickMessage);
		}
		else
		{
			// Kick before addip, as BanClient does, so the client sees our message.
			KickClientEx(client, "%s", kickMessage);
			if (clientIp[0] != '\0')
				BanIdentity(clientIp, 5, BANFLAG_IP, kickMessage, "", 0);
		}

		return;
	}

	#if defined DEBUG
	LogToFile(logFile, "%s is NOT banned.", clientAuth);
	#endif

	PlayerStatus[client] = true;
}

public void SQL_OnIPMend(Database db, DBResultSet results, const char[] error, int client)
{
	if (results == null)
	{
		// We now using SteamID Format2
		LogToFile(logFile, "Failed to mend IP address for %s (%s): %s", g_sSteamIDs[client], g_sPlayerIP[client], error);
	}
}

public void AdminsDone(Database db, DBResultSet results, const char[] error, any data)
{
	//SELECT authid, srv_password , srv_group, srv_flags, user
	if (results == null)
	{
		--curLoading;
		CheckLoadAdmins(AdminCache_Admins);
		LogToFile(logFile, "Failed to retrieve admins from the database, %s", error);
		return;
	}
	char authType[] = "steam";
	char identity[66];
	char password[66];
	char groups[256];
	char flags[32];
	char name[MAX_NAME_LENGTH];
	int admCount = 0;
	int Immunity = 0;
	AdminId curAdm = INVALID_ADMIN_ID;
	KeyValues adminsKV = new KeyValues("Admins");

	while (results.FetchRow())
	{
		if (results.IsFieldNull(0))
			continue; // Sometimes some rows return NULL due to some setups

		results.FetchString(0, identity, 66);
		results.FetchString(1, password, 66);
		results.FetchString(2, groups, 256);
		results.FetchString(3, flags, 32);
		results.FetchString(4, name, MAX_NAME_LENGTH);

		Immunity = results.FetchInt(5);

		TrimString(name);
		TrimString(identity);
		TrimString(groups);
		TrimString(flags);

		// Disable writing to file if they chose to
		if (backupConfig)
		{
			adminsKV.JumpToKey(name, true);

			adminsKV.SetString("auth", authType);
			adminsKV.SetString("identity", identity);

			if (strlen(flags) > 0)
				adminsKV.SetString("flags", flags);

			if (strlen(groups) > 0)
				adminsKV.SetString("group", groups);

			if (strlen(password) > 0)
				adminsKV.SetString("password", password);

			if (Immunity > 0)
				adminsKV.SetNum("immunity", Immunity);

			adminsKV.Rewind();
		}

		// find or create the admin using that identity
		if ((curAdm = FindAdminByIdentity(authType, identity)) == INVALID_ADMIN_ID)
		{
			curAdm = CreateAdmin(name);
			// That should never happen!
			if (!curAdm.BindIdentity(authType, identity))
			{
				LogToFile(logFile, "Unable to bind admin %s to identity %s", name, identity);
				RemoveAdmin(curAdm);
				continue;
			}
		}

		#if defined DEBUG
		LogToFile(logFile, "Given %s (%s) admin", name, identity);
		#endif

		int curPos = 0;
		GroupId curGrp = INVALID_GROUP_ID;
		int numGroups;
		char iterGroupName[64];

		if (strcmp(groups[curPos], "") != 0)
		{
			curGrp = FindAdmGroup(groups[curPos]);
			if (curGrp == INVALID_GROUP_ID)
			{
				LogToFile(logFile, "Unknown group \"%s\"", groups[curPos]);
			}
			else
			{
				// Check, if he's not in the group already.
				numGroups = curAdm.GroupCount;
				for (int i = 0; i < numGroups; i++)
				{
					curAdm.GetGroup(i, iterGroupName, sizeof(iterGroupName));
					// Admin is already part of the group, so don't try to inherit its permissions.
					if (strcmp(iterGroupName, groups[curPos], false) == 0)
					{
						numGroups = -2;
						break;
					}
				}

				// Only try to inherit the group, if it's a new one.
				if (numGroups != -2 && !curAdm.InheritGroup(curGrp))
				{
					LogToFile(logFile, "Unable to inherit group \"%s\"", groups[curPos]);
				}

				if (curAdm.ImmunityLevel < Immunity)
				{
					curAdm.ImmunityLevel = Immunity;
				}
				#if defined DEBUG
				LogToFile(logFile, "Admin %s (%s) has %d immunity", name, identity, Immunity);
				#endif
			}
		}

		if (strlen(password) > 0)
			curAdm.SetPassword(password);

		for (int i = 0; i < strlen(flags); ++i)
		{
			if (flags[i] < 'a' || flags[i] > 'z')
				continue;

			int idx = flags[i]-'a';
			if (g_FlagLetters[idx] < Admin_Reservation)
				continue;

			curAdm.SetFlag(g_FlagLetters[idx], true);
		}
		++admCount;
	}

	if (backupConfig)
		adminsKV.ExportToFile(adminsLoc);
	delete adminsKV;

	#if defined DEBUG
	LogToFile(logFile, "Finished loading %i admins.", admCount);
	#endif

	--curLoading;
	CheckLoadAdmins(AdminCache_Admins);
}

public void GroupsDone(Database db, DBResultSet results, const char[] error, any data)
{
	if (results == null)
	{
		curLoading--;
		CheckLoadAdmins(AdminCache_Groups);
		LogToFile(logFile, "Failed to retrieve groups from the database, %s", error);
		return;
	}

	char grpName[128], immuneGrpName[128];
	char grpFlags[32];
	int Immunity;
	int grpCount = 0;
	KeyValues groupsKV = new KeyValues("Groups");

	GroupId curGrp = INVALID_GROUP_ID;
	while (results.FetchRow())
	{
		if (results.IsFieldNull(0))
			continue; // Sometimes some rows return NULL due to some setups
		results.FetchString(0, grpName, 128);
		results.FetchString(1, grpFlags, 32);
		Immunity = results.FetchInt(2);
		results.FetchString(3, immuneGrpName, 128);

		TrimString(grpName);
		TrimString(grpFlags);
		TrimString(immuneGrpName);

		// Ignore empty rows..
		if (!strlen(grpName))
			continue;

		curGrp = CreateAdmGroup(grpName);

		if (backupConfig)
		{
			groupsKV.JumpToKey(grpName, true);
			if (strlen(grpFlags) > 0)
				groupsKV.SetString("flags", grpFlags);
			if (Immunity > 0)
				groupsKV.SetNum("immunity", Immunity);

			groupsKV.Rewind();
		}

		if (curGrp == INVALID_GROUP_ID)
		{  //This occurs when the group already exists
			curGrp = FindAdmGroup(grpName);
		}

		for (int i = 0; i < strlen(grpFlags); ++i)
		{
			if (grpFlags[i] < 'a' || grpFlags[i] > 'z')
				continue;

			int idx = grpFlags[i]-'a';
			if (g_FlagLetters[idx] < Admin_Reservation)
				continue;

			curGrp.SetFlag(g_FlagLetters[idx], true);
		}

		// Set the group immunity.
		if (Immunity > 0)
		{
			curGrp.ImmunityLevel = Immunity;
			#if defined DEBUG
			LogToFile(logFile, "Group %s has %d immunity", grpName, Immunity);
			#endif
		}

		grpCount++;
	}

	if (backupConfig)
		groupsKV.ExportToFile(groupsLoc);
	delete groupsKV;

	#if defined DEBUG
	LogToFile(logFile, "Finished loading %i groups.", grpCount);
	#endif

	// Load the group overrides
	char query[512];
	FormatEx(query, sizeof(query), "SELECT sg.name, so.type, so.name, so.access FROM %s_srvgroups_overrides so LEFT JOIN %s_srvgroups sg ON sg.id = so.group_id ORDER BY sg.id", DatabasePrefix, DatabasePrefix);
	db.Query(LoadGroupsOverrides, query);
}

// Reparse to apply inherited immunity
public void GroupsSecondPass(Database db, DBResultSet results, const char[] error, any data)
{
	if (results == null)
	{
		curLoading--;
		CheckLoadAdmins(AdminCache_Groups);
		LogToFile(logFile, "Failed to retrieve groups from the database, %s", error);
		return;
	}

	char grpName[128], immunityGrpName[128];

	GroupId curGrp = INVALID_GROUP_ID;
	GroupId immuneGrp = INVALID_GROUP_ID;
	while (results.FetchRow())
	{
		if (results.IsFieldNull(0))
			continue; // Sometimes some rows return NULL due to some setups

		results.FetchString(0, grpName, 128);
		TrimString(grpName);
		if (strlen(grpName) == 0)
			continue;

		results.FetchString(2, immunityGrpName, sizeof(immunityGrpName));
		TrimString(immunityGrpName);

		curGrp = FindAdmGroup(grpName);
		if (curGrp == INVALID_GROUP_ID)
			continue;

		immuneGrp = FindAdmGroup(immunityGrpName);
		if (immuneGrp == INVALID_GROUP_ID)
			continue;

		curGrp.AddGroupImmunity(immuneGrp);

		#if defined DEBUG
		LogToFile(logFile, "Group %s inhertied immunity from group %s", grpName, immunityGrpName);
		#endif
	}
	--curLoading;
	CheckLoadAdmins(AdminCache_Groups);
}

public void LoadGroupsOverrides(Database db, DBResultSet results, const char[] error, any data)
{
	if (results == null)
	{
		curLoading--;
		CheckLoadAdmins(AdminCache_Overrides);
		LogToFile(logFile, "Failed to retrieve group overrides from the database, %s", error);
		return;
	}

	char sGroupName[128], sType[16], sCommand[64], sAllowed[16];
	OverrideRule iRule;
	OverrideType iType;

	KeyValues groupsKV = new KeyValues("Groups");
	groupsKV.ImportFromFile(groupsLoc);

	GroupId curGrp = INVALID_GROUP_ID;
	while (results.FetchRow())
	{
		if (results.IsFieldNull(0))
			continue; // Sometimes some rows return NULL due to some setups

		results.FetchString(0, sGroupName, sizeof(sGroupName));
		TrimString(sGroupName);
		if (strlen(sGroupName) == 0)
			continue;

		results.FetchString(1, sType, sizeof(sType));
		results.FetchString(2, sCommand, sizeof(sCommand));
		results.FetchString(3, sAllowed, sizeof(sAllowed));

		curGrp = FindAdmGroup(sGroupName);
		if (curGrp == INVALID_GROUP_ID)
			continue;

		iRule = strcmp(sAllowed, "allow", false) == 0 ? Command_Allow : Command_Deny;
		iType = strcmp(sType, "group", false) == 0 ? Override_CommandGroup : Override_Command;

		#if defined DEBUG
		PrintToServer("AddAdmGroupCmdOverride(%i, %s, %i, %i)", curGrp, sCommand, iType, iRule);
		#endif

		// Save overrides into admin_groups.cfg backup
		if (groupsKV.JumpToKey(sGroupName))
		{
			groupsKV.JumpToKey("Overrides", true);
			if (iType == Override_Command)
				groupsKV.SetString(sCommand, sAllowed);
			else
			{
				Format(sCommand, sizeof(sCommand), "@%s", sCommand);
				groupsKV.SetString(sCommand, sAllowed);
			}
			groupsKV.Rewind();
		}

		curGrp.AddCommandOverride(sCommand, iType, iRule);
	}
	curLoading--;
	CheckLoadAdmins(AdminCache_Overrides);

	if (backupConfig)
		groupsKV.ExportToFile(groupsLoc);
	delete groupsKV;
}

public void OverridesDone(Database db, DBResultSet results, const char[] error, any data)
{
	if (results == null)
	{
		LogToFile(logFile, "Failed to retrieve overrides from the database, %s", error);
		ParseBackupConfig_Overrides();
		return;
	}

	KeyValues hKV = new KeyValues("SB_Overrides");

	char sFlags[32], sName[MAX_NAME_LENGTH], sType[64];
	while (results.FetchRow())
	{
		results.FetchString(0, sType, sizeof(sType));
		results.FetchString(1, sName, sizeof(sName));
		results.FetchString(2, sFlags, sizeof(sFlags));

		// KeyValuesToFile won't add that key, if the value is ""..
		if (sFlags[0] == '\0')
		{
			sFlags[0] = ' ';
			sFlags[1] = '\0';
		}

		#if defined DEBUG
		LogToFile(logFile, "Adding override (%s, %s, %s)", sType, sName, sFlags);
		#endif

		if (strcmp(sType, "command", false) == 0)
		{
			AddCommandOverride(sName, Override_Command, ReadFlagString(sFlags));
			hKV.JumpToKey("override_commands", true);
			hKV.SetString(sName, sFlags);
			hKV.GoBack();
		}
		else if (strcmp(sType, "group", false) == 0)
		{
			AddCommandOverride(sName, Override_CommandGroup, ReadFlagString(sFlags));
			hKV.JumpToKey("override_groups", true);
			hKV.SetString(sName, sFlags);
			hKV.GoBack();
		}
	}

	hKV.Rewind();

	if (backupConfig)
		hKV.ExportToFile(overridesLoc);
	delete hKV;
}

// TIMER CALL BACKS //

public Action ClientRecheck(Handle timer, any client)
{
	PlayerRecheck[client] = INVALID_HANDLE;

	if (IsClientConnected(client) && IsClientAuthorized(client))
	{
		CheckClientBan(client);
	}

	return Plugin_Stop;
}

/*
public Action PruneBans(Handle timer)
{
	char Query[512];
	FormatEx(Query, sizeof(Query),
			"UPDATE %s_bans SET RemovedBy = 0, RemoveType = 'E', RemovedOn = UNIX_TIMESTAMP() WHERE length != '0' AND ends < UNIX_TIMESTAMP()",
			DatabasePrefix);

	DB.Query(ErrorCheckCallback, Query);
	return Plugin_Continue;
}
*/

public Action ProcessQueue(Handle timer, any data)
{
	char buffer[512];
	Format(buffer, sizeof(buffer), "SELECT steam_id, time, start_time, reason, name, ip, admin_id, admin_ip, game_id FROM queue");
	SQLiteDB.Query(ProcessQueueCallback, buffer);
	return Plugin_Continue;
}

// PARSER //

static void InitializeConfigParser()
{
	if (ConfigParser == null)
	{
		ConfigParser = new SMCParser();
		ConfigParser.OnEnterSection = ReadConfig_NewSection;
		ConfigParser.OnKeyValue = ReadConfig_KeyValue;
		ConfigParser.OnLeaveSection = ReadConfig_EndSection;
	}
}

static void InternalReadConfig(const char[] path)
{
	ConfigState = ConfigStateNone;

	SMCError err = ConfigParser.ParseFile(path);

	if (err != SMCError_Okay)
	{
		char buffer[64];
		PrintToServer("%s", ConfigParser.GetErrorString(err, buffer, sizeof(buffer)) ? buffer : "Fatal parse error");
	}
}

public SMCResult ReadConfig_NewSection(SMCParser smc, const char[] name, bool opt_quotes)
{
	if (name[0])
	{
		if (strcmp("Config", name, false) == 0) {
			ConfigState = ConfigStateConfig;
		} else if (strcmp("BanReasons", name, false) == 0) {
			ConfigState = ConfigStateReasons;
		} else if (strcmp("HackingReasons", name, false) == 0) {
			ConfigState = ConfigStateHacking;
		} else if (strcmp("BanTime", name, false) == 0) {
			ConfigState = ConfigStateTime;
		}
	}
	return SMCParse_Continue;
}

public SMCResult ReadConfig_KeyValue(SMCParser smc, const char[] key, const char[] value, bool key_quotes, bool value_quotes)
{
	if (!key[0])
		return SMCParse_Continue;

	switch (ConfigState)
	{
		case ConfigStateConfig:
		{
			if (strcmp("website", key, false) == 0)
			{
				strcopy(WebsiteAddress, sizeof(WebsiteAddress), value);
			}
			else if (strcmp("Addban", key, false) == 0)
			{
				if (StringToInt(value) == 0)
				{
					CommandDisable |= DISABLE_ADDBAN;
				}
			}
			else if (strcmp("AutoAddServer", key, false) == 0)
			{
				int sAutoAdd = StringToInt(value);
				AutoAdd = (sAutoAdd < 0 || sAutoAdd > 2) ? 0 : sAutoAdd;
			}
			else if (strcmp("ServerIP", key, false) == 0)
			{
				char configuredIp[64];
				strcopy(configuredIp, sizeof(configuredIp), value);
				TrimString(configuredIp);

				if (SBPP_IsValidServerIpOverride(configuredIp))
				{
					strcopy(ConfiguredServerIp, sizeof(ConfiguredServerIp), configuredIp);
				}
				else
				{
					ConfiguredServerIp[0] = '\0';
					LogToFile(logFile, "Ignoring invalid ServerIP override; expected an IPv4 address");
				}
			}
			else if (strcmp("Unban", key, false) == 0)
			{
				if (StringToInt(value) == 0)
				{
					CommandDisable |= DISABLE_UNBAN;
				}
			}
			else if (strcmp("DatabasePrefix", key, false) == 0)
			{
				strcopy(DatabasePrefix, sizeof(DatabasePrefix), value);

				if (DatabasePrefix[0] == '\0')
				{
					DatabasePrefix = "sb";
				}
			}
			else if (strcmp("RetryTime", key, false) == 0)
			{
				RetryTime = StringToFloat(value);
				if (RetryTime < 15.0)
				{
					RetryTime = 15.0;
				} else if (RetryTime > 60.0) {
					RetryTime = 60.0;
				}
			}
			else if (strcmp("ProcessQueueTime", key, false) == 0)
			{
				ProcessQueueTime = StringToInt(value);
			}
			else if (strcmp("BackupConfigs", key, false) == 0)
			{
				backupConfig = StringToInt(value) == 1;
			}
			else if (strcmp("EnableAdmins", key, false) == 0)
			{
				enableAdmins = StringToInt(value) == 1;
			}
			else if (strcmp("RequireSiteLogin", key, false) == 0)
			{
				requireSiteLogin = StringToInt(value) == 1;
			}
			else if (strcmp("ServerID", key, false) == 0)
			{
				serverID = StringToInt(value);

				int sbid = GetConVarInt(sb_id);
				if (sbid != -1)
				{
					serverID = sbid;
				}
			}
		}

		case ConfigStateReasons:
		{
			if (ReasonMenuHandle != INVALID_HANDLE)
			{
				AddMenuItem(ReasonMenuHandle, key, value);
			}
		}
		case ConfigStateHacking:
		{
			if (HackingMenuHandle != INVALID_HANDLE)
			{
				AddMenuItem(HackingMenuHandle, key, value);
			}
		}
		case ConfigStateTime:
		{
			if (StringToInt(key) > -1 && TimeMenuHandle != INVALID_HANDLE)
			{
				AddMenuItem(TimeMenuHandle, key, value);
			}
		}
	}
	return SMCParse_Continue;
}

public SMCResult ReadConfig_EndSection(SMCParser smc)
{
	return SMCParse_Continue;
}


/*********************************************************
 * Ban Player from server
 *
 * @param client	The client index of the player to ban
 * @param time		The time to ban the player for (in minutes, 0 = permanent)
 * @param reason	The reason to ban the player from the server
 * @noreturn
 *********************************************************/
public int Native_SBBanPlayer(Handle plugin, int numParams)
{
	int client = GetNativeCell(1);
	int target = GetNativeCell(2);
	int time = GetNativeCell(3);
	char reason[128];
	GetNativeString(4, reason, 128);

	if (reason[0] == '\0')
		strcopy(reason, sizeof(reason), "Banned by SourceBans");

	if (client && IsClientInGame(client))
	{
		AdminId aid = GetUserAdmin(client);
		if (aid == INVALID_ADMIN_ID)
		{
			ThrowNativeError(SP_ERROR_NATIVE, "Ban Error: Player is not an admin.");
			return 0;
		}

		if (!aid.HasFlag(Admin_Ban))
		{
			ThrowNativeError(SP_ERROR_NATIVE, "Ban Error: Player does not have BAN flag.");
			return 0;
		}
	}

	PrepareBan(client, target, time, reason);
	return true;
}

public int Native_SBPP_BanPlayerBySteamId(Handle plugin, int numParams)
{
	if (DB == INVALID_HANDLE)
	{
		ThrowNativeError(SP_ERROR_NATIVE, "SourceBans++ database is not available.");
		return 0;
	}

	int admin = GetNativeCell(1);
	int iTime = GetNativeCell(4);

	if (admin < 0 || admin > MaxClients)
	{
		ThrowNativeError(SP_ERROR_NATIVE, "SBPP_BanPlayerBySteamId: iAdmin must be 0 or a valid client index.");
		return 0;
	}

	if (iTime < 0)
	{
		ThrowNativeError(SP_ERROR_NATIVE, "SBPP_BanPlayerBySteamId: iTime cannot be negative.");
		return 0;
	}

	if (admin != 0)
	{
		if (!IsClientInGame(admin))
		{
			ThrowNativeError(SP_ERROR_NATIVE, "Ban Error: Player is not in game.");
			return 0;
		}

		AdminId aid = GetUserAdmin(admin);
		if (aid == INVALID_ADMIN_ID)
		{
			ThrowNativeError(SP_ERROR_NATIVE, "Ban Error: Player is not an admin.");
			return 0;
		}

		if (!aid.HasFlag(Admin_Ban))
		{
			ThrowNativeError(SP_ERROR_NATIVE, "Ban Error: Player does not have BAN flag.");
			return 0;
		}
	}

	char steamId[MAX_AUTHID_LENGTH], name[MAX_NAME_LENGTH], reason[128];
	GetNativeString(2, steamId, sizeof(steamId));
	GetNativeString(3, name, sizeof(name));
	GetNativeString(5, reason, sizeof(reason));

	char validatedSteam3[MAX_AUTHID_LENGTH];
	if (!Steam2ToSteam3(steamId, validatedSteam3, sizeof(validatedSteam3)))
	{
		ThrowNativeError(SP_ERROR_NATIVE, "SBPP_BanPlayerBySteamId: steamId must be in SteamID2 format (STEAM_[01]:[01]:Z), got: %s", steamId);
		return 0;
	}

	if (reason[0] == '\0')
		strcopy(reason, sizeof(reason), "Banned by SourceBans");

	char adminAuth[MAX_AUTHID_LENGTH], adminIp[16];
	if (admin == 0)
	{
		strcopy(adminAuth, sizeof(adminAuth), "STEAM_ID_SERVER");
		strcopy(adminIp, sizeof(adminIp), ServerIp);
	}
	else
	{
		strcopy(adminAuth, sizeof(adminAuth), g_sSteamIDs[admin]);
		strcopy(adminIp, sizeof(adminIp), g_sPlayerIP[admin]);
	}

	DataPack pack = new DataPack();
	pack.WriteCell(admin == 0 ? 0 : GetClientUserId(admin));
	pack.WriteCell(iTime);
	pack.WriteString(reason);
	pack.WriteString(steamId);
	pack.WriteString(name);
	pack.WriteString(adminAuth);
	pack.WriteString(adminIp);

	char steamIdEscaped[MAX_AUTHID_LENGTH * 2 + 1], steamIdYzEscaped[MAX_AUTHID_LENGTH * 2 + 1];
	DB.Escape(steamId, steamIdEscaped, sizeof(steamIdEscaped));
	DB.Escape(steamId[8], steamIdYzEscaped, sizeof(steamIdYzEscaped));

	char query[512];
	FormatEx(query, sizeof(query), "SELECT bid FROM %s_bans WHERE type = 0 AND (authid = '%s' OR authid REGEXP '^STEAM_[0-9]:%s$') AND (length = 0 OR ends > UNIX_TIMESTAMP()) AND RemoveType IS NULL",
		DatabasePrefix, steamIdEscaped, steamIdYzEscaped);

	DB.Query(DB_OnBanBySteamIdSelect, query, pack, DBPrio_High);

	return 0;
}

void DB_OnBanBySteamIdSelect(Database db, DBResultSet results, const char[] error, DataPack pack)
{
	if (results == null)
	{
		LogToFile(logFile, "[SBPP] BanPlayerBySteamId select failed: %s", error);
		delete pack;
		return;
	}

	pack.Reset();
	int adminUserId = pack.ReadCell();
	int iTime = pack.ReadCell();
	char reason[128], steamId[MAX_AUTHID_LENGTH], name[MAX_NAME_LENGTH], adminAuth[MAX_AUTHID_LENGTH], adminIp[16];
	pack.ReadString(reason, sizeof(reason));
	pack.ReadString(steamId, sizeof(steamId));
	pack.ReadString(name, sizeof(name));
	pack.ReadString(adminAuth, sizeof(adminAuth));
	pack.ReadString(adminIp, sizeof(adminIp));
	delete pack;

	if (results.RowCount > 0)
	{
		LogToFile(logFile, "[SBPP] BanPlayerBySteamId: %s is already banned, skipping.", steamId);
		return;
	}

	char steamIdEscaped[MAX_AUTHID_LENGTH * 2 + 1], nameEscaped[MAX_NAME_LENGTH * 2 + 1], reasonEscaped[256],
		adminAuthEscaped[MAX_AUTHID_LENGTH * 2 + 1], adminAuthYzEscaped[MAX_AUTHID_LENGTH * 2 + 1], adminIpEscaped[33];
	if (!db.Escape(steamId, steamIdEscaped, sizeof(steamIdEscaped))
		|| !db.Escape(name, nameEscaped, sizeof(nameEscaped))
		|| !db.Escape(reason, reasonEscaped, sizeof(reasonEscaped))
		|| !db.Escape(adminAuth, adminAuthEscaped, sizeof(adminAuthEscaped))
		|| !db.Escape(adminAuth[8], adminAuthYzEscaped, sizeof(adminAuthYzEscaped))
		|| !db.Escape(adminIp, adminIpEscaped, sizeof(adminIpEscaped)))
	{
		LogToFile(logFile, "[SBPP] BanPlayerBySteamId failed to escape ban data for %s", steamId);
		return;
	}

	char query[1024];
	if (serverID == -1)
	{
		FormatEx(query, sizeof(query), "INSERT INTO %s_bans (authid, name, created, ends, length, reason, aid, adminIp, sid, country) VALUES \
			('%s', '%s', UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + %d, %d, '%s', \
			IFNULL((SELECT aid FROM %s_admins WHERE authid = '%s' OR authid REGEXP '^STEAM_[0-9]:%s$'),'0'), '%s', \
			(SELECT sid FROM %s_servers WHERE ip = '%s' AND port = '%s' LIMIT 0,1), ' ')",
			DatabasePrefix, steamIdEscaped, nameEscaped, (iTime * 60), (iTime * 60), reasonEscaped,
			DatabasePrefix, adminAuthEscaped, adminAuthYzEscaped, adminIpEscaped,
			DatabasePrefix, ServerIpEscaped, ServerPort);
	}
	else
	{
		FormatEx(query, sizeof(query), "INSERT INTO %s_bans (authid, name, created, ends, length, reason, aid, adminIp, sid, country) VALUES \
			('%s', '%s', UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + %d, %d, '%s', \
			IFNULL((SELECT aid FROM %s_admins WHERE authid = '%s' OR authid REGEXP '^STEAM_[0-9]:%s$'),'0'), '%s', \
			%d, ' ')",
			DatabasePrefix, steamIdEscaped, nameEscaped, (iTime * 60), (iTime * 60), reasonEscaped,
			DatabasePrefix, adminAuthEscaped, adminAuthYzEscaped, adminIpEscaped,
			serverID);
	}

	DataPack fwdPack = new DataPack();
	fwdPack.WriteCell(adminUserId);
	fwdPack.WriteCell(iTime);
	fwdPack.WriteString(reason);

	db.Query(DB_OnBanBySteamIdInsert, query, fwdPack, DBPrio_High);
}

void DB_OnBanBySteamIdInsert(Database db, DBResultSet results, const char[] error, DataPack pack)
{
	pack.Reset();
	int adminUserId = pack.ReadCell();
	int iTime = pack.ReadCell();
	char reason[128];
	pack.ReadString(reason, sizeof(reason));
	delete pack;

	if (results == null)
	{
		LogToFile(logFile, "[SBPP] BanPlayerBySteamId insert failed: %s", error);
		return;
	}

	int admin = adminUserId == 0 ? 0 : GetClientOfUserId(adminUserId);

	Call_StartForward(g_hFwd_OnBanAdded);
	Call_PushCell(admin);
	Call_PushCell(-1);
	Call_PushCell(iTime);
	Call_PushString(reason);
	Call_Finish();
}

public int Native_SBReportPlayer(Handle plugin, int numParams)
{
	if (numParams < 3)
	{
		ThrowNativeError(SP_ERROR_NATIVE, "Invalid amount of arguments. Received %d arguments", numParams);
		return 0;
	}

	int iReporter = GetNativeCell(1)
	  , iTarget = GetNativeCell(2)
	  , iReasonLen;

	int iTime = GetTime();

	GetNativeStringLength(3, iReasonLen);

	iReasonLen++;

	char[] sReason = new char[iReasonLen];

	GetNativeString(3, sReason, iReasonLen);

	char sREscapedName[MAX_NAME_LENGTH * 2 + 1], sTEscapedName[MAX_NAME_LENGTH * 2 + 1];
	char[] sEscapedReason = new char[iReasonLen * 2 + 1];

	DB.Escape(g_sName[iReporter], sREscapedName, sizeof sREscapedName);
	DB.Escape(g_sName[iTarget], sTEscapedName, sizeof sTEscapedName);
	DB.Escape(sReason, sEscapedReason, iReasonLen * 2 + 1);

	char[] sQuery = new char[512 + (iReasonLen * 2 + 1)];

	Format(sQuery, 512 + (iReasonLen * 2 + 1), "INSERT INTO %s_submissions (`submitted`, `modid`, `SteamId`, `name`, `email`, `reason`, `ip`, `subname`, `sip`, `archiv`, `server`)"
	... "VALUES ('%d', 0, '%s', '%s', '%s', '%s', '%s', '%s', '%s', 0, '%d')", DatabasePrefix, iTime, g_sSteamIDs[iTarget], sTEscapedName, g_sSteamIDs[iReporter], sEscapedReason, g_sPlayerIP[iReporter], sREscapedName, g_sPlayerIP[iTarget], (serverID != -1) ? serverID : 0);

	DataPack dataPack = new DataPack();

	dataPack.WriteCell(GetClientUserId(iReporter));
	dataPack.WriteCell(GetClientUserId(iTarget));
	dataPack.WriteCell(iReasonLen);
	dataPack.WriteString(sReason);

	DB.Query(SQL_OnReportPlayer, sQuery, dataPack);
	return 0;
}

public void SQL_OnReportPlayer(Database db, DBResultSet results, const char[] error, DataPack dataPack)
{
	if (results == null)
	{
		LogToFile(logFile, "Failed to submit report: %s", error);
		delete dataPack;
	}
	else
	{
		dataPack.Reset();

		int reporterUserId = dataPack.ReadCell();
		int targetUserId = dataPack.ReadCell();
		int iReasonLen = dataPack.ReadCell();

		char[] sReason = new char[iReasonLen];

		dataPack.ReadString(sReason, iReasonLen);
		delete dataPack;

		int iReporter = GetClientOfUserId(reporterUserId);
		int iTarget = GetClientOfUserId(targetUserId);
		if (iReporter == 0 || iTarget == 0)
			return;

		Call_StartForward(g_hFwd_OnReportAdded);
		Call_PushCell(iReporter);
		Call_PushCell(iTarget);
		Call_PushString(sReason);
		Call_Finish();
	}
}

// STOCK FUNCTIONS //

stock bool IsAsciiDecimal(const char[] value)
{
	if (value[0] == '\0')
		return false;

	for (int i = 0; value[i] != '\0'; i++)
	{
		if (value[i] < '0' || value[i] > '9')
			return false;
	}
	return true;
}

stock bool Steam2ToSteam3(const char[] steam2, char[] steam3, int maxlength)
{
	int colonCount = 0;
	for (int i = 0; steam2[i] != '\0'; i++)
	{
		if (steam2[i] == ':')
			colonCount++;
	}
	if (colonCount != 2)
		return false;

	char parts[3][22];
	if (ExplodeString(steam2, ":", parts, sizeof(parts), sizeof(parts[])) != sizeof(parts))
		return false;
	if (!StrEqual(parts[0], "STEAM_0") && !StrEqual(parts[0], "STEAM_1"))
		return false;
	if (parts[1][1] != '\0' || (parts[1][0] != '0' && parts[1][0] != '1'))
		return false;
	if (!IsAsciiDecimal(parts[2]))
		return false;

	int zLength = strlen(parts[2]);
	if (zLength > 10 || (zLength == 10 && strcmp(parts[2], "2147483647") > 0))
		return false;

	int y = parts[1][0] - '0';
	int z = StringToInt(parts[2]);
	FormatEx(steam3, maxlength, "[U:1:%u]", z * 2 + y);
	return true;
}

stock void ResolveQueuedGameAuth(const char[] storedAuth, char[] gameAuth, int maxlength)
{
	if (gameAuth[0] != '\0')
		return;

	char gameFolder[32];
	GetGameFolderName(gameFolder, sizeof(gameFolder));
	if (StrEqual(gameFolder, "synergy", false) && Steam2ToSteam3(storedAuth, gameAuth, maxlength))
		return;

	strcopy(gameAuth, maxlength, storedAuth);
}

public void InitializeBackupDB()
{
	char error[256];

	SQLiteDB = SQLite_UseDatabase("sourcebans-queue", error, sizeof(error));
	if (SQLiteDB == INVALID_HANDLE)
	{
		SetFailState(error);
	}

	if (!SQL_FastQuery(SQLiteDB,
			"CREATE TABLE IF NOT EXISTS queue ( \
				steam_id TEXT PRIMARY KEY ON CONFLICT REPLACE, \
				time INTEGER, \
				start_time INTEGER, \
				reason TEXT, \
				name TEXT, \
				ip TEXT, \
				admin_id TEXT, \
				admin_ip TEXT, \
				game_id TEXT NOT NULL DEFAULT '');"))
	{
		SQL_GetError(SQLiteDB, error, sizeof(error));
		SetFailState("Could not create the local ban queue: %s", error);
		return;
	}

	DBResultSet columns = SQL_Query(SQLiteDB, "PRAGMA table_info(queue)");
	if (columns == null)
	{
		SQL_GetError(SQLiteDB, error, sizeof(error));
		SetFailState("Could not inspect the local ban queue: %s", error);
		return;
	}

	bool hasGameId = false;
	char columnName[32];
	while (columns.FetchRow())
	{
		columns.FetchString(1, columnName, sizeof(columnName));
		if (StrEqual(columnName, "game_id"))
		{
			hasGameId = true;
			break;
		}
	}
	delete columns;

	if (!hasGameId && !SQL_FastQuery(SQLiteDB, "ALTER TABLE queue ADD COLUMN game_id TEXT NOT NULL DEFAULT ''"))
	{
		SQL_GetError(SQLiteDB, error, sizeof(error));
		SetFailState("Could not upgrade the local ban queue: %s", error);
	}
}

public bool CreateBan(int client, int target, int time, const char[] reason)
{
	char adminIp[16], adminAuth[MAX_AUTHID_LENGTH], gameAuth[MAX_AUTHID_LENGTH];
	int admin = client;

	CleanupPendingBanDataPack(admin);

	// The server is the one calling the ban
	if (!admin)
	{
		if (reason[0] == '\0')
		{
			// We cannot pop the reason menu if the command was issued from the server
			PrintToServer("%s%T", Prefix, "Include Reason", LANG_SERVER);
			return false;
		}

		// setup dummy adminAuth and adminIp for server
		strcopy(adminAuth, sizeof(adminAuth), "STEAM_ID_SERVER");
		strcopy(adminIp, sizeof(adminIp), ServerIp);
	} else {
		strcopy(adminAuth, sizeof(adminAuth), g_sSteamIDs[admin]);
		strcopy(adminIp, sizeof(adminIp), g_sPlayerIP[admin]);
	}

	// target information
	int userid = admin ? g_iUserIDs[admin] : 0;
	if (!GetClientAuthId(target, AuthId_Engine, gameAuth, sizeof(gameAuth), false))
		strcopy(gameAuth, sizeof(gameAuth), g_sSteamIDs[target]);

	// Pack everything into a data pack so we can retain it
	DataPack dataPack = new DataPack();
	DataPack reasonPack = new DataPack();

	WritePackString(reasonPack, reason);

	dataPack.WriteCell(admin);
	dataPack.WriteCell(target);
	dataPack.WriteCell(userid);
	dataPack.WriteCell(g_iUserIDs[target]);
	dataPack.WriteCell(time);
	dataPack.WriteCell(reasonPack);
	dataPack.WriteString(g_sName[target]);
	dataPack.WriteString(g_sSteamIDs[target]);
	dataPack.WriteString(gameAuth);
	dataPack.WriteString(g_sPlayerIP[target]);
	dataPack.WriteString(adminAuth);
	dataPack.WriteString(adminIp);

	dataPack.Reset();
	reasonPack.Reset();

	if (reason[0] != '\0')
	{
		// if we have a valid reason pass move forward with the ban
		if (DB != INVALID_HANDLE)
		{
			UTIL_InsertBan(time, g_sName[target], g_sSteamIDs[target], g_sPlayerIP[target], reason, adminAuth, adminIp, dataPack);
		} else {
			CleanupBanDataPack(dataPack);
			UTIL_InsertTempBan(admin, target, g_iUserIDs[target], time, g_sName[target], g_sSteamIDs[target], gameAuth, g_sPlayerIP[target], reason, adminAuth, adminIp);
		}
	} else {
		// We need a reason so offer the administrator a menu of reasons
		PlayerDataPack[admin] = dataPack;
		DisplayMenu(ReasonMenuHandle, admin, MENU_TIME_FOREVER);
		ReplyToCommand(admin, "%s%t", Prefix, "Check Menu");
	}

	Call_StartForward(g_hFwd_OnBanAdded);
	Call_PushCell(client);
	Call_PushCell(target);
	Call_PushCell(time);
	Call_PushString(reason);
	Call_Finish();

	return true;
}

stock void CleanupBanDataPack(DataPack dataPack)
{
	if (dataPack == null)
		return;

	dataPack.Reset();
	dataPack.ReadCell(); // admin index
	dataPack.ReadCell(); // target index
	dataPack.ReadCell(); // admin userid
	dataPack.ReadCell(); // target userid
	dataPack.ReadCell(); // time

	DataPack reasonPack = view_as<DataPack>(dataPack.ReadCell());
	if (reasonPack != null)
		delete reasonPack;

	delete dataPack;
}

stock void CleanupPendingBanDataPack(int client)
{
	if (client < 0 || client > MaxClients)
		return;

	DataPack dataPack = PlayerDataPack[client];
	PlayerDataPack[client] = null;
	CleanupBanDataPack(dataPack);
}

stock void ClearPendingBanState(int client)
{
	if (client < 0 || client > MaxClients)
		return;

	CleanupPendingBanDataPack(client);
	g_BanTarget[client] = -1;
	g_BanTime[client] = -1;
	g_BanTargetUserId[client] = -1;
	g_ownReasons[client] = false;
}

stock void UTIL_InsertBan(int time, const char[] Name, const char[] Authid, const char[] Ip, const char[] Reason, const char[] AdminAuthid, const char[] AdminIp, DataPack dataPack)
{
	//new Handle:dummy;
	//PruneBans(dummy);
	char banName[MAX_NAME_LENGTH];
	char banReason[256];
	char Query[1024];
	DB.Escape(Name, banName, sizeof(banName));
	DB.Escape(Reason, banReason, sizeof(banReason));
	if (serverID == -1)
	{
		FormatEx(Query, sizeof(Query), "INSERT INTO %s_bans (ip, authid, name, created, ends, length, reason, aid, adminIp, sid, country) VALUES \
						('%s', '%s', '%s', UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + %d, %d, '%s', IFNULL((SELECT aid FROM %s_admins WHERE authid = '%s' OR authid REGEXP '^STEAM_[0-9]:%s$'),'0'), '%s', \
						(SELECT sid FROM %s_servers WHERE ip = '%s' AND port = '%s' LIMIT 0,1), ' ')",
			DatabasePrefix, Ip, Authid, banName, (time * 60), (time * 60), banReason, DatabasePrefix, AdminAuthid, AdminAuthid[8], AdminIp, DatabasePrefix, ServerIpEscaped, ServerPort);
	} else {
		FormatEx(Query, sizeof(Query), "INSERT INTO %s_bans (ip, authid, name, created, ends, length, reason, aid, adminIp, sid, country) VALUES \
						('%s', '%s', '%s', UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + %d, %d, '%s', IFNULL((SELECT aid FROM %s_admins WHERE authid = '%s' OR authid REGEXP '^STEAM_[0-9]:%s$'),'0'), '%s', \
						%d, ' ')",
			DatabasePrefix, Ip, Authid, banName, (time * 60), (time * 60), banReason, DatabasePrefix, AdminAuthid, AdminAuthid[8], AdminIp, serverID);
	}
	DB.Query(VerifyInsert, Query, dataPack, DBPrio_High);
}

stock void UTIL_InsertTempBan(int admin, int client, int targetUserId, int time, const char[] name, const char[] auth, const char[] gameAuth, const char[] ip, const char[] reason, const char[] adminAuth, const char[] adminIp)
{
	// we add a temporary ban and then add the record into the queue to be processed when the database is available
	BanIdentity(gameAuth, ProcessQueueTime, BANFLAG_AUTHID, reason, "", admin);

	if (client > 0 && client <= MaxClients && IsClientInGame(client) && GetClientUserId(client) == targetUserId)
	{
		char length[32];
		if(time == 0)
			FormatEx(length, sizeof(length), "permanent");
		else
			FormatEx(length, sizeof(length), "%d %s", time, time == 1 ? "minute" : "minutes");
		KickClient(client, "%t\n\n%t", "Banned Check Site", WebsiteAddress, "Kick Reason", admin, reason, length);
	}

	char banName[MAX_NAME_LENGTH * 2 + 1], banReason[256], gameAuthEscaped[MAX_AUTHID_LENGTH * 2 + 1], query[1024];

	if (!SQLiteDB.Escape(name, banName, sizeof(banName))
		|| !SQLiteDB.Escape(reason, banReason, sizeof(banReason))
		|| !SQLiteDB.Escape(gameAuth, gameAuthEscaped, sizeof(gameAuthEscaped)))
	{
		LogToFile(logFile, "Failed to escape temporary ban data for %s", auth);
		return;
	}

	FormatEx(query, sizeof(query), "INSERT OR REPLACE INTO queue (steam_id, time, start_time, reason, name, ip, admin_id, admin_ip, game_id) VALUES ('%s', %i, %i, '%s', '%s', '%s', '%s', '%s', '%s')",
		auth, time, GetTime(), banReason, banName, ip, adminAuth, adminIp, gameAuthEscaped);

	SQLiteDB.Query(ErrorCheckCallback, query);
}

stock void CheckLoadAdmins(AdminCachePart part)
{
	bool bNotify = true;

	Call_StartForward(g_hFwd_OnClientPreAdminCheck);
	Call_PushCell(part);
	Call_Finish(bNotify);

	if (!bNotify)
		return;

	for (int i = 1; i <= MaxClients; i++)
	{
		if (IsClientInGame(i) && IsClientAuthorized(i))
		{
			RunAdminCacheChecks(i);
			NotifyPostAdminCheck(i);

			Call_StartForward(g_hFwd_OnClientPostAdminCheck);
			Call_PushCell(i);
			Call_Finish();
		}
	}
}

stock void ResolveServerInfo()
{
	SBPP_ResolveServerIp(CvarHostIp, ConfiguredServerIp, ServerIp, sizeof(ServerIp));
	CvarPort.GetString(ServerPort, sizeof(ServerPort));

	if (DB != INVALID_HANDLE)
	{
		DB.Escape(ServerIp, ServerIpEscaped, sizeof(ServerIpEscaped));
	}
}

stock void InsertServerInfo()
{
	if (DB == INVALID_HANDLE)
	{
		return;
	}

	ResolveServerInfo();

	if (AutoAdd != AUTO_ADD_SERVER_DISABLED)
	{
		char query[256];
		FormatEx(query, sizeof(query), "SELECT sid FROM %s_servers WHERE ip = '%s' AND port = '%s'", DatabasePrefix, ServerIpEscaped, ServerPort);

		DataPack serverInfo = new DataPack();
		serverInfo.WriteString(ServerIpEscaped);
		serverInfo.WriteString(ServerPort);
		serverInfo.WriteString(DatabasePrefix);
		serverInfo.WriteCell(AutoAdd);
		serverInfo.Reset();

		DB.Query(ServerInfoCallback, query, serverInfo);
	}
}

stock void PrepareBan(int client, int target, int time, char[] reason, int targetUserId = -1)
{
	#if defined DEBUG
	LogToFile(logFile, "PrepareBan()");
	#endif

	ClearPendingBanState(client);

	if (!target || !IsClientInGame(target) || (targetUserId != -1 && GetClientUserId(target) != targetUserId))
		return;

	char bannedSite[512];

	if (CreateBan(client, target, time, reason))
	{
		if (!time)
		{
			if (reason[0] == '\0')
			{
				ShowActivity(client, "%t", "Permabanned Player", g_sName[target]);
			} else {
				ShowActivity(client, "%t", "Permabanned Player Reason", g_sName[target], reason);
			}
		} else {
			if (reason[0] == '\0')
			{
				ShowActivity(client, "%t", "Banned Player", g_sName[target], time);
			} else {
				ShowActivity(client, "%t", "Banned Player Reason", g_sName[target], time, reason);
			}
		}

		LogAction(client, target, "%t", "Ban Log", client, target, time, reason);

		char length[32];

		if(time == 0)
			FormatEx(length, sizeof(length), "%T", "permanent", client);
		else
			FormatEx(length, sizeof(length), "%d %t", time, time == 1 ? "minute" : "minutes", client);

		if (time > 5 || time == 0)
			time = 5;

		Format(bannedSite, sizeof(bannedSite), "%t\n\n%t", "Banned Check Site", WebsiteAddress, "Kick Reason", client, reason, length);//temp
		BanClient(target, time, BANFLAG_AUTO, bannedSite, bannedSite, "sm_ban", client);
	}

	g_BanTarget[client] = -1;
	g_BanTime[client] = -1;
}

stock void ReadConfig()
{
	InitializeConfigParser();

	if (ConfigParser == null)
	{
		return;
	}

	char ConfigFile[PLATFORM_MAX_PATH];
	BuildPath(Path_SM, ConfigFile, sizeof(ConfigFile), "configs/sourcebans/sourcebans.cfg");

	if (FileExists(ConfigFile))
	{
		InternalReadConfig(ConfigFile);
		PrintToServer("%sLoading configs/sourcebans.cfg config file", Prefix);
	} else {
		char Error[PLATFORM_MAX_PATH + 64];
		FormatEx(Error, sizeof(Error), "%sFATAL *** ERROR *** can not find %s", Prefix, ConfigFile);
		LogToFile(logFile, "FATAL *** ERROR *** can not find %s", ConfigFile);
		SetFailState(Error);
	}
}

stock bool ResetSettings()
{
	char previousServerIp[sizeof(ServerIp)], previousServerPort[sizeof(ServerPort)], previousDatabasePrefix[sizeof(DatabasePrefix)];
	strcopy(previousServerIp, sizeof(previousServerIp), ServerIp);
	strcopy(previousServerPort, sizeof(previousServerPort), ServerPort);
	strcopy(previousDatabasePrefix, sizeof(previousDatabasePrefix), DatabasePrefix);
	int previousServerId = serverID;
	int previousAutoAdd = AutoAdd;

	CommandDisable = 0;
	AutoAdd = AUTO_ADD_SERVER_DISABLED;
	serverID = -1;
	ConfiguredServerIp[0] = '\0';

	ResetMenu();
	ReadConfig();
	ResolveServerInfo();

	return previousServerId != serverID
		|| previousAutoAdd != AutoAdd
		|| !StrEqual(previousServerIp, ServerIp)
		|| !StrEqual(previousServerPort, ServerPort)
		|| !StrEqual(previousDatabasePrefix, DatabasePrefix);
}

stock void ParseBackupConfig_Overrides()
{
	KeyValues hKV = new KeyValues("SB_Overrides");

	if (!hKV.ImportFromFile(overridesLoc))
		return;

	if (!hKV.GotoFirstSubKey())
		return;

	char sSection[16], sFlags[32], sName[MAX_NAME_LENGTH];
	OverrideType type;

	do
	{
		hKV.GetSectionName(sSection, sizeof(sSection));
		if (strcmp(sSection, "override_commands", false) == 0)
			type = Override_Command;
		else if (strcmp(sSection, "override_groups", false) == 0)
			type = Override_CommandGroup;
		else
			continue;

		if (hKV.GotoFirstSubKey(false))
		{
			do
			{
				hKV.GetSectionName(sName, sizeof(sName));
				hKV.GetString(NULL_STRING, sFlags, sizeof(sFlags));
				AddCommandOverride(sName, type, ReadFlagString(sFlags));
				#if defined _DEBUG
				PrintToServer("Adding override (%s, %s, %s)", sSection, sName, sFlags);
				#endif
			} while (hKV.GotoNextKey(false));
			hKV.GoBack();
		}
	}
	while (hKV.GotoNextKey());
	delete hKV;
}

stock AdminFlag[] CreateFlagLetters()
{
	AdminFlag FlagLetters[FLAG_LETTERS_SIZE];

	FlagLetters['a'-'a'] = Admin_Reservation;
	FlagLetters['b'-'a'] = Admin_Generic;
	FlagLetters['c'-'a'] = Admin_Kick;
	FlagLetters['d'-'a'] = Admin_Ban;
	FlagLetters['e'-'a'] = Admin_Unban;
	FlagLetters['f'-'a'] = Admin_Slay;
	FlagLetters['g'-'a'] = Admin_Changemap;
	FlagLetters['h'-'a'] = Admin_Convars;
	FlagLetters['i'-'a'] = Admin_Config;
	FlagLetters['j'-'a'] = Admin_Chat;
	FlagLetters['k'-'a'] = Admin_Vote;
	FlagLetters['l'-'a'] = Admin_Password;
	FlagLetters['m'-'a'] = Admin_RCON;
	FlagLetters['n'-'a'] = Admin_Cheats;
	FlagLetters['o'-'a'] = Admin_Custom1;
	FlagLetters['p'-'a'] = Admin_Custom2;
	FlagLetters['q'-'a'] = Admin_Custom3;
	FlagLetters['r'-'a'] = Admin_Custom4;
	FlagLetters['s'-'a'] = Admin_Custom5;
	FlagLetters['t'-'a'] = Admin_Custom6;
	FlagLetters['z'-'a'] = Admin_Root;

	return FlagLetters;
}

stock void AccountForLateLoading()
{
	// The database connects asynchronously, so the actual ban checks run from
	// GotDatabase once it's up.
	for (int i = 1; i <= MaxClients; i++)
	{
		if (IsClientConnected(i))
		{
			PlayerStatus[i] = false;
			PlayerCheckPending[i] = false;
			OnClientConnected(i);
		}
	}
}

//Yarr!
